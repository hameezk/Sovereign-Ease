import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/home.dart';
// import 'package:myapp/page-1/home-BvH.dart';
// import 'package:myapp/page-1/my-collections.dart';
// import 'package:myapp/page-1/newly-added-collections.dart';
// import 'package:myapp/page-1/new-collection.dart';
// import 'package:myapp/page-1/store-categories.dart';
// import 'package:myapp/page-1/frame-95.dart';
// import 'package:myapp/page-1/notifications.dart';
// import 'package:myapp/page-1/settings.dart';
// import 'package:myapp/page-1/my-profile.dart';
// import 'package:myapp/page-1/friends-profile.dart';
// import 'package:myapp/page-1/share-popup.dart';
// import 'package:myapp/page-1/gender-popup.dart';
// import 'package:myapp/page-1/size-popup.dart';
// import 'package:myapp/page-1/color-popup.dart';
// import 'package:myapp/page-1/story.dart';
// import 'package:myapp/page-1/trending-topic-1.dart';
// import 'package:myapp/page-1/frame-31.dart';
// import 'package:myapp/page-1/category.dart';
// import 'package:myapp/page-1/frame-1000004198.dart';
// import 'package:myapp/page-1/frame-1000004199.dart';
// import 'package:myapp/page-1/frame-1000004200.dart';
// import 'package:myapp/page-1/frame-1000004201.dart';
// import 'package:myapp/page-1/sign-up.dart';
// import 'package:myapp/page-1/login.dart';
// import 'package:myapp/page-1/splash.dart';
// import 'package:myapp/page-1/home-q37.dart';
// import 'package:myapp/page-1/my-collections-in5.dart';
// import 'package:myapp/page-1/newly-added-collections-FcM.dart';
// import 'package:myapp/page-1/new-collection-AzD.dart';
// import 'package:myapp/page-1/store.dart';
// import 'package:myapp/page-1/store-designers.dart';
// import 'package:myapp/page-1/store-categories-nYZ.dart';
// import 'package:myapp/page-1/notifications-u4d.dart';
// import 'package:myapp/page-1/settings-UJd.dart';
// import 'package:myapp/page-1/my-profile-2Mw.dart';
// import 'package:myapp/page-1/friends-profile-uqK.dart';
// import 'package:myapp/page-1/share-popup-VLd.dart';
// import 'package:myapp/page-1/gender-popup-94M.dart';
// import 'package:myapp/page-1/size-popup-j1B.dart';
// import 'package:myapp/page-1/color-popup-SFb.dart';
// import 'package:myapp/page-1/story-bUV.dart';
// import 'package:myapp/page-1/category-rM7.dart';
// import 'package:myapp/page-1/sign-up-WKT.dart';
// import 'package:myapp/page-1/login-9DB.dart';
// import 'package:myapp/page-1/splash-t65.dart';
// import 'package:myapp/page-1/home-n1f.dart';
// import 'package:myapp/page-1/my-inventory.dart';
// import 'package:myapp/page-1/payment-details.dart';
// import 'package:myapp/page-1/payment-details-9Um.dart';
// import 'package:myapp/page-1/inventory-item.dart';
// import 'package:myapp/page-1/inventory-item-dQu.dart';
// import 'package:myapp/page-1/analytics-.dart';
// import 'package:myapp/page-1/orders.dart';
// import 'package:myapp/page-1/notification-setting.dart';
// import 'package:myapp/page-1/account-settings.dart';
// import 'package:myapp/page-1/store-settings.dart';
// import 'package:myapp/page-1/home-GSm.dart';
// import 'package:myapp/page-1/my-inventory-L57.dart';
// import 'package:myapp/page-1/inventory-item-zHw.dart';
// import 'package:myapp/page-1/inventory-item-3KF.dart';
// import 'package:myapp/page-1/analytics--Qxq.dart';
// import 'package:myapp/page-1/orders-k81.dart';
// import 'package:myapp/page-1/notification-setting-hkV.dart';
// import 'package:myapp/page-1/account-settings-scD.dart';
// import 'package:myapp/page-1/store-settings-K4m.dart';
// import 'package:myapp/page-1/login-EJ5.dart';
// import 'package:myapp/page-1/splash-fAy.dart';
// import 'package:myapp/page-1/login-ch7.dart';
// import 'package:myapp/page-1/splash-B4d.dart';
// import 'package:myapp/page-1/frame-28.dart';
// import 'package:myapp/page-1/store-designers-4PB.dart';
// import 'package:myapp/page-1/store-categories-KMb.dart';
// import 'package:myapp/page-1/image-capture.dart';
// import 'package:myapp/page-1/select-image.dart';
// import 'package:myapp/page-1/select-images.dart';
// import 'package:myapp/page-1/image-capture-cgq.dart';
// import 'package:myapp/page-1/select-image-7Jh.dart';
// import 'package:myapp/page-1/select-images-H9B.dart';
// import 'package:myapp/page-1/view-post.dart';
// import 'package:myapp/page-1/upcomings.dart';
// import 'package:myapp/page-1/delete-account.dart';
// import 'package:myapp/page-1/my-cart.dart';
// import 'package:myapp/page-1/checkout-2nd-time-all-detailed-filled.dart';
// import 'package:myapp/page-1/checkout-first-time.dart';
// import 'package:myapp/page-1/privacy-security.dart';
// import 'package:myapp/page-1/notifications-JgZ.dart';
// import 'package:myapp/page-1/account-privacy.dart';
// import 'package:myapp/page-1/change-password.dart';
// import 'package:myapp/page-1/checkout-2nd-time-all-detailed-filled-Tpd.dart';
// import 'package:myapp/page-1/checkout-first-time-kBK.dart';
// import 'package:myapp/page-1/my-cart-JuF.dart';
// import 'package:myapp/page-1/delete-account-rQ1.dart';
// import 'package:myapp/page-1/upcomings-dgD.dart';
// import 'package:myapp/page-1/view-post-x9f.dart';
// import 'package:myapp/page-1/store-search.dart';
// import 'package:myapp/page-1/social-search.dart';
// import 'package:myapp/page-1/social-search-ffF.dart';
// import 'package:myapp/page-1/friends-profile-PTP.dart';
// import 'package:myapp/page-1/privacy-security-76R.dart';
// import 'package:myapp/page-1/notifications-9E1.dart';
// import 'package:myapp/page-1/account-privacy-FcM.dart';
// import 'package:myapp/page-1/change-password-mWh.dart';
// import 'package:myapp/page-1/friends-profile-H1j.dart';
// import 'package:myapp/page-1/frame-1000004215.dart';
// import 'package:myapp/bin/home.dart';
// import 'package:myapp/bin/store-categories.dart';
// import 'package:myapp/bin/store-designers.dart';
// import 'package:myapp/bin/store-designers-GR7.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
