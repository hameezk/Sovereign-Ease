import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signup9Kf (5:50317)
        padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf7),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // blackstatusbar4xR (5:50320)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 0*fem, 21*fem),
              width: double.infinity,
              height: 16*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timezLH (I5:50335;727:363)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: -0.2800000012*fem,
                          color: Color(0xff0a0a0a),
                        ),
                        children: [
                          TextSpan(
                            text: '9:4',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: -0.2800000012*fem,
                              color: Color(0xff0a0a0a),
                            ),
                          ),
                          TextSpan(
                            text: '1',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: -0.2800000012*fem,
                              color: Color(0xff0a0a0a),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // groupg6d (5:50321)
                    margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // cellularconnection1Po (5:50330)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                          width: 17*fem,
                          height: 10.67*fem,
                          child: Image.asset(
                            'assets/page-1/images/cellular-connection-Lz5.png',
                            width: 17*fem,
                            height: 10.67*fem,
                          ),
                        ),
                        Container(
                          // wifivmf (5:50326)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                          width: 15.33*fem,
                          height: 11*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-hHs.png',
                            width: 15.33*fem,
                            height: 11*fem,
                          ),
                        ),
                        Container(
                          // batteryr9X (5:50322)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: 24.33*fem,
                          height: 11.33*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery-SYH.png',
                            width: 24.33*fem,
                            height: 11.33*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame1000004191ZZj (99:2878)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.66*fem, 0*fem),
              width: 361*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgzwbgPT (9zs6bHgEiFPhu4PEYgGzwB)
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // iconarrowarrowleftR69 (5:50465)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-arrow-arrow-left-on9.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                        Container(
                          // frame21w4V (5:50475)
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // createanaccount6TB (5:50473)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                child: Text(
                                  'Create an account',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 0.7272727273*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Text(
                                // signupandstartexploringtourch1 (5:50474)
                                'Sign up and start exploring Tourch',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame308Ps (5:50556)
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame295K7 (5:50555)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame28dbX (5:50535)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // group19Zk5 (I99:2872;99:2828)
                                      padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 51*fem, 4*fem),
                                      width: double.infinity,
                                      height: 42*fem,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xffebdfd7)),
                                        color: Color(0xfff4ede8),
                                        borderRadius: BorderRadius.circular(15*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroup18adfHK (9zs73C6jxxj1RTNCeu18AD)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 45*fem, 0*fem),
                                            width: 176*fem,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              color: Color(0xff11a0af),
                                              borderRadius: BorderRadius.circular(12*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'I am a buyer',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                          TextButton(
                                            // iamasellerjHB (I99:2872;99:2843)
                                            onPressed: () {},
                                            style: TextButton.styleFrom (
                                              padding: EdgeInsets.zero,
                                            ),
                                            child: Text(
                                              'I am a seller',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff8d8d8d),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 24*fem,
                                    ),
                                    Container(
                                      // group2132y (5:50534)
                                      width: double.infinity,
                                      height: 68*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // frame22yxD (5:50481)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                            width: 172*fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // firstname7oX (5:50478)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'First name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group19qjX (5:50480)
                                                  padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                                  width: double.infinity,
                                                  decoration: BoxDecoration (
                                                    border: Border.all(color: Color(0xffebdfd7)),
                                                    color: Color(0xfffff7f1),
                                                    borderRadius: BorderRadius.circular(15*fem),
                                                  ),
                                                  child: Text(
                                                    'John ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff949a92),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // frame23Wam (5:50482)
                                            width: 172*fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // lastnameFoF (5:50483)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Last name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group19BB7 (5:50484)
                                                  padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                                  width: double.infinity,
                                                  decoration: BoxDecoration (
                                                    border: Border.all(color: Color(0xffebdfd7)),
                                                    color: Color(0xfffff7f1),
                                                    borderRadius: BorderRadius.circular(15*fem),
                                                  ),
                                                  child: Text(
                                                    'Doe',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff949a92),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 24*fem,
                                    ),
                                    Container(
                                      // frame242hX (5:50487)
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // emailaddressnRo (5:50488)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Email address',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // group19Jf3 (5:50489)
                                            padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0xffebdfd7)),
                                              color: Color(0xfffff7f1),
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Text(
                                              'samplemail@mail.com',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff949a92),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 24*fem,
                                    ),
                                    Container(
                                      // frame25N97 (5:50501)
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // phonenumber7sP (5:50493)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Phone number',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // group20qYV (5:50500)
                                            padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0xffebdfd7)),
                                              color: Color(0xfffff7f1),
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Text(
                                              '+1',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff949a92),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 24*fem,
                                    ),
                                    Container(
                                      // frame26i6V (5:50502)
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // password5Bw (5:50503)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Password',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // group20bg5 (5:50504)
                                            padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0xffebdfd7)),
                                              color: Color(0xfffff7f1),
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // 7eR (5:50506)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 262*fem, 0*fem),
                                                  child: Text(
                                                    '*********',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff949a92),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // iconsecurityeye32H (5:50507)
                                                  width: 16*fem,
                                                  height: 16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-security-eye.png',
                                                    width: 16*fem,
                                                    height: 16*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 24*fem,
                                    ),
                                    Container(
                                      // frame27Yjj (5:50523)
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // confirmpasswordJiu (5:50524)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Confirm password',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // group20qTw (5:50525)
                                            padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0xffebdfd7)),
                                              color: Color(0xfffff7f1),
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // kqo (5:50528)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 262*fem, 0*fem),
                                                  child: Text(
                                                    '*********',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xff949a92),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // iconsecurityeyegUZ (5:50527)
                                                  width: 16*fem,
                                                  height: 16*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-security-eye-2nm.png',
                                                    width: 16*fem,
                                                    height: 16*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group22ct1 (5:50546)
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(6*fem),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // rectangle8wQV (5:50536)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                      width: 20*fem,
                                      height: 20*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(6*fem),
                                        border: Border.all(color: Color(0xffd9d9d9)),
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                    Container(
                                      // bycontinuingimagreewithtermsco (5:50537)
                                      constraints: BoxConstraints (
                                        maxWidth: 323*fem,
                                      ),
                                      child: RichText(
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'By continuing I’m agree with ',
                                            ),
                                            TextSpan(
                                              text: 'Terms & Conditions',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                decoration: TextDecoration.underline,
                                                color: Color(0xff11a0af),
                                                decorationColor: Color(0xff11a0af),
                                              ),
                                            ),
                                            TextSpan(
                                              text: ' and ',
                                            ),
                                            TextSpan(
                                              text: 'Privacy Policies',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                decoration: TextDecoration.underline,
                                                color: Color(0xff11a0af),
                                                decorationColor: Color(0xff11a0af),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 32*fem,
                        ),
                        TextButton(
                          // group24HPo (5:50550)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: double.infinity,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Container(
                              // group23RW1 (5:50549)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xff11a0af),
                                borderRadius: BorderRadius.circular(100*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Sign up',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 32*fem,
                        ),
                        TextButton(
                          // alreadyhaveanaccountloginug5 (5:50551)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Already have an account?',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                                TextSpan(
                                  text: ' ',
                                ),
                                TextSpan(
                                  text: 'Login',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    decoration: TextDecoration.underline,
                                    color: Color(0xff11a0af),
                                    decorationColor: Color(0xff11a0af),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 32*fem,
                        ),
                        TextButton(
                          // alreadyhaveanaccountloginbBX (99:2879)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Already have an account?',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                                TextSpan(
                                  text: ' ',
                                ),
                                TextSpan(
                                  text: 'Login',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    decoration: TextDecoration.underline,
                                    color: Color(0xff11a0af),
                                    decorationColor: Color(0xff11a0af),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}