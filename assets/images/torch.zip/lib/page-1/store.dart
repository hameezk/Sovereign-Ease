import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // store6Sd (40:1584)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupcdwobuB (9zsUajsM98E2V2Tn7hCdwo)
              left: 0*fem,
              top: 132*fem,
              child: Container(
                width: 934*fem,
                height: 2233*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group10000042007sX (106:3138)
                      left: 14*fem,
                      top: 0*fem,
                      child: Container(
                        width: 920*fem,
                        height: 2233*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // group2081w (106:3139)
                              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 16*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 364*fem,
                                  height: 45*fem,
                                  child: Container(
                                    // group43E4y (106:3140)
                                    padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 15*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1e1e1e),
                                      borderRadius: BorderRadius.circular(15*fem),
                                    ),
                                    child: Container(
                                      // frame52kZ7 (106:3142)
                                      width: 109*fem,
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // iconsearchsearchnormal6N5 (106:3143)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                            width: 16*fem,
                                            height: 16*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/icon-search-search-normal-xHw.png',
                                              width: 16*fem,
                                              height: 16*fem,
                                            ),
                                          ),
                                          Text(
                                            // searchhereziM (106:3144)
                                            'Search here',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1*ffem/fem,
                                              color: Color(0x7fffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // frame1000004207WRo (106:3145)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group1000004193EMo (106:3146)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                    padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                                    width: 364*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                      gradient: LinearGradient (
                                        begin: Alignment(0, -1),
                                        end: Alignment(0, 1),
                                        colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                        stops: <double>[0, 1],
                                      ),
                                      image: DecorationImage (
                                        image: AssetImage (
                                          'assets/page-1/images/rectangle-6827-bg-2c1.png',
                                        ),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // trendycollectionr8H (106:3148)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                          child: Text(
                                            'Trendy collection',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 22*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 0.7272727273*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group1000004192Maq (106:3149)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                          width: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // shopnowHzH (106:3150)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: Text(
                                                  'Shop now',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // iconarrowarrowrightCrM (106:3151)
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-arrow-arrow-right-3S9.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame1000004196wJ9 (106:3153)
                                    width: double.infinity,
                                    height: 274*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame1000004198gFj (106:3154)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group100000419524h (106:3155)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-fyb.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17hwX (106:3157)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarbGD (106:3158)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-EFb.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // 5hB (106:3159)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197QzM (106:3160)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196xW5 (106:3161)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtJK3 (106:3162)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // RPf (106:3163)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23NZo (106:3164)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004199apH (106:3165)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195ifb (106:3166)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-A2d.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17QoK (106:3168)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstaruEH (106:3169)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-Znh.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // Dkm (106:3170)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197Zpd (106:3171)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196iSd (106:3172)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtebB (106:3173)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // B5K (106:3174)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara237zZ (106:3175)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004200et1 (106:3176)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group10000041951Cm (106:3177)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-nCR.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17hLV (106:3179)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarPj7 (106:3180)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-Ziq.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // K6y (106:3181)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197TU5 (106:3182)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196onq (106:3183)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtLXs (106:3184)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // eoT (106:3185)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23oRT (106:3186)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004201wRB (106:3187)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195tbK (106:3188)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-qDb.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17BaR (106:3190)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstargGH (106:3191)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-LoK.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // nq7 (106:3192)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197jkM (106:3193)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196657 (106:3194)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtQLh (106:3195)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // 81o (106:3196)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara234g9 (106:3197)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004202yRj (106:3198)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195uqB (106:3199)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-Cmf.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17bi1 (106:3201)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarhFF (106:3202)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-Yoj.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // 22d (106:3203)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197AuX (106:3204)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196XEH (106:3205)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirt4k1 (106:3206)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // C5X (106:3207)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23YQH (106:3208)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004203HmB (106:3209)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195ERX (106:3210)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-AAV.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17817 (106:3212)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66ffffff),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarQjK (106:3213)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-bAh.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // izu (106:3214)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197sso (106:3215)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196q3w (106:3216)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtmiH (106:3217)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xffffffff),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // JTK (106:3218)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23f2y (106:3219)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7fffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame1000004206p4H (106:3295)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group10000041949cM (106:3296)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                    padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                                    width: 364*fem,
                                    height: 386*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                      gradient: LinearGradient (
                                        begin: Alignment(0, -1),
                                        end: Alignment(0, 1),
                                        colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                        stops: <double>[0, 1],
                                      ),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/rectangle-6827-bg-or1.png',
                                        ),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // popularoutfitsNED (106:3298)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                          child: Text(
                                            'Popular outfits',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 22*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 0.7272727273*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group1000004192VJq (106:3299)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                          width: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // shopnowRiH (106:3300)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: Text(
                                                  'Shop now',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // iconarrowarrowrightwgd (106:3301)
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-arrow-arrow-right-Ttd.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame10000041965Xw (106:3303)
                                    width: double.infinity,
                                    height: 274*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame1000004198R61 (106:3304)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195kty (106:3305)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-6Sd.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17eDf (106:3307)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarXHT (106:3308)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-h7o.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // Rtd (106:3309)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197mhb (106:3310)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196icq (106:3311)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirteWV (106:3312)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // mLD (106:3313)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara237us (106:3314)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004199Feh (106:3315)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195oRK (106:3316)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-Fnh.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame176fK (106:3318)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarCCZ (106:3319)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-5i1.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // Wj3 (106:3320)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197fbw (106:3321)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196oi9 (106:3322)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtYfj (106:3323)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // UJV (106:3324)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23RUd (106:3325)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004200MFo (106:3326)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group10000041956z5 (106:3327)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-JPK.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17yny (106:3329)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarGn5 (106:3330)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-osF.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // nEd (106:3331)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197vbj (106:3332)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196U7T (106:3333)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtQWu (106:3334)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // vk9 (106:3335)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara235d3 (106:3336)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004201DMs (106:3337)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195Miy (106:3338)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-2a5.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17ei5 (106:3340)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstar8dF (106:3341)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-N4R.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // eLh (106:3342)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197zQZ (106:3343)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196XvH (106:3344)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtg2V (106:3345)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // Bjw (106:3346)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23YKb (106:3347)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004202gKK (106:3348)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195Rnh (106:3349)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-RAR.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17vjT (106:3351)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstar1W1 (106:3352)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-7Ld.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // 84q (106:3353)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame10000041975Ey (106:3354)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196Dry (106:3355)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtm7o (106:3356)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // VZb (106:3357)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23F2y (106:3358)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004203NWu (106:3359)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195iqf (106:3360)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-R69.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17DXX (106:3362)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstar6bK (106:3363)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-JyP.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // cJm (106:3364)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197A5P (106:3365)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196WQ9 (106:3366)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtSob (106:3367)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // y2q (106:3368)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23X4M (106:3369)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame1000004208sGd (106:3220)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group1000004193D5b (106:3221)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                    padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                                    width: 364*fem,
                                    height: 386*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                      gradient: LinearGradient (
                                        begin: Alignment(0, -1),
                                        end: Alignment(0, 1),
                                        colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                        stops: <double>[0, 1],
                                      ),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/rectangle-6827-bg-EP3.png',
                                        ),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // trendycollectionF2H (106:3223)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                          child: Text(
                                            'Trendy collection',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 22*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 0.7272727273*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group1000004192N6u (106:3224)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                          width: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // shopnow6Yh (106:3225)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: Text(
                                                  'Shop now',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // iconarrowarrowright2SM (106:3226)
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-arrow-arrow-right-WaV.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame1000004196xau (106:3228)
                                    width: double.infinity,
                                    height: 274*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame1000004198hHb (106:3229)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group10000041952qf (106:3230)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-R4D.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17iiV (106:3232)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstar1Sh (106:3233)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-JRo.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // iru (106:3234)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197GdX (106:3235)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame10000041961LD (106:3236)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtwDs (106:3237)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // 43b (106:3238)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23c57 (106:3239)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004199LQR (106:3240)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195gjB (106:3241)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-AQy.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17NM7 (106:3243)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstar4Uq (106:3244)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-4S5.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // aCH (106:3245)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame10000041977xu (106:3246)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196sBP (106:3247)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtoKw (106:3248)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // Kp5 (106:3249)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23gPj (106:3250)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004200QU9 (106:3251)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195wys (106:3252)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-U9F.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17dbo (106:3254)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarW9o (106:3255)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-9bF.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // 1cM (106:3256)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197ZNy (106:3257)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame1000004196WJD (106:3258)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtEV7 (106:3259)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // xAD (106:3260)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23hdb (106:3261)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004201Rxu (106:3262)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195P93 (106:3263)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-3Y5.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame17gP3 (106:3265)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarHNq (106:3266)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-g6V.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // CVo (106:3267)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197Lru (106:3268)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame100000419665P (106:3269)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtEBb (106:3270)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // 93f (106:3271)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara235xu (106:3272)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004202FF7 (106:3273)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195CRF (106:3274)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-Cuo.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame176mX (106:3276)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarbiH (106:3277)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-54d.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // uiy (106:3278)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197G3j (106:3279)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame10000041961X7 (106:3280)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirtYX3 (106:3281)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // 51B (106:3282)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara231vR (106:3283)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16*fem,
                                        ),
                                        Container(
                                          // frame1000004203Z4m (106:3284)
                                          width: 140*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group1000004195WEu (106:3285)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                                width: double.infinity,
                                                height: 190*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-7-bg-cxR.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // frame171SZ (106:3287)
                                                  padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                                  width: 34*fem,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: ClipRect(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur (
                                                        sigmaX: 7*fem,
                                                        sigmaY: 7*fem,
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // iconsupportlikequestionstarJwT (106:3288)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                            width: 8*fem,
                                                            height: 8*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/icon-support-like-question-star-dR3.png',
                                                              width: 8*fem,
                                                              height: 8*fem,
                                                            ),
                                                          ),
                                                          Text(
                                                            // RWH (106:3289)
                                                            '4.2',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 10*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.2*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame1000004197mKF (106:3290)
                                                width: 81*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // frame10000041967e1 (106:3291)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                      width: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // funkytshirt4JM (106:3292)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            child: Text(
                                                              'Funky T Shirt',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 14*ffem,
                                                                fontWeight: FontWeight.w500,
                                                                height: 1.1428571429*ffem/fem,
                                                                color: Color(0xff000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // Npq (106:3293)
                                                            '\$150',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 0.8888888889*ffem/fem,
                                                              color: Color(0xff000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    RichText(
                                                      // byzara23JCh (106:3294)
                                                      text: TextSpan(
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.3333333333*ffem/fem,
                                                          color: Color(0x7f000000),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                            text: 'by ',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Zara23',
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.3333333333*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // footerrdX (40:1585)
                      left: 0*fem,
                      top: 637*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(24*fem, 0*fem, 25*fem, 0*fem),
                        width: 393*fem,
                        height: 83*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff191919)),
                          color: Color(0xff010101),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // iconessentialhome2jBX (40:1588)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-essential-home-2-3PF.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // autogrouptayqox5 (9zsYZxZQtz53Z6ZUr9taYq)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                              width: 44*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/auto-group-tayq.png',
                                width: 44*fem,
                                height: 40*fem,
                              ),
                            ),
                            Container(
                              // group11j53 (40:1590)
                              margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                              width: 44*fem,
                              height: 44*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-11-78d.png',
                                width: 44*fem,
                                height: 44*fem,
                              ),
                            ),
                            Container(
                              // iconnotificationnotificationdw (40:1589)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-notification-notification-va5.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // ellipse1vQR (40:1594)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(12*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-1-bg-6wb.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // blackstatusbaroz1 (45:3342)
              left: 36*fem,
              top: 15*fem,
              child: Container(
                width: 341.66*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeiLH (I45:3357;727:363)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: -0.2800000012*fem,
                            color: Color(0xffffffff),
                          ),
                          children: [
                            TextSpan(
                              text: '9:4',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: '1',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // groupQsK (45:3343)
                      margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cellularconnectionjub (45:3352)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/cellular-connection-JBT.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // wifi4BB (45:3348)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                            width: 15.33*fem,
                            height: 11*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-ZeR.png',
                              width: 15.33*fem,
                              height: 11*fem,
                            ),
                          ),
                          Container(
                            // batteryAk1 (45:3344)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-pk1.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group1000004190gCZ (106:3370)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16.35*fem, 15*fem, 14*fem, 8*fem),
                width: 393*fem,
                height: 116*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff191919)),
                  color: Color(0xff111111),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // blackstatusbarkCR (106:3383)
                      margin: EdgeInsets.fromLTRB(17.65*fem, 0*fem, 1.34*fem, 21*fem),
                      width: double.infinity,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timesXw (I106:3398;727:363)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1428571429*ffem/fem,
                                  letterSpacing: -0.2800000012*fem,
                                  color: Color(0xffffffff),
                                ),
                                children: [
                                  TextSpan(
                                    text: '9:4',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                  TextSpan(
                                    text: '1',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // groupzW5 (106:3384)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // cellularconnection8cH (106:3393)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/cellular-connection-dhT.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                Container(
                                  // wifiroB (106:3389)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                  width: 15.33*fem,
                                  height: 11*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-Uzu.png',
                                    width: 15.33*fem,
                                    height: 11*fem,
                                  ),
                                ),
                                Container(
                                  // batteryz8h (106:3385)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-swF.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group4hJ1 (106:3377)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                      padding: EdgeInsets.fromLTRB(158.65*fem, 0*fem, 0*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // storep7j (106:3380)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 136*fem, 0*fem),
                            child: Text(
                              'Store',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w700,
                                height: 0.8888888889*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // iconshopshoppingcartjVb (106:3379)
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-shop-shopping-cart-Dqs.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup7tqus61 (9zscLS7iEdncr12mLN7TQu)
                      margin: EdgeInsets.fromLTRB(10.65*fem, 0*fem, 13*fem, 7*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            // womenBcV (106:3373)
                            'Women',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1*ffem/fem,
                              color: Color(0xff12a1af),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // menWem (106:3374)
                            'Men',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7feaeaea),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // unisex3eh (106:3375)
                            'Unisex',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7feaeaea),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // kidsaPj (106:3376)
                            'Kids',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7feaeaea),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}