import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // accountprivacyPXo (154:5331)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // group10vXj (154:5332)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarpd7 (154:5335)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeYp1 (I154:5350;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // group1b7 (154:5336)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnection9SR (154:5345)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-bCm.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifirLq (154:5341)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-cyo.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryNpy (154:5337)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-PTF.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupcra15jP (9zv477Pfg2isUw492qCRa1)
                    width: 164*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // accountprivacyqCm (154:5334)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 132*fem,
                              height: 16*fem,
                              child: Text(
                                'Account privacy',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 0.8888888889*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group4iXT (154:5351)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4-dm3.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // adjustwhocanseeyourpostsinyour (154:5358)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
              child: Text(
                'Adjust who can see your posts in your account',
                style: SafeGoogleFont (
                  'Urbanist',
                  fontSize: 16*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupgj2yjhT (9zv3cnsXC1YmkZfD9qGj2y)
              padding: EdgeInsets.fromLTRB(16*fem, 24*fem, 17*fem, 376*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame1000004232r1P (154:5359)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    width: double.infinity,
                    height: 56*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame1000004231Anm (154:5360)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // likesWLq (154:5361)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                child: Text(
                                  'Likes',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 18*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 0.8888888889*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Container(
                                // allowyourfriendsfollowerstosee (154:5362)
                                constraints: BoxConstraints (
                                  maxWidth: 213*fem,
                                ),
                                child: Text(
                                  'Allow your friends/ followers to see the post you’ve liked',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0x7fffffff),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // group113vvM (154:5363)
                          margin: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 12*fem),
                          padding: EdgeInsets.fromLTRB(28*fem, 4*fem, 4*fem, 4*fem),
                          width: 56*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff7f8e2e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Align(
                            // ellipse1344DuT (154:5365)
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                              width: double.infinity,
                              height: 24*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(12*fem),
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjsg9x6M (9zv36tZgKGghkMJajVjSg9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    width: double.infinity,
                    height: 56*fem,
                    child: Container(
                      // frame1000004233go3 (154:5366)
                      width: double.infinity,
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame1000004231puF (154:5367)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 0*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // pinsZbw (154:5368)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  child: Text(
                                    'Pins',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 0.8888888889*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // allowyourfriendsfollowerstosee (154:5369)
                                  constraints: BoxConstraints (
                                    maxWidth: 213*fem,
                                  ),
                                  child: Text(
                                    'Allow your friends/ followers to see the post you’ve pinned',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1428571429*ffem/fem,
                                      color: Color(0x7fffffff),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group113nDo (154:5370)
                            margin: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 12*fem),
                            padding: EdgeInsets.fromLTRB(28*fem, 4*fem, 4*fem, 4*fem),
                            width: 56*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff7f8e2e),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Align(
                              // ellipse1344tGq (154:5372)
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                width: double.infinity,
                                height: 24*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(12*fem),
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogroupxupdPjP (9zv3KJNfbeMR9s9hHZxupd)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 86*fem),
                    width: double.infinity,
                    height: 68*fem,
                    child: Container(
                      // frame1000004234vjK (154:5373)
                      width: double.infinity,
                      height: 56*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame1000004231UVw (154:5374)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 0*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // collections21f (154:5375)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  child: Text(
                                    'Collections',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 0.8888888889*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // allowyourfriendsfollowerstosee (154:5376)
                                  constraints: BoxConstraints (
                                    maxWidth: 213*fem,
                                  ),
                                  child: Text(
                                    'Allow your friends/ followers to see the post your collections',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1428571429*ffem/fem,
                                      color: Color(0x7fffffff),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group1133hT (154:5377)
                            margin: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 12*fem),
                            padding: EdgeInsets.fromLTRB(28*fem, 4*fem, 4*fem, 4*fem),
                            width: 56*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff7f8e2e),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Align(
                              // ellipse1344Mi9 (154:5379)
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                width: double.infinity,
                                height: 24*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(12*fem),
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogroupzcoj6Qq (9zv3VNvCwAo1wpXfzQZCoj)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 33*fem, 0*fem),
                    width: double.infinity,
                    height: 16*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}