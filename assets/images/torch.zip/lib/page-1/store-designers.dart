import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // storedesignersXS9 (40:1653)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10EbT (106:3890)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupzvnmimX (9zsdrPb9uDTVPyFJCwzvNM)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 8*fem),
                    width: 392*fem,
                    height: 44*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // blackstatusbare9P (106:3892)
                          left: 36*fem,
                          top: 15*fem,
                          child: Container(
                            width: 341.66*fem,
                            height: 16*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // timexA5 (I106:3907;727:363)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xff0a0a0a),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '9:4',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            letterSpacing: -0.2800000012*fem,
                                            color: Color(0xff0a0a0a),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            letterSpacing: -0.2800000012*fem,
                                            color: Color(0xff0a0a0a),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  // groupaKs (106:3893)
                                  margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // cellularconnectionWjK (106:3902)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 17*fem,
                                        height: 10.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/cellular-connection-Hnq.png',
                                          width: 17*fem,
                                          height: 10.67*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5*fem,
                                      ),
                                      Container(
                                        // wifiDdj (106:3898)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                        width: 15.33*fem,
                                        height: 11*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/wifi-5Jh.png',
                                          width: 15.33*fem,
                                          height: 11*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5*fem,
                                      ),
                                      Container(
                                        // battery7z1 (106:3894)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24.33*fem,
                                        height: 11.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/battery-6Fs.png',
                                          width: 24.33*fem,
                                          height: 11.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // blackstatusbarEoj (45:3360)
                          left: 36*fem,
                          top: 15*fem,
                          child: Container(
                            width: 341.66*fem,
                            height: 16*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // timeN9F (I45:3375;727:363)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '9:4',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            letterSpacing: -0.2800000012*fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '1',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            letterSpacing: -0.2800000012*fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  // groupfnZ (45:3361)
                                  margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // cellularconnection1bX (45:3370)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 17*fem,
                                        height: 10.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/cellular-connection-sJq.png',
                                          width: 17*fem,
                                          height: 10.67*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5*fem,
                                      ),
                                      Container(
                                        // wifiWYH (45:3366)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                        width: 15.33*fem,
                                        height: 11*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/wifi-DGV.png',
                                          width: 15.33*fem,
                                          height: 11*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 5*fem,
                                      ),
                                      Container(
                                        // batteryRQM (45:3362)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24.33*fem,
                                        height: 11.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/battery-XMj.png',
                                          width: 24.33*fem,
                                          height: 11.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4LXK (106:3908)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 14*fem, 0*fem),
                    width: double.infinity,
                    height: 24*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupjn3bGfs (9zseQhze1GAMcA1tQ4jn3B)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 153*fem, 0*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // iconarrowarrowleftofo (106:3911)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-arrow-arrow-left-1zR.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // browsebybrandstSM (106:3912)
                                'Browse by brands',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 0.8888888889*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // iconshopshoppingcartRhB (106:3910)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-shop-shopping-cart-wCD.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame54ZHb (106:3831)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 14*fem, 0*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group43tKs (106:3885)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 15*fem),
                    width: 364*fem,
                    height: 45*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff1e1e1e),
                      borderRadius: BorderRadius.circular(15*fem),
                    ),
                    child: Container(
                      // frame52ayP (106:3887)
                      width: 109*fem,
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // iconsearchsearchnormalvnM (106:3888)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                            width: 16*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-search-search-normal-Wiu.png',
                              width: 16*fem,
                              height: 16*fem,
                            ),
                          ),
                          Text(
                            // searchheredwf (106:3889)
                            'Search here',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7f949a92),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // frame53AAu (106:3832)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                    width: 364*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupwedoERf (9zsczfX1VGAxBVv257Wedo)
                          width: double.infinity,
                          height: 182*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group45way (106:3833)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(27*fem, 66*fem, 26.91*fem, 66*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // zarasvgQDf (106:3835)
                                  child: SizedBox(
                                    width: 120.09*fem,
                                    height: 50*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/zara-svg.png',
                                      width: 120.09*fem,
                                      height: 50*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group44vSu (106:3838)
                                padding: EdgeInsets.fromLTRB(26*fem, 66*fem, 26.02*fem, 66*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // levissvgQss (106:3840)
                                  child: SizedBox(
                                    width: 121.98*fem,
                                    height: 50*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/levis-svg.png',
                                      width: 121.98*fem,
                                      height: 50*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // autogrouphn41v5X (9zsd8k7t1mrAjYcActhN41)
                          width: double.infinity,
                          height: 182*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group46fYu (106:3843)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(42.1*fem, 60.97*fem, 41.2*fem, 60.84*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // hmsvgkaM (106:3845)
                                  child: SizedBox(
                                    width: 90.7*fem,
                                    height: 60.19*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/hm-svg.png',
                                      width: 90.7*fem,
                                      height: 60.19*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group47H4V (106:3849)
                                padding: EdgeInsets.fromLTRB(10*fem, 71*fem, 10.15*fem, 71*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // snitchpngzUh (106:3851)
                                  child: SizedBox(
                                    width: 153.85*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/snitch-png.png',
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // autogroupj5z1JkH (9zsdFzQohhNZMTr3wEJ5z1)
                          width: double.infinity,
                          height: 182*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group48rG1 (106:3852)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(23*fem, 81*fem, 23.34*fem, 81*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // pradasvgY8q (106:3854)
                                  child: SizedBox(
                                    width: 127.66*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/prada-svg.png',
                                      width: 127.66*fem,
                                      height: 20*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group50sB7 (106:3857)
                                padding: EdgeInsets.fromLTRB(56*fem, 60.84*fem, 56*fem, 61.16*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // louisvuittonsvga5X (106:3859)
                                  child: SizedBox(
                                    width: 62*fem,
                                    height: 60*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/louis-vuitton-svg.png',
                                      width: 62*fem,
                                      height: 60*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // autogrouplqmpt6D (9zsdP9sY7AHGNy97L2LQmP)
                          width: double.infinity,
                          height: 182*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group51dZb (106:3861)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(23*fem, 81.05*fem, 23.36*fem, 81*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // chanelsvg7zZ (106:3863)
                                  child: SizedBox(
                                    width: 127.65*fem,
                                    height: 19.95*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/chanel-svg.png',
                                      width: 127.65*fem,
                                      height: 19.95*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group49T2q (106:3879)
                                padding: EdgeInsets.fromLTRB(16*fem, 71*fem, 15.13*fem, 71*fem),
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x3f090909),
                                      offset: Offset(0*fem, 10*fem),
                                      blurRadius: 7.5*fem,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  // diorsvgAT3 (106:3881)
                                  child: SizedBox(
                                    width: 142.87*fem,
                                    height: 40*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/dior-svg.png',
                                      width: 142.87*fem,
                                      height: 40*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}