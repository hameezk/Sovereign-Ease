import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // viewpost43b (110:4676)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10MoP (110:4710)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarSZw (110:4713)
                    margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeZeZ (I110:4728;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupyrh (110:4714)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionv1F (110:4723)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-vcy.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiRyb (110:4719)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-kQy.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batterykW5 (110:4715)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-zwK.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupyejbs4u (9zurPSvA5YYVx5ZqvryejB)
                    width: 69*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // posts1S1 (110:4712)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 16*fem,
                              child: Text(
                                'Posts',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group46iM (110:4729)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4-ZpM.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame1000004217cAu (144:2235)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group10000042069Rj (144:2236)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group5fey (144:2237)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 8*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.25*fem, 0*fem),
                          width: double.infinity,
                          height: 30*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame10nDo (144:2238)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 177.25*fem, 0*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse4XBP (144:2239)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-4-bg-GwT.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // profilenameherepgH (144:2240)
                                      'Profile name here',
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // dots1AEM (144:2241)
                                width: 19.5*fem,
                                height: 4.5*fem,
                                child: Image.asset(
                                  'assets/page-1/images/dots-1-69X.png',
                                  width: 19.5*fem,
                                  height: 4.5*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame1000004206tRF (144:2245)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group7Ek1 (144:2246)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(346*fem, 16*fem, 16*fem, 16*fem),
                                width: double.infinity,
                                height: 550*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-5-bg-5Q5.png',
                                    ),
                                  ),
                                ),
                                child: ClipRect(
                                  // frame11w8d (144:2248)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 2*fem,
                                      sigmaY: 2*fem,
                                    ),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 498*fem),
                                      width: double.infinity,
                                      height: 20*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xccffffff),
                                        borderRadius: BorderRadius.circular(5*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '1/5',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group6PmK (144:2250)
                                margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                                width: double.infinity,
                                height: 20*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame12Kus (144:2251)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.73*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(2.08*fem, 0*fem, 0*fem, 0*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // trendingtopic1r97 (144:2252)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18.08*fem, 0*fem),
                                            width: 15.84*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/trending-topic-1-ga5.png',
                                              width: 15.84*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                          Container(
                                            // messageAQh (144:2254)
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/message-dr9.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // frame66ZF (144:2256)
                                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 93.9*fem, 1.5*fem),
                                      padding: EdgeInsets.fromLTRB(10*fem, 6*fem, 9.87*fem, 6*fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xfff5f5f5),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // xmlid289nS5 (144:2257)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid289-qgV.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid2876Bs (144:2258)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid287-m29.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid291pNm (144:2259)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-yMT.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid2919fw (144:2260)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-Spy.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid291Hn9 (144:2261)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-G8y.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // frame12qYm (144:2262)
                                      padding: EdgeInsets.fromLTRB(3.14*fem, 0*fem, 0*fem, 0*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // bookmarkwER (144:2263)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19.14*fem, 0*fem),
                                            width: 13.72*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/bookmark-L25.png',
                                              width: 13.72*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                          Container(
                                            // layers1EzD (144:2265)
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/layers-1-qfX.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame1000004216BPf (144:2269)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004210Wgq (144:2270)
                          width: double.infinity,
                          height: 34*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ellipse13534iM (144:2271)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                width: 30*fem,
                                height: 30*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(15*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-1353-bg-mxV.png',
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group1000004209yaR (144:2272)
                                padding: EdgeInsets.fromLTRB(16*fem, 9*fem, 16*fem, 9*fem),
                                width: 319*fem,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xff1e1e1e),
                                  borderRadius: BorderRadius.circular(15*fem),
                                ),
                                child: Text(
                                  'Add a comment',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff949a92),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupo9xmRxD (9zusC6F6zX4nDGvYuZo9xm)
                          padding: EdgeInsets.fromLTRB(0*fem, 24*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // frame10000042099NR (144:2275)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 185*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353UQh (144:2276)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-aBB.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208CLh (144:2277)
                                      width: 134*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215k7K (144:2278)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnameH7F (144:2279)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hPg5 (144:2280)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // looksdelidelicious8tZ (144:2281)
                                            'Looks delidelicious!! 😋',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004210eM7 (144:2282)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353yPP (144:2283)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-Tv1.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group10000042085xD (144:2284)
                                      width: 304*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215diq (144:2285)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 204*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnameyGu (144:2286)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // h66d (144:2287)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // nihilnonaliquidutrerumvelitdol (144:2288)
                                            'Nihil non aliquid ut rerum velit dolorem illum est at.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004211Kk5 (144:2289)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 138*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353T5b (144:2290)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-tHf.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208mMB (144:2291)
                                      width: 181*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame10000042157A9 (144:2292)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnamer7j (144:2293)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hmEh (144:2294)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // evenietquianumquamsintinurh (144:2295)
                                            'Eveniet quia numquam sint in.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004212qkM (144:2296)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353BJR (144:2297)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-2Mw.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208tid (144:2298)
                                      width: 239*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215EnV (144:2299)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 139*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnameNdo (144:2300)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hJ1f (144:2301)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // mollitiaconsequaturaperiamtemp (144:2302)
                                            'Mollitia consequatur aperiam tempora.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004213NXK (144:2303)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 140*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353uXF (144:2304)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-Kc5.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208qA1 (144:2305)
                                      width: 179*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215nb3 (144:2306)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personname897 (144:2307)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hr57 (144:2308)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // voluptatemetveritatisullambYV (144:2309)
                                            'Voluptatem et veritatis ullam.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Opacity(
                                // frame1000004214id7 (144:2310)
                                opacity: 0,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 140*fem, 0*fem),
                                  width: double.infinity,
                                  height: 36*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse1353S3K (144:2311)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                        width: 30*fem,
                                        height: 30*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(15*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-1353-bg-Ffo.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group1000004208Z7w (144:2312)
                                        width: 179*fem,
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004215W3B (144:2313)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79*fem, 4*fem),
                                              width: double.infinity,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // personnameEjs (144:2314)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                    child: Text(
                                                      'Person name',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // hMpV (144:2315)
                                                    '1h',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff9e9e9e),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Text(
                                              // voluptatemetveritatisullam7Hs (144:2316)
                                              'Voluptatem et veritatis ullam.',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}