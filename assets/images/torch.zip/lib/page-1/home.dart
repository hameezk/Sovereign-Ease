import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homedBf (14:96)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // group28tWu (17:550)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 0*fem, 16*fem),
              width: 580*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffecdfd7)),
                color: Color(0xfffffbf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // blackstatusbariF3 (14:158)
                    margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 202.34*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeCg1 (I14:173;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // group2aV (14:159)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnection9f7 (14:168)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-cJM.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiFTF (14:164)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batterymgV (14:160)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4Gt9 (14:174)
                    margin: EdgeInsets.fromLTRB(152*fem, 0*fem, 201*fem, 16*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // torchQUZ (14:175)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 133.52*fem, 0.9*fem),
                          width: 53.48*fem,
                          height: 15.38*fem,
                          child: Image.asset(
                            'assets/page-1/images/torch.png',
                            width: 53.48*fem,
                            height: 15.38*fem,
                          ),
                        ),
                        TextButton(
                          // iconsearchsearchnormalj13 (14:176)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-search-search-normal.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame3p2V (14:178)
                    width: double.infinity,
                    height: 84*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame2jQM (14:179)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group1U73 (14:180)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(39*fem, 42*fem, 3*fem, 0*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(30*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-2-bg.png',
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      // group27A1 (14:182)
                                      alignment: Alignment.bottomRight,
                                      child: SizedBox(
                                        width: 18*fem,
                                        height: 18*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group-2.png',
                                          width: 18*fem,
                                          height: 18*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // addstoryRAh (14:185)
                                'Add story',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame37pD (14:186)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group1TNH (14:187)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3w2Z (14:189)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-GP3.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // nicklaus3bP (14:190)
                                'Nicklaus',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame4xyF (14:191)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group17LM (14:192)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(30*fem),
                                  border: Border (
                                  ),
                                ),
                                child: Center(
                                  // ellipse3dJh (14:194)
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 56*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(28*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-3-bg-St1.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // cathyYgZ (14:195)
                                'Cathy',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame5H8M (14:196)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group12bj (14:197)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(30*fem),
                                  border: Border (
                                  ),
                                ),
                                child: Center(
                                  // ellipse3Jp9 (14:199)
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 56*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(28*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-3-bg-bJH.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // kaileyDw7 (14:200)
                                'Kailey',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame69Zs (14:201)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group1JSm (14:202)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(30*fem),
                                  border: Border (
                                  ),
                                ),
                                child: Center(
                                  // ellipse3Co3 (14:204)
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 56*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(28*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-3-bg-wfX.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // tiarauhT (14:205)
                                'Tiara',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame732y (14:206)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group1b4V (14:207)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(30*fem),
                                  border: Border (
                                  ),
                                ),
                                child: Center(
                                  // ellipse3h7X (14:209)
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 56*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(28*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-3-bg.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // quincyowF (14:210)
                                'Quincy',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 24*fem,
                        ),
                        Container(
                          // frame89ER (14:211)
                          width: 60*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group16QZ (14:212)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(30*fem),
                                  border: Border (
                                  ),
                                ),
                                child: Center(
                                  // ellipse3opm (14:214)
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 56*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(28*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-3-bg-SX3.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // daynejiR (14:215)
                                'Dayne',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupfhrr5nH (9zrKzVAAYiZr1Bp2X8fhrR)
              width: double.infinity,
              height: 1236*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame28DNh (17:492)
                    left: 15*fem,
                    top: 0*fem,
                    child: Container(
                      width: 364*fem,
                      height: 1236*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // frame29vY1 (17:493)
                            width: 182*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // frame28Grm (17:396)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 182*fem,
                                      height: 228*fem,
                                      child: Container(
                                        // group26CEd (17:392)
                                        width: double.infinity,
                                        height: 200*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // group25jkM (17:389)
                                              left: 16.0007629395*fem,
                                              top: 2.9991455078*fem,
                                              child: Container(
                                                width: 166*fem,
                                                height: 187*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      // group15esK (17:387)
                                                      left: 47.9943847656*fem,
                                                      top: 17.5886230469*fem,
                                                      child: Container(
                                                        width: 118*fem,
                                                        height: 149.7*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5ZjP (17:388)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 149.7*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-7QV.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group14fnR (17:385)
                                                      left: 20.5866699219*fem,
                                                      top: 10.9829101562*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                        width: 139.69*fem,
                                                        height: 170.3*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5BEy (17:386)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 169.92*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-EXK.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group13673 (17:383)
                                                      left: 0*fem,
                                                      top: 0*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                        width: 153.32*fem,
                                                        height: 187*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5Q7j (17:384)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 186.78*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-zPs.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // group12u4V (17:381)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 156*fem,
                                                height: 200*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Center(
                                                  // rectangle5E6m (17:382)
                                                  child: SizedBox(
                                                    width: double.infinity,
                                                    height: 200*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                        color: Color(0xffd9d9d9),
                                                        image: DecorationImage (
                                                          fit: BoxFit.cover,
                                                          image: AssetImage (
                                                            'assets/page-1/images/rectangle-5-bg-deZ.png',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame30wms (17:420)
                                  left: 0*fem,
                                  top: 216*fem,
                                  child: Container(
                                    width: 174*fem,
                                    height: 268*fem,
                                    child: Container(
                                      // group26V2h (17:421)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                      width: double.infinity,
                                      height: 240*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Container(
                                        // group121Fw (17:422)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Center(
                                          // rectangle5xgy (17:423)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 240*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffd9d9d9),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame32UQR (17:453)
                                  left: 0*fem,
                                  top: 472*fem,
                                  child: Container(
                                    width: 174*fem,
                                    height: 764*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26bjw (17:454)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: 166*fem,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group128E5 (17:455)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5VKX (17:456)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-wKw.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogroupc1pfCUq (9zrLoJ9W2cKVTD4PLvc1PF)
                                          width: double.infinity,
                                          height: 516*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // frame30jjf (17:518)
                                                left: 0*fem,
                                                top: 0*fem,
                                                child: Container(
                                                  width: 174*fem,
                                                  height: 268*fem,
                                                  child: Container(
                                                    // group26HFP (17:519)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                    width: double.infinity,
                                                    height: 240*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Container(
                                                      // group12pFK (17:520)
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5BLm (17:521)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 240*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-kzV.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // frame316s3 (17:534)
                                                left: 0*fem,
                                                top: 248*fem,
                                                child: Container(
                                                  width: 174*fem,
                                                  height: 268*fem,
                                                  child: Container(
                                                    // group26e7s (17:535)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                    width: double.infinity,
                                                    height: 240*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Container(
                                                      // group12NpZ (17:536)
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5LWV (17:537)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 240*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-nC1.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame294Bb (17:494)
                            width: 182*fem,
                            height: 956*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // frame29oey (17:397)
                                  left: 16*fem,
                                  top: 0*fem,
                                  child: Container(
                                    width: 166*fem,
                                    height: 268*fem,
                                    child: Container(
                                      // group26MAh (17:398)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                      width: double.infinity,
                                      height: 240*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Container(
                                        // group12tAd (17:406)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Center(
                                          // rectangle53ZK (17:407)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 240*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffd9d9d9),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg-ZkD.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame319sF (17:436)
                                  left: 8*fem,
                                  top: 256*fem,
                                  child: Container(
                                    width: 174*fem,
                                    height: 268*fem,
                                    child: Container(
                                      // group26gMP (17:437)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                      width: double.infinity,
                                      height: 240*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Container(
                                        // group12d1j (17:438)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Center(
                                          // rectangle5z7B (17:439)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 240*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffd9d9d9),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg-UvV.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame33J7s (17:469)
                                  left: 0*fem,
                                  top: 512*fem,
                                  child: Container(
                                    width: 182*fem,
                                    height: 228*fem,
                                    child: Container(
                                      // group26q7o (17:470)
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group25ZpV (17:471)
                                            left: 16.0007629395*fem,
                                            top: 2.9990844727*fem,
                                            child: Container(
                                              width: 166*fem,
                                              height: 187*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // group155nq (17:472)
                                                    left: 47.9943771362*fem,
                                                    top: 17.588684082*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                      width: 118*fem,
                                                      height: 149.7*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5zeu (17:473)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 149.7*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-rqw.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group14iqo (17:474)
                                                    left: 20.5866699219*fem,
                                                    top: 10.9829101562*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                      width: 139.69*fem,
                                                      height: 170.3*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5dSy (17:475)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 169.92*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-ttZ.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group13MNy (17:476)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                      width: 153.32*fem,
                                                      height: 187*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5Gkq (17:477)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 186.78*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-3tM.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group12C8h (17:478)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 156*fem,
                                              height: 200*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Center(
                                                // rectangle5JxR (17:479)
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 200*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                      color: Color(0xffd9d9d9),
                                                      image: DecorationImage (
                                                        fit: BoxFit.cover,
                                                        image: AssetImage (
                                                          'assets/page-1/images/rectangle-5-bg-bTw.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame34RXF (17:495)
                                  left: 0*fem,
                                  top: 728*fem,
                                  child: Container(
                                    width: 182*fem,
                                    height: 228*fem,
                                    child: Container(
                                      // group26NBb (17:496)
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group25iFT (17:497)
                                            left: 16.0007629395*fem,
                                            top: 2.9990844727*fem,
                                            child: Container(
                                              width: 166*fem,
                                              height: 187*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // group15qL5 (17:498)
                                                    left: 47.9943771362*fem,
                                                    top: 17.5886535645*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                      width: 118*fem,
                                                      height: 149.7*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle59rZ (17:499)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 149.7*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-mLd.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group14fpu (17:500)
                                                    left: 20.5866699219*fem,
                                                    top: 10.9829406738*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                      width: 139.69*fem,
                                                      height: 170.3*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5B2Z (17:501)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 169.92*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-cUq.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group13VJ9 (17:502)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                      width: 153.32*fem,
                                                      height: 187*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5c7s (17:503)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 186.78*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-YrD.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group12Wyw (17:504)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 156*fem,
                                              height: 200*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Center(
                                                // rectangle5TPP (17:505)
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 200*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                      color: Color(0xffd9d9d9),
                                                      image: DecorationImage (
                                                        fit: BoxFit.cover,
                                                        image: AssetImage (
                                                          'assets/page-1/images/rectangle-5-bg-tGR.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // footerycd (14:216)
                    left: 0*fem,
                    top: 561*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(14*fem, 0*fem, 25*fem, 0*fem),
                      width: 393*fem,
                      height: 83*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffe6e6e6)),
                        color: Color(0xffffffff),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupdjadFa9 (9zrNb5VucNt4jcsuctdJad)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                            width: 44*fem,
                            height: 40*fem,
                            child: Image.asset(
                              'assets/page-1/images/auto-group-djad.png',
                              width: 44*fem,
                              height: 40*fem,
                            ),
                          ),
                          Container(
                            // iconshopshopLbb (14:224)
                            margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-shop-shop.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // group11cp1 (14:221)
                            margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 44*fem,
                                height: 44*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-11.png',
                                  width: 44*fem,
                                  height: 44*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // iconnotificationnotification7k (14:220)
                            margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-notification-notification.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // ellipse1QE5 (14:225)
                            margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(12*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-1-bg.png',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}