import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // changepasswordmQm (154:5131)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10Jfb (154:5132)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xfff1f1f1)),
                color: Color(0xfffefaf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarRkD (154:5135)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeLsB (I154:5150;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupoeH (154:5136)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionvyo (154:5145)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-zyP.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifieQ1 (154:5141)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-rRX.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryySH (154:5137)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-YJM.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup5msxgbb (9zuYhTPiZ2HhNbbxGU5MsX)
                    width: 180*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // changepasswordE7K (154:5134)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 148*fem,
                              height: 16*fem,
                              child: Text(
                                'Change password',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 0.8888888889*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group4i2V (154:5151)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4-utd.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9epbd9T (9zuYFy8Bic2opGM7my9EPb)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 376*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame24wR3 (154:5185)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // entercurrentpasswordg7j (154:5186)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                          child: Text(
                            'Enter current password',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // group19BKP (154:5187)
                          padding: EdgeInsets.fromLTRB(329*fem, 14*fem, 16*fem, 14*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffebdfd7)),
                            color: Color(0xfffff7f1),
                            borderRadius: BorderRadius.circular(15*fem),
                          ),
                          child: Align(
                            // iconsecurityeyeVqs (154:5222)
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-security-eye-Xhs.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup51mjDWy (9zuXxox7G5JBbDcubt51mj)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                    width: double.infinity,
                    height: 82*fem,
                    child: Container(
                      // frame25MdB (154:5190)
                      width: double.infinity,
                      height: 68*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // enternewpasswordWFB (154:5191)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            child: Text(
                              'Enter new password',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // group19Rd3 (154:5192)
                            padding: EdgeInsets.fromLTRB(329*fem, 14*fem, 16*fem, 14*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffebdfd7)),
                              color: Color(0xfffff7f1),
                              borderRadius: BorderRadius.circular(15*fem),
                            ),
                            child: Align(
                              // iconsecurityeyeYxZ (154:5210)
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                width: 16*fem,
                                height: 16*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-security-eye-fbw.png',
                                  width: 16*fem,
                                  height: 16*fem,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // frame26H9T (154:5194)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 40*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // confirmnewpasswordRFf (154:5195)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                          child: Text(
                            'Confirm new password',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // group19jn9 (154:5196)
                          padding: EdgeInsets.fromLTRB(329*fem, 14*fem, 16*fem, 14*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffebdfd7)),
                            color: Color(0xfffff7f1),
                            borderRadius: BorderRadius.circular(15*fem),
                          ),
                          child: Align(
                            // iconsecurityeyeffo (154:5216)
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-security-eye-TAH.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group24zTB (154:5200)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 34*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 44*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Container(
                          // group23t2m (154:5201)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff11a0af),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Change password',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupaxehZeh (9zuY7UNLmoHBJ9vqcUAXEH)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 34*fem, 0*fem),
                    width: double.infinity,
                    height: 16*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}