import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // selectimagesRDb (109:4374)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10M7F (109:4418)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarqYD (109:4420)
                    margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timexcq (I109:4435;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupReq (109:4421)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionN4H (109:4430)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-eJM.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifi5zH (109:4426)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-RyK.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryD4u (109:4422)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-N6d.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4vV7 (109:4436)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 244.66*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconarrowarrowleftTjw (109:4438)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-arrow-arrow-left-ibT.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // newpostZ2H (109:4439)
                          'New post',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup5hu5VAq (9zu3cTXLzofSAjtrHz5hU5)
              padding: EdgeInsets.fromLTRB(168*fem, 16*fem, 16*fem, 10.5*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-bg-dqj.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRect(
                    // frame11PX7 (109:4411)
                    child: BackdropFilter(
                      filter: ImageFilter.blur (
                        sigmaX: 2*fem,
                        sigmaY: 2*fem,
                      ),
                      child: Container(
                        margin: EdgeInsets.fromLTRB(178*fem, 0*fem, 0*fem, 337*fem),
                        width: 31*fem,
                        height: 20*fem,
                        decoration: BoxDecoration (
                          color: Color(0xcc000000),
                          borderRadius: BorderRadius.circular(5*fem),
                        ),
                        child: Center(
                          child: Text(
                            '1/5',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // frame6q8D (109:4405)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 150.63*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(10*fem, 6*fem, 9.87*fem, 6*fem),
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f5),
                      borderRadius: BorderRadius.circular(100*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // xmlid289vQZ (109:4406)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid289-7V3.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid2873EH (109:4407)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid287-xG1.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291ydj (109:4408)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291-M6R.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291KBo (109:4409)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291-55j.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291FLM (109:4410)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291-Jqf.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // recentsb9K (109:4377)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupa6edLsb (9zu4G77HGDjzMMAKZva6ed)
                    width: double.infinity,
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004205t8R (109:4391)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-Je5.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircle1D3 (109:4393)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-jey.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004201it9 (109:4388)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-Fhs.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleErV (109:4390)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-Hus.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004202B13 (109:4382)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-ma1.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcirclehVB (109:4384)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-iuf.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004203Rvy (109:4385)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 9*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-tfK.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleYVo (109:4387)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-GEd.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroups3ybGRo (9zu4fG7N9nmmJ7x2DBs3yB)
                    width: double.infinity,
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004204cEm (109:4397)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-Sp1.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleLRf (109:4399)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-tyo.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // rectanglereu (109:4396)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-TC5.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectanglebsP (109:4394)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-zR7.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectanglexT3 (109:4395)
                          width: 99*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-wEy.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupa8jjWjT (9zu4rLdEtpbZD2fuzZA8jj)
                    width: double.infinity,
                    height: 196*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangleFww (109:4378)
                          left: 0*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-p65.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleyN9 (109:4379)
                          left: 98.2613525391*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-yjw.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleuWh (109:4380)
                          left: 196.5227050781*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-Fkm.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangledhb (109:4381)
                          left: 294.7839355469*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-ujo.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleZbF (109:4400)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-hXf.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangletdX (109:4401)
                          left: 98*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-VLM.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleq2y (109:4402)
                          left: 294*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 99*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-kr5.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // videoZzZ (109:4403)
                          left: 255.1773681641*fem,
                          top: 74.5*fem,
                          child: Container(
                            width: 30*fem,
                            height: 13*fem,
                            child: Center(
                              child: Text(
                                '06:23',
                                textAlign: TextAlign.right,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 11*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1818181818*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle1G8H (109:4413)
                          left: 0*fem,
                          top: 49*fem,
                          child: Align(
                            child: SizedBox(
                              width: 393*fem,
                              height: 117*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff191919)),
                                  color: Color(0xff010101),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group24aem (109:4414)
                          left: 16*fem,
                          top: 73*fem,
                          child: Container(
                            width: 361*fem,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Container(
                              // group23vCq (109:4415)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xff11a0af),
                                borderRadius: BorderRadius.circular(100*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Post',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}