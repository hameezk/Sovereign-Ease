import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // newcollectionxoB (40:1342)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Container(
          // frame35gjB (45:3964)
          width: 580*fem,
          height: 1557*fem,
          child: Stack(
            children: [
              Positioned(
                // group281WZ (45:3965)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 0*fem, 16*fem),
                  width: 580*fem,
                  height: 192*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff111111),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // blackstatusbar5mK (45:3968)
                        margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 202.34*fem, 21*fem),
                        width: double.infinity,
                        height: 16*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // time19B (I45:3983;727:363)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                              child: RichText(
                                textAlign: TextAlign.center,
                                text: TextSpan(
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                  children: [
                                    TextSpan(
                                      text: '9:4',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xffd7d7d7),
                                      ),
                                    ),
                                    TextSpan(
                                      text: '1',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xffd7d7d7),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              // groupcoB (45:3969)
                              margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // cellularconnectionYwj (45:3978)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                    width: 17*fem,
                                    height: 10.67*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/cellular-connection-PLD.png',
                                      width: 17*fem,
                                      height: 10.67*fem,
                                    ),
                                  ),
                                  Container(
                                    // wifirhX (45:3974)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                    width: 15.33*fem,
                                    height: 11*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/wifi-XHj.png',
                                      width: 15.33*fem,
                                      height: 11*fem,
                                    ),
                                  ),
                                  Container(
                                    // batterymJh (45:3970)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/battery-9bF.png',
                                      width: 24.33*fem,
                                      height: 11.33*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group4ssX (45:3984)
                        margin: EdgeInsets.fromLTRB(0.35*fem, 0*fem, 201*fem, 16*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // torchR8M (45:3985)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 278.72*fem, 0.9*fem),
                              width: 59.93*fem,
                              height: 15.38*fem,
                              child: Image.asset(
                                'assets/page-1/images/torch-LbT.png',
                                width: 59.93*fem,
                                height: 15.38*fem,
                              ),
                            ),
                            Container(
                              // iconsearchsearchnormal8Hf (45:3986)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-search-search-normal-qz1.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // frame34BK (45:3988)
                        width: double.infinity,
                        height: 84*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // frame2BFw (45:3989)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1XKo (45:3990)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(39*fem, 42*fem, 3*fem, 0*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(30*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-2-bg-rb3.png',
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      // group2DCd (45:3992)
                                      alignment: Alignment.bottomRight,
                                      child: SizedBox(
                                        width: 18*fem,
                                        height: 18*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group-2-kHF.png',
                                          width: 18*fem,
                                          height: 18*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // addstory8qP (45:3995)
                                    'Add story',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame3eoj (45:3996)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1zsb (45:3997)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffd7d7d7),
                                          borderRadius: BorderRadius.circular(30*fem),
                                          border: Border (
                                          ),
                                        ),
                                        child: Center(
                                          // ellipse3fyj (45:3999)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 56*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(28*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/ellipse-3-bg-QmF.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // nicklausCCy (45:4000)
                                    'Nicklaus',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame4ix1 (45:4001)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1GyX (45:4002)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3Bah (45:4004)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-DUD.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // cathyuWh (45:4005)
                                    'Cathy',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame5Rzq (45:4006)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1Zr9 (45:4007)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse35Jh (45:4009)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-5nH.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // kaileyniu (45:4010)
                                    'Kailey',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame6vKK (45:4011)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group14wK (45:4012)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3Nx1 (45:4014)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-8pR.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // tiara7Po (45:4015)
                                    'Tiara',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame7FF7 (45:4016)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1CRF (45:4017)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3Wgq (45:4019)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-zFB.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // quincy3Ay (45:4020)
                                    'Quincy',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame8AFb (45:4021)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1iY1 (45:4022)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3Djf (45:4024)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-kfK.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // dayneYG9 (45:4025)
                                    'Dayne',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // frame28VBP (45:4026)
                left: 15*fem,
                top: 209*fem,
                child: Container(
                  width: 364*fem,
                  height: 1348*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // frame29RKw (45:4027)
                        width: 182*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // frame28NW5 (45:4028)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26vXb (45:4029)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25T1j (45:4030)
                                          left: 16.0007629395*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15aMF (45:4031)
                                                  left: 47.9943847656*fem,
                                                  top: 17.5886230469*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle576H (45:4032)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-MhB.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group14Rcm (45:4033)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5jtM (45:4034)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-wX7.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13ZsP (45:4035)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5Gmo (45:4036)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-vKb.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group12xuX (45:4037)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5hcD (45:4038)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-AuF.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27E6M (45:4039)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame329z1 (45:4044)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 60*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic1JM7 (45:4045)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-P21.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messagebLD (45:4046)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-6jB.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame31ifj (45:4048)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-62V.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        TextButton(
                                          // dots1eZP (45:4040)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/dots-1-GF3.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupkrxfAnd (9zsQiMKEetpz4osq5rKRXf)
                              padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // frame30Vpu (45:4049)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                    width: 174*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26RyT (45:4050)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12mXX (45:4051)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5XFo (45:4052)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-sDs-SRP.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27SNm (45:4053)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame329ny (45:4058)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1hJh (45:4059)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-gkh.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // messageadP (45:4060)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-G2D.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31uQm (45:4062)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-oWy.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots1dbf (45:4054)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-KnH.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame32A5o (45:4063)
                                    width: 174*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogrouppe9xWQZ (9zsR1WVK7RZcHrc3FwPe9X)
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 276*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group262th (45:4064)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: 166*fem,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12y3F (45:4065)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5uxV (45:4066)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-Djo.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group272XK (45:4067)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame32Lnu (45:4072)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic1tJd (45:4073)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-JGZ.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messagen97 (45:4074)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-HiR.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame31W57 (45:4076)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-Ra1.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1qNH (45:4068)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-kmf.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame30mmj (45:4077)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group26usw (45:4078)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group123jF (45:4079)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5oyK (45:4080)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-EYH.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group27KRs (45:4081)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame322r5 (45:4086)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic1ASV (45:4087)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-ASM.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messageFiq (45:4088)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-pFj.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame31PKF (45:4090)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-k97.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1VdB (45:4082)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-3RK.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame31qBF (45:4091)
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group26Bku (45:4092)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12XZs (45:4093)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5How (45:4094)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-br9.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group27Cvu (45:4095)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame32KEq (45:4100)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic1qys (45:4101)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-DTf.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messageYtH (45:4102)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-qnR.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame315NR (45:4104)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-qiq.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1c7T (45:4096)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-EvV.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // frame298rV (45:4105)
                        width: 182*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // autogroup8iu9gd7 (9zsSWYpcexTyKHRUyY8iU9)
                              padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 16*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    // frame29zth (45:4106)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                    width: 166*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26j5b (45:4107)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12FZj (45:4108)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5c9P (45:4109)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-Smf.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27XXF (45:4110)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame32eLy (45:4115)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1nCH (45:4116)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-CZo.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // messagerxq (45:4117)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-tcR.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31nrV (45:4119)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-bah.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots1XJH (45:4111)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-piu.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame31Fzy (45:4120)
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26p2V (45:4121)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12kRw (45:4122)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5upd (45:4123)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-GnD.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27Rny (45:4124)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame32kKT (45:4129)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1tRf (45:4130)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-hYd.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // messageBff (45:4131)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-k9f.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31JkH (45:4133)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-nCy.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots1qER (45:4125)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-Q1P.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame33xK3 (45:4134)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group266RF (45:4135)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25dRB (45:4136)
                                          left: 16.0007629395*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15XmT (45:4137)
                                                  left: 47.9943847656*fem,
                                                  top: 17.5888671875*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5fMs (45:4138)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-iY9.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group14aDw (45:4139)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5HPF (45:4140)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-6do.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13cRX (45:4141)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle58Ps (45:4142)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-Tdj.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group12TS9 (45:4143)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5Bsw (45:4144)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-zCR.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27KDT (45:4145)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame32SJ5 (45:4150)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic1n73 (45:4151)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-d7w.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messageVGM (45:4152)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-Ztu.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame31p3j (45:4154)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-tnV.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // dots1961 (45:4146)
                                          width: 16.25*fem,
                                          height: 3.75*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/dots-1-Pt5.png',
                                            width: 16.25*fem,
                                            height: 3.75*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame34sGu (45:4155)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26E7T (45:4156)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25x3T (45:4157)
                                          left: 16.0007629395*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15UXb (45:4158)
                                                  left: 47.9943847656*fem,
                                                  top: 17.5888671875*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5DEH (45:4159)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-SBj.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group14jCd (45:4160)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5SMw (45:4161)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-x3K.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13Mzh (45:4162)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5si9 (45:4163)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-TuK.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group12znm (45:4164)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5wT7 (45:4165)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-nuF.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27GVP (45:4166)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame32aky (45:4171)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic1XAR (45:4172)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-yWq.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messageDZ3 (45:4173)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-hdT.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame319Sh (45:4175)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-EMF.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // dots1fvq (45:4167)
                                          width: 16.25*fem,
                                          height: 3.75*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/dots-1-fah.png',
                                            width: 16.25*fem,
                                            height: 3.75*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // footeron9 (45:4176)
                left: 0*fem,
                top: 769*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(14*fem, 0*fem, 25*fem, 0*fem),
                  width: 393*fem,
                  height: 83*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff191919)),
                    color: Color(0xff010101),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // autogroupfbybg5F (9zsTfWu2ou6pMDRoD1FbyB)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                        width: 44*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/auto-group-fbyb.png',
                          width: 44*fem,
                          height: 40*fem,
                        ),
                      ),
                      Container(
                        // iconshopshopnty (45:4183)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-shop-shop-7Qd.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // group11fxm (45:4180)
                        margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                        width: 44*fem,
                        height: 44*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-11-KBP.png',
                          width: 44*fem,
                          height: 44*fem,
                        ),
                      ),
                      Container(
                        // iconnotificationnotificationBw (45:4179)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-notification-notification-xTb.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // ellipse1Ghf (45:4184)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(12*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/ellipse-1-bg-sPw.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // rectangle20Mj7 (40:1567)
                left: 0*fem,
                top: 0*fem,
                child: Align(
                  child: SizedBox(
                    width: 393*fem,
                    height: 852*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0x7f000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // group58H6y (40:1569)
                left: 16*fem,
                top: 256*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
                  width: 361*fem,
                  height: 186*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff111111),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupwftfxU1 (9zsTtgBmeQJg6SnM4yWfTF)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // newcollectionHFP (40:1582)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 201*fem, 0*fem),
                              child: Text(
                                'New collection',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            TextButton(
                              // iconessentialcloseBLm (40:1583)
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-essential-close-TzH.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group19tW5 (40:1579)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                        padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 15*fem),
                        width: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xff1e1e1e),
                          borderRadius: BorderRadius.circular(15*fem),
                        ),
                        child: Text(
                          'Collection name',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1*ffem/fem,
                            color: Color(0xff949a92),
                          ),
                        ),
                      ),
                      Container(
                        // autogroupuddsZ6R (9zsTybDFPUbx6oZ6Y5UDDs)
                        width: double.infinity,
                        height: 45*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // group256MF (40:1575)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 157*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                  ),
                                  child: Container(
                                    // group23Qsj (40:1576)
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xff12a1af)),
                                      borderRadius: BorderRadius.circular(8*fem),
                                    ),
                                    child: Center(
                                      child: Text(
                                        'Cancel',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Urbanist',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1*ffem/fem,
                                          color: Color(0xff12a1af),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            TextButton(
                              // group24i7j (40:1571)
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 157*fem,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                ),
                                child: Container(
                                  // group23FdT (40:1572)
                                  width: double.infinity,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff11a0af),
                                    borderRadius: BorderRadius.circular(8*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Save',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}