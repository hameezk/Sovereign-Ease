import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // viewpostRjo (110:4483)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10kn5 (110:4645)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xfff1f1f1)),
                color: Color(0xfffefaf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarSeu (110:4647)
                    margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeAau (I110:4662;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupiuF (110:4648)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionrkZ (110:4657)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-1Kf.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiaAm (110:4653)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-9pV.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryJ6m (110:4649)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-Pc5.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvko31G5 (9zu5njEHCULKecwTprvko3)
                    width: 69*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // postsxBK (110:4674)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 16*fem,
                              child: Text(
                                'Posts',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group4eZw (110:4663)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame1000004217NVw (144:2234)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group1000004206j5b (110:4673)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group5quK (110:4485)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 8*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.25*fem, 0*fem),
                          width: double.infinity,
                          height: 30*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame10LbB (110:4486)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 177.25*fem, 0*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse45Hs (110:4487)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-4-bg.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // profilenameherePJZ (110:4488)
                                      'Profile name here',
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // dots1vJV (110:4489)
                                width: 19.5*fem,
                                height: 4.5*fem,
                                child: Image.asset(
                                  'assets/page-1/images/dots-1-63b.png',
                                  width: 19.5*fem,
                                  height: 4.5*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame10000042063tu (110:4672)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group7bvR (110:4493)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(346*fem, 16*fem, 16*fem, 16*fem),
                                width: double.infinity,
                                height: 550*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-5-bg-ghX.png',
                                    ),
                                  ),
                                ),
                                child: ClipRect(
                                  // frame116cH (110:4495)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 2*fem,
                                      sigmaY: 2*fem,
                                    ),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 498*fem),
                                      width: double.infinity,
                                      height: 20*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xcc000000),
                                        borderRadius: BorderRadius.circular(5*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '1/5',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group6YUH (110:4497)
                                margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                                width: double.infinity,
                                height: 20*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame12fYu (110:4498)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.73*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(2.08*fem, 0*fem, 0*fem, 0*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // trendingtopic1C33 (110:4499)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18.08*fem, 0*fem),
                                            width: 15.84*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/trending-topic-1-og5.png',
                                              width: 15.84*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                          Container(
                                            // messagehEh (110:4501)
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/message-a4q.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // frame62nm (110:4503)
                                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 93.9*fem, 1.5*fem),
                                      padding: EdgeInsets.fromLTRB(10*fem, 6*fem, 9.87*fem, 6*fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xfff5f5f5),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // xmlid289hP7 (110:4504)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid289-JXB.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid2871eh (110:4505)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid287-vHX.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid2919F7 (110:4506)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-Atq.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid2915Pf (110:4507)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-efj.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 4*fem,
                                          ),
                                          Container(
                                            // xmlid291RCd (110:4508)
                                            width: 4.5*fem,
                                            height: 4.5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/xmlid291-BJy.png',
                                              width: 4.5*fem,
                                              height: 4.5*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // frame12N7s (110:4509)
                                      padding: EdgeInsets.fromLTRB(3.14*fem, 0*fem, 0*fem, 0*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // bookmarkK37 (110:4510)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19.14*fem, 0*fem),
                                            width: 13.72*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/bookmark.png',
                                              width: 13.72*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                          Container(
                                            // layers1dZb (110:4512)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/layers-1.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame1000004216MEh (144:2195)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004210gXs (144:2222)
                          width: double.infinity,
                          height: 34*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ellipse1353pty (144:2223)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                width: 30*fem,
                                height: 30*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(15*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-1353-bg.png',
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group1000004209LsK (144:2224)
                                padding: EdgeInsets.fromLTRB(16*fem, 9*fem, 16*fem, 9*fem),
                                width: 319*fem,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffebdfd7)),
                                  color: Color(0xfffff7f1),
                                  borderRadius: BorderRadius.circular(15*fem),
                                ),
                                child: Text(
                                  'Add a comment',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff949a92),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupngokpGh (9zu6a86JrZdN1d7mxQNGoK)
                          padding: EdgeInsets.fromLTRB(0*fem, 24*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // frame1000004209Xwo (144:2187)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 185*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353GPb (144:2186)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-inM.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208av5 (144:2185)
                                      width: 134*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215XqK (144:2184)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnameGnu (144:2181)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hzU1 (144:2183)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // looksdelideliciousjwP (144:2182)
                                            'Looks delidelicious!! 😋',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame10000042103hB (144:2188)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353yaq (144:2189)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-8nm.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208RBw (144:2190)
                                      width: 304*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215kzu (144:2191)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 204*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personname6Yy (144:2192)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hDNh (144:2193)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // nihilnonaliquidutrerumvelitdol (144:2194)
                                            'Nihil non aliquid ut rerum velit dolorem illum est at.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame10000042115pD (144:2196)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 138*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1353D9j (144:2197)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-Mbo.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208KyT (144:2198)
                                      width: 181*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215riV (144:2199)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnamezJu (144:2200)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hJqP (144:2201)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // evenietquianumquamsintinrM7 (144:2202)
                                            'Eveniet quia numquam sint in.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004212a2D (144:2203)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse13536mF (144:2204)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-J8q.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208297 (144:2205)
                                      width: 239*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215yKF (144:2206)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 139*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personnameWKB (144:2207)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hpqf (144:2208)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // mollitiaconsequaturaperiamtemp (144:2209)
                                            'Mollitia consequatur aperiam tempora.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Container(
                                // frame1000004213wJ1 (144:2210)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 140*fem, 0*fem),
                                width: double.infinity,
                                height: 36*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse13534tR (144:2211)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                      width: 30*fem,
                                      height: 30*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-1353-bg-xKK.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // group1000004208Pfo (144:2212)
                                      width: 179*fem,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame1000004215YHo (144:2213)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79*fem, 4*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // personname5Hj (144:2214)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                  child: Text(
                                                    'Person name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // hzvV (144:2215)
                                                  '1h',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1428571429*ffem/fem,
                                                    color: Color(0xff9e9e9e),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // voluptatemetveritatisullamMFF (144:2216)
                                            'Voluptatem et veritatis ullam.',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1428571429*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 24*fem,
                              ),
                              Opacity(
                                // frame10000042144QZ (144:2227)
                                opacity: 0,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 140*fem, 0*fem),
                                  width: double.infinity,
                                  height: 36*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse1353z3K (144:2228)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                        width: 30*fem,
                                        height: 30*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(15*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-1353-bg-V2H.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group10000042086c9 (144:2229)
                                        width: 179*fem,
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004215eNm (144:2230)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79*fem, 4*fem),
                                              width: double.infinity,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // personnamemyB (144:2231)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                                    child: Text(
                                                      'Person name',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // huJh (144:2232)
                                                    '1h',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1428571429*ffem/fem,
                                                      color: Color(0xff9e9e9e),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Text(
                                              // voluptatemetveritatisullamf2y (144:2233)
                                              'Voluptatem et veritatis ullam.',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}