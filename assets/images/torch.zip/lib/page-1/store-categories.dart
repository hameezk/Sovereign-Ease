import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // storecategoriesD9b (17:1114)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Stack(
          children: [
            Positioned(
              // group1000004200uYD (106:3135)
              left: 14*fem,
              top: 132*fem,
              child: Container(
                width: 920*fem,
                height: 2233*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // group20CnD (106:2082)
                      margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 16*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 364*fem,
                          height: 45*fem,
                          child: Container(
                            // group43JaM (106:2083)
                            padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 15*fem),
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffebdfd7)),
                              color: Color(0xfffff7f1),
                              borderRadius: BorderRadius.circular(15*fem),
                            ),
                            child: Container(
                              // frame52R9B (106:2085)
                              width: 109*fem,
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconsearchsearchnormalxuo (106:2086)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                    width: 16*fem,
                                    height: 16*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-search-search-normal-sN9.png',
                                      width: 16*fem,
                                      height: 16*fem,
                                    ),
                                  ),
                                  Text(
                                    // searchhere4hw (106:2087)
                                    'Search here',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1*ffem/fem,
                                      color: Color(0x7f000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // frame10000042075d3 (106:3030)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // group1000004193Ptd (106:2140)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                            padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                            width: 364*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(10*fem),
                              gradient: LinearGradient (
                                begin: Alignment(0, -1),
                                end: Alignment(0, 1),
                                colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                stops: <double>[0, 1],
                              ),
                              image: DecorationImage (
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-6827-bg-DRK.png',
                                ),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // trendycollectionbzh (106:2123)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                  child: Text(
                                    'Trendy collection',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 22*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 0.7272727273*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group10000041927i9 (106:2139)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // shopnowTX7 (106:2124)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        child: Text(
                                          'Shop now',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // iconarrowarrowrightn3b (106:2126)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-arrow-arrow-right-1D3.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame1000004196u8D (106:2372)
                            width: double.infinity,
                            height: 274*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame1000004198Sdw (106:2373)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195z9f (106:2374)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-fZs.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17UKj (106:2376)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarxEu (106:2377)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-Xiq.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // TSZ (106:2378)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197bYm (106:2379)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196YU1 (106:2380)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtsWH (106:2381)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // afb (106:2382)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Kt5 (106:2383)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004199uUu (106:2384)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Szd (106:2385)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-Miy.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17KoX (106:2387)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarCcR (106:2388)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-Cr5.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // Wt1 (106:2389)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197TYM (106:2390)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041961Jy (106:2391)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtwTX (106:2392)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // 4o3 (106:2393)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Dfw (106:2394)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004200XKF (106:2395)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195UEV (106:2396)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17x9f (106:2398)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarTMK (106:2399)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-pZP.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // AmX (106:2400)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197iY9 (106:2401)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196fCV (106:2402)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtbrq (106:2403)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // wA1 (106:2404)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Hjf (106:2405)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004201D13 (106:2406)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195kWm (106:2407)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-mW9.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17qo7 (106:2409)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarvZf (106:2410)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-zpZ.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // diy (106:2411)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197ynq (106:2412)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196XJZ (106:2413)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtrbj (106:2414)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // 9qj (106:2415)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23JCq (106:2416)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004202ooo (106:2417)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195kU9 (106:2418)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-52q.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17E8R (106:2420)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstar7CD (106:2421)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-ech.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // 2py (106:2422)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197BC5 (106:2423)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196jUV (106:2424)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtfd3 (106:2425)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // B5b (106:2426)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23WtZ (106:2427)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004203Fjf (106:2428)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195oWH (106:2429)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-GZX.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame1771B (106:2431)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarzam (106:2432)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-fwo.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // JrM (106:2433)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197TUM (106:2434)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196CB3 (106:2435)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtvMw (106:2436)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // EtR (106:2437)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Bof (106:2438)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // frame1000004206Xm3 (106:3029)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // group1000004194fcM (106:2926)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                            padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                            width: 364*fem,
                            height: 386*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(10*fem),
                              gradient: LinearGradient (
                                begin: Alignment(0, -1),
                                end: Alignment(0, 1),
                                colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                stops: <double>[0, 1],
                              ),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-6827-bg.png',
                                ),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // popularoutfitsUZo (106:2928)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                  child: Text(
                                    'Popular outfits',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 22*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 0.7272727273*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group1000004192Pwf (106:2929)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // shopnow8eM (106:2930)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        child: Text(
                                          'Shop now',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // iconarrowarrowrightfPP (106:2931)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-arrow-arrow-right-TR3.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame1000004196Q65 (106:2938)
                            width: double.infinity,
                            height: 274*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame1000004198vq7 (106:2939)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Urd (106:2940)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-6D7.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17yHb (106:2942)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstar449 (106:2943)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-imP.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // mUM (106:2944)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197Wgq (106:2945)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196fJq (106:2946)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtPkd (106:2947)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // 7gd (106:2948)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23sA1 (106:2949)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004199nwB (106:2950)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Xtm (106:2951)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-V5B.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17q8m (106:2953)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarhwf (106:2954)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-DoP.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // pmP (106:2955)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197AqF (106:2956)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041967Eh (106:2957)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtFLu (106:2958)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // NRX (106:2959)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara237tu (106:2960)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame10000042003AH (106:2961)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195PV3 (106:2962)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-XCM.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17gDF (106:2964)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarYFT (106:2965)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-L9o.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // qVT (106:2966)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197yLm (106:2967)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041966wB (106:2968)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirt2pq (106:2969)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // 9eZ (106:2970)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara236Zo (106:2971)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004201qA1 (106:2972)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195aNV (106:2973)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-cVf.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame175KF (106:2975)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarkwB (106:2976)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-wiy.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // fHT (106:2977)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197QF3 (106:2978)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196MRB (106:2979)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtGY9 (106:2980)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // CAu (106:2981)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23wuB (106:2982)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame10000042025tu (106:2983)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Rhs (106:2984)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-s3X.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17WUR (106:2986)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarzuP (106:2987)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-o4D.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // v2M (106:2988)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197UJm (106:2989)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196cvm (106:2990)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtZ5K (106:2991)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // g9w (106:2992)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23dL5 (106:2993)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004203kZ7 (106:2994)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Vmb (106:2995)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-JEm.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame1772H (106:2997)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarawT (106:2998)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-q4D.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // hWH (106:2999)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197tKs (106:3000)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041962S5 (106:3001)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtxad (106:3002)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // fzq (106:3003)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23dAy (106:3004)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // frame1000004208MWH (106:3031)
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // group1000004193hq3 (106:3032)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                            padding: EdgeInsets.fromLTRB(24*fem, 298*fem, 24*fem, 24*fem),
                            width: 364*fem,
                            height: 386*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(10*fem),
                              gradient: LinearGradient (
                                begin: Alignment(0, -1),
                                end: Alignment(0, 1),
                                colors: <Color>[Color(0x00000000), Color(0xff000000)],
                                stops: <double>[0, 1],
                              ),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-6827-bg-H37.png',
                                ),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // trendycollectioniEM (106:3034)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                  child: Text(
                                    'Trendy collection',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 22*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 0.7272727273*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group1000004192SAM (106:3035)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 213*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // shopnowmiR (106:3036)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        child: Text(
                                          'Shop now',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // iconarrowarrowrightHcD (106:3037)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-arrow-arrow-right-WFb.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame1000004196cPb (106:3039)
                            width: double.infinity,
                            height: 274*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame1000004198LKb (106:3040)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195g8Z (106:3041)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-ied.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17kPK (106:3043)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarpty (106:3044)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-imo.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // k1w (106:3045)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame10000041976Lh (106:3046)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196qJH (106:3047)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtmBw (106:3048)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // gZo (106:3049)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23dV3 (106:3050)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004199x9w (106:3051)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195hdK (106:3052)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-4zD.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17n8y (106:3054)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarGK3 (106:3055)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-X5B.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // BS1 (106:3056)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197jCd (106:3057)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196Ug1 (106:3058)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirt1R3 (106:3059)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // jM3 (106:3060)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23UJd (106:3061)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004200zAV (106:3062)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Xw7 (106:3063)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-v1f.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame1727B (106:3065)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstaruAy (106:3066)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // QdX (106:3067)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197xf3 (106:3068)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196Jyo (106:3069)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirt3Ah (106:3070)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // AFK (106:3071)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara236uf (106:3072)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004201cmX (106:3073)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Zgm (106:3074)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-gPK.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17T1T (106:3076)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarL5F (106:3077)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-FVj.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // eLq (106:3078)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197b1B (106:3079)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041968mo (106:3080)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtU4y (106:3081)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // ynR (106:3082)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23vxZ (106:3083)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame10000042023Qu (106:3084)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195bBX (106:3085)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-LdP.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17Um7 (106:3087)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarmVK (106:3088)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-uhB.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // HCm (106:3089)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197pyP (106:3090)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196yLV (106:3091)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirthnH (106:3092)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // Dkd (106:3093)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23yE1 (106:3094)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 16*fem,
                                ),
                                Container(
                                  // frame1000004203WNM (106:3095)
                                  width: 140*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195ejT (106:3096)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        height: 190*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-3oo.png',
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          // frame17YZw (106:3098)
                                          padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0x66000000),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: ClipRect(
                                            child: BackdropFilter(
                                              filter: ImageFilter.blur (
                                                sigmaX: 7*fem,
                                                sigmaY: 7*fem,
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // iconsupportlikequestionstarcph (106:3099)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/icon-support-like-question-star-qSq.png',
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // KDK (106:3100)
                                                    '4.2',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197fHB (106:3101)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196QVf (106:3102)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtk3j (106:3103)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // s8M (106:3104)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23R9s (106:3105)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // footeriHP (106:3499)
              left: 0*fem,
              top: 769*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 0*fem, 25*fem, 0*fem),
                width: 393*fem,
                height: 83*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffe6e6e6)),
                  color: Color(0xffffffff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // iconessentialhome2yUD (106:3501)
                      margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-essential-home-2.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // autogrouppngrrH7 (9zrmp5U8oSBmzDxDCJPnGR)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                      width: 44*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/auto-group-pngr.png',
                        width: 44*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // group119GD (106:3503)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                      width: 44*fem,
                      height: 44*fem,
                      child: Image.asset(
                        'assets/page-1/images/group-11-fAh.png',
                        width: 44*fem,
                        height: 44*fem,
                      ),
                    ),
                    Container(
                      // iconnotificationnotificationeC (106:3502)
                      margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-notification-notification-q69.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // ellipse1XGm (106:3507)
                      margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 24*fem,
                          height: 24*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-1-bg-HC5.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group1000004190Ppm (106:2081)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16.35*fem, 15*fem, 14*fem, 8*fem),
                width: 393*fem,
                height: 116*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xfff1f1f1)),
                  color: Color(0xfffffbf8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // blackstatusbarFc5 (17:1323)
                      margin: EdgeInsets.fromLTRB(19.65*fem, 0*fem, 1.34*fem, 21*fem),
                      width: double.infinity,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timeAU9 (I17:1338;727:363)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1428571429*ffem/fem,
                                  letterSpacing: -0.2800000012*fem,
                                  color: Color(0xff0a0a0a),
                                ),
                                children: [
                                  TextSpan(
                                    text: '9:4',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xff0a0a0a),
                                    ),
                                  ),
                                  TextSpan(
                                    text: '1',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xff0a0a0a),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // groupG9o (17:1324)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // cellularconnectionypu (17:1333)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/cellular-connection-XM3.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                Container(
                                  // wifihW1 (17:1329)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                  width: 15.33*fem,
                                  height: 11*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-3DB.png',
                                    width: 15.33*fem,
                                    height: 11*fem,
                                  ),
                                ),
                                Container(
                                  // battery2HP (17:1325)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-sGu.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group4LJ5 (17:1406)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                      padding: EdgeInsets.fromLTRB(158.65*fem, 0*fem, 0*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // storerXK (17:1410)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 136*fem, 0*fem),
                            child: Text(
                              'Store',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 18*ffem,
                                fontWeight: FontWeight.w700,
                                height: 0.8888888889*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // iconshopshoppingcartZwX (17:1408)
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-shop-shopping-cart.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupfsbptiu (9zrnKjHPpoCoDCUMr1FsBP)
                      margin: EdgeInsets.fromLTRB(10.65*fem, 0*fem, 13*fem, 7*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            // womenp6m (22:1803)
                            'Women',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1*ffem/fem,
                              color: Color(0xff12a1af),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // men8NM (22:1805)
                            'Men',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7f000000),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // unisex4G1 (106:2078)
                            'Unisex',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7f000000),
                            ),
                          ),
                          SizedBox(
                            width: 60*fem,
                          ),
                          Text(
                            // kidsb13 (106:2079)
                            'Kids',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0x7f000000),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}