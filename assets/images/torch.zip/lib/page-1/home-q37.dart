import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homeoC5 (40:622)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Container(
          // frame35k7K (40:623)
          width: 580*fem,
          height: 1452*fem,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                // group28UZ7 (40:624)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 0*fem, 16*fem),
                width: double.infinity,
                decoration: BoxDecoration (
                  color: Color(0xff111111),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // blackstatusbaryVs (41:3306)
                      margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 202.34*fem, 21*fem),
                      width: double.infinity,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timegv5 (I41:3321;727:363)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1428571429*ffem/fem,
                                  letterSpacing: -0.2800000012*fem,
                                  color: Color(0xffd7d7d7),
                                ),
                                children: [
                                  TextSpan(
                                    text: '9:4',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                  TextSpan(
                                    text: '1',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // groupxWD (41:3307)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // cellularconnectiontem (41:3316)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/cellular-connection-gLy.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                Container(
                                  // wifi1UV (41:3312)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                  width: 15.33*fem,
                                  height: 11*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-1uT.png',
                                    width: 15.33*fem,
                                    height: 11*fem,
                                  ),
                                ),
                                Container(
                                  // batteryj9b (41:3308)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-zUZ.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group4e1f (40:626)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 201*fem, 16*fem),
                      padding: EdgeInsets.fromLTRB(152*fem, 0*fem, 0*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // torchMgm (40:627)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 133.52*fem, 0.9*fem),
                            width: 53.48*fem,
                            height: 15.38*fem,
                            child: Image.asset(
                              'assets/page-1/images/torch-AAu.png',
                              width: 53.48*fem,
                              height: 15.38*fem,
                            ),
                          ),
                          TextButton(
                            // iconsearchsearchnormalfxM (40:628)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-search-search-normal-s6q.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // frame3aZX (40:630)
                      width: double.infinity,
                      height: 84*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame2urh (40:631)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1GBT (40:632)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(39*fem, 42*fem, 3*fem, 0*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(30*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-2-bg-xFs.png',
                                      ),
                                    ),
                                  ),
                                  child: Align(
                                    // group2m8D (40:634)
                                    alignment: Alignment.bottomRight,
                                    child: SizedBox(
                                      width: 18*fem,
                                      height: 18*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/group-2-MP7.png',
                                        width: 18*fem,
                                        height: 18*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // addstorytTj (40:637)
                                  'Add story',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame31HT (40:638)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1ZJy (40:639)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffd7d7d7),
                                        borderRadius: BorderRadius.circular(30*fem),
                                        border: Border (
                                        ),
                                      ),
                                      child: Center(
                                        // ellipse3pkh (40:641)
                                        child: SizedBox(
                                          width: double.infinity,
                                          height: 56*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(28*fem),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-3-bg-rNu.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // nicklauswqK (40:642)
                                  'Nicklaus',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame4THs (40:643)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1Qiu (40:644)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd7d7d7),
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border (
                                    ),
                                  ),
                                  child: Center(
                                    // ellipse3XHj (40:646)
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 56*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(28*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-3-bg-qVb.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // cathyFUd (40:647)
                                  'Cathy',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame5B7P (40:648)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1up5 (40:649)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd7d7d7),
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border (
                                    ),
                                  ),
                                  child: Center(
                                    // ellipse3pAM (40:651)
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 56*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(28*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-3-bg-9LV.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // kaileywkm (40:652)
                                  'Kailey',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame6gCZ (40:653)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1Rfw (40:654)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd7d7d7),
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border (
                                    ),
                                  ),
                                  child: Center(
                                    // ellipse38KT (40:656)
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 56*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(28*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-3-bg-y1T.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // tiararmF (40:657)
                                  'Tiara',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame7zcZ (40:658)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1x3b (40:659)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd7d7d7),
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border (
                                    ),
                                  ),
                                  child: Center(
                                    // ellipse3GKB (40:661)
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 56*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(28*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-3-bg-sqT.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // quincyyzH (40:662)
                                  'Quincy',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 24*fem,
                          ),
                          Container(
                            // frame8WjK (40:663)
                            width: 60*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group14kq (40:664)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffd7d7d7),
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border (
                                    ),
                                  ),
                                  child: Center(
                                    // ellipse3ajB (40:666)
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 56*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(28*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-3-bg-fdj.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // daynei4h (40:667)
                                  'Dayne',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupez1pTHB (9zs8ZeZMLJ5yXuFh4kEz1P)
                width: 393*fem,
                height: 1236*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // frame28beH (91:2056)
                      left: 15*fem,
                      top: 0*fem,
                      child: Container(
                        width: 364*fem,
                        height: 1236*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // frame29iD7 (91:2057)
                              width: 182*fem,
                              height: double.infinity,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // frame28fPF (91:2058)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 182*fem,
                                      height: 228*fem,
                                      child: Container(
                                        // group26QLq (91:2059)
                                        width: double.infinity,
                                        height: 200*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // group259ZK (91:2060)
                                              left: 16.0007629395*fem,
                                              top: 2.9991455078*fem,
                                              child: Container(
                                                width: 166*fem,
                                                height: 187*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      // group15sVK (91:2061)
                                                      left: 47.9943847656*fem,
                                                      top: 17.5886230469*fem,
                                                      child: Container(
                                                        width: 118*fem,
                                                        height: 149.7*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5CnV (91:2062)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 149.7*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-S1f.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group14vCh (91:2063)
                                                      left: 20.5866699219*fem,
                                                      top: 10.9829101562*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                        width: 139.69*fem,
                                                        height: 170.3*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5d77 (91:2064)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 169.92*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-5Hb.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group13jfw (91:2065)
                                                      left: 0*fem,
                                                      top: 0*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                        width: 153.32*fem,
                                                        height: 187*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5Rof (91:2066)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 186.78*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-XhT.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // group12Lvd (91:2067)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 156*fem,
                                                height: 200*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Center(
                                                  // rectangle5rty (91:2068)
                                                  child: SizedBox(
                                                    width: double.infinity,
                                                    height: 200*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                        color: Color(0xffd9d9d9),
                                                        image: DecorationImage (
                                                          fit: BoxFit.cover,
                                                          image: AssetImage (
                                                            'assets/page-1/images/rectangle-5-bg-Xi9.png',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame30P8D (91:2079)
                                    left: 0*fem,
                                    top: 216*fem,
                                    child: Container(
                                      width: 174*fem,
                                      height: 268*fem,
                                      child: Container(
                                        // group26KnZ (91:2080)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                        width: double.infinity,
                                        height: 240*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Container(
                                          // group12s3P (91:2081)
                                          width: double.infinity,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle52S5 (91:2082)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 240*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-qMK.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame329Fo (91:2093)
                                    left: 0*fem,
                                    top: 472*fem,
                                    child: Container(
                                      width: 174*fem,
                                      height: 764*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // group26sSh (91:2094)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            width: 166*fem,
                                            height: 240*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Container(
                                              // group12or9 (91:2095)
                                              width: double.infinity,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Center(
                                                // rectangle5yVj (91:2096)
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 240*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                      color: Color(0xffd9d9d9),
                                                      image: DecorationImage (
                                                        fit: BoxFit.cover,
                                                        image: AssetImage (
                                                          'assets/page-1/images/rectangle-5-bg-1i1.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // autogroupucfsVU5 (9zs9CDLkukAf19ERLcUCFs)
                                            width: double.infinity,
                                            height: 516*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // frame30qXw (91:2107)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    width: 174*fem,
                                                    height: 268*fem,
                                                    child: Container(
                                                      // group26B61 (91:2108)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Container(
                                                        // group126yf (91:2109)
                                                        width: double.infinity,
                                                        height: double.infinity,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5rC9 (91:2110)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 240*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-eNM.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // frame31m4D (91:2121)
                                                  left: 0*fem,
                                                  top: 248*fem,
                                                  child: Container(
                                                    width: 174*fem,
                                                    height: 268*fem,
                                                    child: Container(
                                                      // group26zxZ (91:2122)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Container(
                                                        // group12jfF (91:2123)
                                                        width: double.infinity,
                                                        height: double.infinity,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle56kh (91:2124)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 240*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-Mr9.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame29QmP (91:2135)
                              width: 182*fem,
                              height: 956*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // frame299ys (91:2136)
                                    left: 16*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 166*fem,
                                      height: 268*fem,
                                      child: Container(
                                        // group26twT (91:2137)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                        width: double.infinity,
                                        height: 240*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Container(
                                          // group122Xs (91:2138)
                                          width: double.infinity,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle5PNR (91:2139)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 240*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-fQu.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame31i9o (91:2150)
                                    left: 8*fem,
                                    top: 256*fem,
                                    child: Container(
                                      width: 174*fem,
                                      height: 268*fem,
                                      child: Container(
                                        // group26ep9 (91:2151)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                        width: double.infinity,
                                        height: 240*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Container(
                                          // group12z7K (91:2152)
                                          width: double.infinity,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle5MCm (91:2153)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 240*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-84y.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame33rfK (91:2164)
                                    left: 0*fem,
                                    top: 512*fem,
                                    child: Container(
                                      width: 182*fem,
                                      height: 228*fem,
                                      child: Container(
                                        // group26CUH (91:2165)
                                        width: double.infinity,
                                        height: 200*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // group25wgm (91:2166)
                                              left: 16.0007629395*fem,
                                              top: 2.9990234375*fem,
                                              child: Container(
                                                width: 166*fem,
                                                height: 187*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      // group15er5 (91:2167)
                                                      left: 47.9943771362*fem,
                                                      top: 17.5886230469*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                        width: 118*fem,
                                                        height: 149.7*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5Zy3 (91:2168)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 149.7*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-6Kb.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group14gXs (91:2169)
                                                      left: 20.5866699219*fem,
                                                      top: 10.9829101562*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                        width: 139.69*fem,
                                                        height: 170.3*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5nau (91:2170)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 169.92*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-opm.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group13uvR (91:2171)
                                                      left: 0*fem,
                                                      top: 0*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                        width: 153.32*fem,
                                                        height: 187*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5RNy (91:2172)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 186.78*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-eDw.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // group12Lkq (91:2173)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 156*fem,
                                                height: 200*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Center(
                                                  // rectangle5HAH (91:2174)
                                                  child: SizedBox(
                                                    width: double.infinity,
                                                    height: 200*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                        color: Color(0xffd9d9d9),
                                                        image: DecorationImage (
                                                          fit: BoxFit.cover,
                                                          image: AssetImage (
                                                            'assets/page-1/images/rectangle-5-bg-34V.png',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame34CY9 (91:2185)
                                    left: 0*fem,
                                    top: 728*fem,
                                    child: Container(
                                      width: 182*fem,
                                      height: 228*fem,
                                      child: Container(
                                        // group26LeM (91:2186)
                                        width: double.infinity,
                                        height: 200*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // group25VGM (91:2187)
                                              left: 16.0007629395*fem,
                                              top: 2.9990234375*fem,
                                              child: Container(
                                                width: 166*fem,
                                                height: 187*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      // group15QeD (91:2188)
                                                      left: 47.9943771362*fem,
                                                      top: 17.5886230469*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                        width: 118*fem,
                                                        height: 149.7*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5iuo (91:2189)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 149.7*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-BpM.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group142vV (91:2190)
                                                      left: 20.5866699219*fem,
                                                      top: 10.9829101562*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                        width: 139.69*fem,
                                                        height: 170.3*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5wnZ (91:2191)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 169.92*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-vsT.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // group13fTf (91:2192)
                                                      left: 0*fem,
                                                      top: 0*fem,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                        width: 153.32*fem,
                                                        height: 187*fem,
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                        ),
                                                        child: Center(
                                                          // rectangle5Nss (91:2193)
                                                          child: SizedBox(
                                                            width: double.infinity,
                                                            height: 186.78*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(10*fem),
                                                                color: Color(0xffd9d9d9),
                                                                image: DecorationImage (
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage (
                                                                    'assets/page-1/images/rectangle-5-bg-XqT.png',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // group12Hzq (91:2194)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 156*fem,
                                                height: 200*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Center(
                                                  // rectangle5doo (91:2195)
                                                  child: SizedBox(
                                                    width: double.infinity,
                                                    height: 200*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                        color: Color(0xffd9d9d9),
                                                        image: DecorationImage (
                                                          fit: BoxFit.cover,
                                                          image: AssetImage (
                                                            'assets/page-1/images/rectangle-5-bg-EFj.png',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // footerME1 (40:818)
                      left: 0*fem,
                      top: 553*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(14*fem, 0*fem, 25*fem, 0*fem),
                        width: 393*fem,
                        height: 83*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff191919)),
                          color: Color(0xff010101),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // autogroupb7r1orh (9zsAwQw8hHf4tkkKziB7r1)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                              width: 44*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/auto-group-b7r1.png',
                                width: 44*fem,
                                height: 40*fem,
                              ),
                            ),
                            Container(
                              // iconshopshop7cV (40:826)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-shop-shop-tY1.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // group11Qbb (40:823)
                              margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                              width: 44*fem,
                              height: 44*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-11-oZT.png',
                                width: 44*fem,
                                height: 44*fem,
                              ),
                            ),
                            Container(
                              // iconnotificationnotification8G (40:822)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-notification-notification-TQD.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // ellipse1chf (40:827)
                              margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 24*fem,
                                  height: 24*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(12*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/ellipse-1-bg-r2D.png',
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}