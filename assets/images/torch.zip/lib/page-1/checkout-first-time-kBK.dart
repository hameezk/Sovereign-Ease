import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // checkoutfirsttimezgR (151:4334)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group107m3 (151:4335)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbar2ND (151:4338)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeYLZ (I151:4353;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupzLy (151:4339)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionvVX (151:4348)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-4cy.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiqcV (151:4344)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-JmP.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batterykUZ (151:4340)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-Ucq.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupusa5rXb (9zuf42JbFadPqTUAKAuSa5)
                    width: 108*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // checkoutNkq (151:4337)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 76*fem,
                              height: 16*fem,
                              child: Text(
                                'Checkout',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 0.8888888889*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group4RDK (151:4354)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4-5GM.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupglu7iTK (9zucHwEfqcBMTxe5yPGLu7)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
              width: double.infinity,
              height: 679*fem,
              child: Container(
                // frame1000004230FCM (151:4371)
                padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                width: double.infinity,
                height: double.infinity,
                child: Container(
                  // frame1000004229akR (151:4372)
                  width: 538*fem,
                  height: 1480*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // group1000004224KT7 (151:4373)
                        width: double.infinity,
                        height: 358*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // rectangle23sDj (151:4374)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 361*fem,
                                  height: 358*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(8*fem),
                                      color: Color(0xff191919),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x3f000000),
                                          offset: Offset(0*fem, 10*fem),
                                          blurRadius: 7.5*fem,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame1000004224Z6Z (151:4375)
                              left: 16*fem,
                              top: 322*fem,
                              child: Container(
                                width: 161*fem,
                                height: 20*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // rectangle6822UDX (151:4376)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                      width: 20*fem,
                                      height: 20*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(5*fem),
                                        border: Border.all(color: Color(0xff303030)),
                                        color: Color(0xff1e1e1e),
                                      ),
                                    ),
                                    Text(
                                      // saveforfutureuseBdj (151:4377)
                                      'Save for future use',
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // group1000004223Wg1 (151:4378)
                              left: 16*fem,
                              top: 56*fem,
                              child: Container(
                                width: 522*fem,
                                height: 242*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(15*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupstuh2PT (9zudgPvbxtUncmnFkzstUh)
                                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // group1000004218xnu (151:4379)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                            width: 350*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // fullnamegyo (151:4380)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Full name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146Whw (151:4381)
                                                  width: double.infinity,
                                                  height: 46*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(15*fem),
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      Positioned(
                                                        // rectangle6822rG1 (151:4382)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 328*fem,
                                                            height: 46*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(15*fem),
                                                                border: Border.all(color: Color(0xff303030)),
                                                                color: Color(0xff1e1e1e),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // johndoexK3 (151:4384)
                                                        left: 16*fem,
                                                        top: 14*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 61*fem,
                                                            height: 20*fem,
                                                            child: Text(
                                                              'John doe',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 16*ffem,
                                                                fontWeight: FontWeight.w400,
                                                                height: 1.2*ffem/fem,
                                                                letterSpacing: -0.32*fem,
                                                                color: Color(0xff9da3a2),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // group1000004219fsf (151:4385)
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // cardnumberR69 (151:4386)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Card number',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146YAm (151:4387)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-2JV.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // group1000004222rhF (151:4390)
                                      width: double.infinity,
                                      height: 70*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group1000004220PSH (151:4391)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 350*fem,
                                              height: 70*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(15*fem),
                                              ),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // cvv6rV (151:4392)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'CVV',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // group1000004146dLd (151:4393)
                                                    width: double.infinity,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(15*fem),
                                                    ),
                                                    child: Align(
                                                      // rectangle6822b2Z (151:4394)
                                                      alignment: Alignment.centerLeft,
                                                      child: SizedBox(
                                                        width: 156*fem,
                                                        height: 46*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(15*fem),
                                                            border: Border.all(color: Color(0xff303030)),
                                                            color: Color(0xff1e1e1e),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group1000004221WfK (151:4396)
                                            left: 172*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 350*fem,
                                              height: 70*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(15*fem),
                                              ),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // expiredatedV3 (151:4397)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Expire date',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // group1000004146x1X (151:4398)
                                                    width: double.infinity,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(15*fem),
                                                    ),
                                                    child: Align(
                                                      // rectangle6822hzh (151:4399)
                                                      alignment: Alignment.centerLeft,
                                                      child: SizedBox(
                                                        width: 156*fem,
                                                        height: 46*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(15*fem),
                                                            border: Border.all(color: Color(0xff303030)),
                                                            color: Color(0xff1e1e1e),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // cardinformationqLD (151:4401)
                              left: 16*fem,
                              top: 16*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 121*fem,
                                  height: 16*fem,
                                  child: Text(
                                    'Card information',
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupxqpbA17 (9zucX6XQg7PDDBzdqMXQPB)
                        padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // group1000004235tC1 (151:4402)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                              width: 366*fem,
                              height: 532*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle23bs7 (151:4403)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 361*fem,
                                        height: 532*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(8*fem),
                                            color: Color(0xff191919),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset: Offset(0*fem, 10*fem),
                                                blurRadius: 7.5*fem,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame1000004224GCZ (151:4404)
                                    left: 16*fem,
                                    top: 486*fem,
                                    child: Container(
                                      width: 161*fem,
                                      height: 20*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Container(
                                            // rectangle6822ycm (151:4405)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                            width: 20*fem,
                                            height: 20*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(5*fem),
                                              color: Color(0xff1e1e1e),
                                            ),
                                          ),
                                          Text(
                                            // saveforfutureuseuFX (151:4406)
                                            'Save for future use',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // group1000004223SFT (151:4407)
                                    left: 16*fem,
                                    top: 56*fem,
                                    child: Container(
                                      width: 350*fem,
                                      height: 414*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // group1000004218Lbj (151:4408)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // fullnamegfb (151:4409)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Full name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146QLh (151:4410)
                                                  width: double.infinity,
                                                  height: 46*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(15*fem),
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      Positioned(
                                                        // rectangle68229ZB (151:4411)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 328*fem,
                                                            height: 46*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(15*fem),
                                                                border: Border.all(color: Color(0xff303030)),
                                                                color: Color(0xff1e1e1e),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // johndoe4w3 (151:4413)
                                                        left: 16*fem,
                                                        top: 14*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 61*fem,
                                                            height: 20*fem,
                                                            child: Text(
                                                              'John doe',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 16*ffem,
                                                                fontWeight: FontWeight.w400,
                                                                height: 1.2*ffem/fem,
                                                                letterSpacing: -0.32*fem,
                                                                color: Color(0xff9da3a2),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004219YbK (151:4414)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // address1rc1 (151:4415)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Address 1',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146Asb (151:4416)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-EhP.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004220sn1 (151:4419)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // address1pSM (151:4420)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Address 1',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146YNM (151:4421)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-S6d.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004221rtq (151:4424)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // cityc7K (151:4425)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'City',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146Xzy (151:4426)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-gau.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group10000042224V7 (151:4429)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // zipcodeQ3B (151:4430)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Zip code',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146XNh (151:4431)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-1jP.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // billinginformationrQy (151:4434)
                                    left: 16*fem,
                                    top: 16*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 126*fem,
                                        height: 16*fem,
                                        child: Text(
                                          'Billing information',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // group1000004236jUm (151:4435)
                              width: 366*fem,
                              height: 558*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle2352q (151:4436)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 361*fem,
                                        height: 558*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(8*fem),
                                            color: Color(0xff191919),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset: Offset(0*fem, 10*fem),
                                                blurRadius: 7.5*fem,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // frame1000004228mRT (151:4437)
                                    left: 16*fem,
                                    top: 56*fem,
                                    child: Container(
                                      width: 350*fem,
                                      height: 486*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame10000042255BF (151:4438)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 186*fem, 0*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Container(
                                                  // rectangle6822Cmf (151:4439)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(5*fem),
                                                    border: Border.all(color: Color(0xff303030)),
                                                    color: Color(0xff1e1e1e),
                                                  ),
                                                ),
                                                Text(
                                                  // usesameasbilling8QR (151:4440)
                                                  'USe same as billing',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group10000042184J5 (151:4441)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // fullnamezxR (151:4442)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Full name',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group10000041467n9 (151:4443)
                                                  width: double.infinity,
                                                  height: 46*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(15*fem),
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      Positioned(
                                                        // rectangle6822rUq (151:4444)
                                                        left: 0*fem,
                                                        top: 0*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 328*fem,
                                                            height: 46*fem,
                                                            child: Container(
                                                              decoration: BoxDecoration (
                                                                borderRadius: BorderRadius.circular(15*fem),
                                                                border: Border.all(color: Color(0xff303030)),
                                                                color: Color(0xff1e1e1e),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        // johndoeAkR (151:4446)
                                                        left: 16*fem,
                                                        top: 14*fem,
                                                        child: Align(
                                                          child: SizedBox(
                                                            width: 61*fem,
                                                            height: 20*fem,
                                                            child: Text(
                                                              'John doe',
                                                              style: SafeGoogleFont (
                                                                'Urbanist',
                                                                fontSize: 16*ffem,
                                                                fontWeight: FontWeight.w400,
                                                                height: 1.2*ffem/fem,
                                                                letterSpacing: -0.32*fem,
                                                                color: Color(0xff9da3a2),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004219FG5 (151:4447)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // address1PNH (151:4448)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Address 1',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146K13 (151:4449)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-VyB.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group10000042202w3 (151:4452)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // address1aSm (151:4453)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Address 1',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146hXP (151:4454)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-CiM.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004221RCV (151:4457)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // cityZJh (151:4458)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'City',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group1000004146tLy (151:4459)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-5Vs.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // group1000004222CsT (151:4462)
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(15*fem),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // zipcodeYwK (151:4463)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                  child: Text(
                                                    'Zip code',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // group10000041464uf (151:4464)
                                                  width: 350*fem,
                                                  height: 46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-1000004146-BQ5.png',
                                                    width: 350*fem,
                                                    height: 46*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16*fem,
                                          ),
                                          Container(
                                            // frame1000004224aND (151:4467)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 189*fem, 0*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Container(
                                                  // rectangle6822Jp1 (151:4468)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(5*fem),
                                                    border: Border.all(color: Color(0xff303030)),
                                                    color: Color(0xff1e1e1e),
                                                  ),
                                                ),
                                                Text(
                                                  // saveforfutureusepnM (151:4469)
                                                  'Save for future use',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // shippinginformationA5X (151:4470)
                                    left: 16*fem,
                                    top: 16*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 148*fem,
                                        height: 16*fem,
                                        child: Text(
                                          'Shipping information',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              // group1000004235rDF (151:4361)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 23*fem),
              width: double.infinity,
              height: 83*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff010101),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame1000004227kpR (151:4500)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 104*fem, 14*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // total5rh (151:4501)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          child: Text(
                            'Total:',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              color: Color(0xff727272),
                            ),
                          ),
                        ),
                        Text(
                          // c5w (151:4502)
                          '\$16.31',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    // group24khw (151:4363)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: 170*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(100*fem),
                      ),
                      child: Container(
                        // group23617 (151:4364)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xff11a0af),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Pay now',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}