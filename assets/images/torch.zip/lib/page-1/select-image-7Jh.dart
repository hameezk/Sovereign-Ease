import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // selectimageCH7 (109:4324)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10vyo (109:4352)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbare97 (109:4354)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timexfb (I109:4369;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupdfF (109:4355)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionmWZ (109:4364)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-CnV.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifigdX (109:4360)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-HcD.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batterycXB (109:4356)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-jzy.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4XPF (109:4370)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 244.66*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconarrowarrowleftfVT (109:4372)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-arrow-arrow-left-ecH.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // newpostmHb (109:4373)
                          'New post',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // rectangleVjP (109:4346)
              width: 393*fem,
              height: 400*fem,
              child: Image.asset(
                'assets/page-1/images/rectangle-3Cd.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // recentsEgy (109:4326)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup9nhfaVw (9zu2BR5P5JHqd8T4tW9nHF)
                    width: double.infinity,
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup3huuvJu (9zu2LVeb1KMFJ8V8Wp3HUu)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-xVP.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleSHF (109:4335)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-MTF.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        TextButton(
                          // rectanglemKX (109:4333)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 98*fem,
                            height: 98*fem,
                            child: Image.asset(
                              'assets/page-1/images/rectangle-ZfP.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                          // rectangletuw (109:4331)
                          width: 98*fem,
                          height: 98*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-bbF.png',
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // rectangle329 (109:4332)
                          width: 99*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-mus.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvcn5PLu (9zu2SpoNaC78PWKvgAVcn5)
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangleYDo (109:4339)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-NSD.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectangle5zR (109:4338)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-rHw.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectangleSa5 (109:4336)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-t6D.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectanglenP3 (109:4337)
                          width: 99*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-NaV.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup96smXrR (9zu2eQJR1yd1rtimzo96SM)
                    width: double.infinity,
                    height: 196*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectanglefSq (109:4327)
                          left: 0*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-ya1.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectanglemVs (109:4328)
                          left: 98.2613525391*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-Bwo.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleh8d (109:4329)
                          left: 196.522644043*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-gYq.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangledHB (109:4330)
                          left: 294.783996582*fem,
                          top: 98.7839355469*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-HsF.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleZAq (109:4340)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-uTw.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectanglegWM (109:4341)
                          left: 98*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-ewT.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleQx9 (109:4342)
                          left: 294*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 99*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-9Nq.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // videoZ4M (109:4343)
                          left: 255.1774291992*fem,
                          top: 74.5*fem,
                          child: Container(
                            width: 30*fem,
                            height: 13*fem,
                            child: Center(
                              child: Text(
                                '06:23',
                                textAlign: TextAlign.right,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 11*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1818181818*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleSP3 (109:4345)
                          left: 196*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-17P.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle1mw7 (109:4347)
                          left: 0*fem,
                          top: 49*fem,
                          child: Align(
                            child: SizedBox(
                              width: 393*fem,
                              height: 117*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff191919)),
                                  color: Color(0xff010101),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group24Vs7 (109:4348)
                          left: 16*fem,
                          top: 73*fem,
                          child: Container(
                            width: 361*fem,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Container(
                              // group23S1f (109:4349)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xff11a0af),
                                borderRadius: BorderRadius.circular(100*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Post',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}