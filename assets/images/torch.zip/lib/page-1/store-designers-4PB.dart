import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // storedesigners1r1 (106:3664)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Stack(
          children: [
            Positioned(
              // frame54kHo (106:3665)
              left: 14*fem,
              top: 108*fem,
              child: Container(
                width: 365*fem,
                height: 837*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group43fvZ (106:3719)
                      margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 16*fem),
                      padding: EdgeInsets.fromLTRB(16*fem, 14*fem, 16*fem, 15*fem),
                      width: 364*fem,
                      height: 45*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffebdfd7)),
                        color: Color(0xfffff7f1),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Container(
                        // frame52mCu (106:3721)
                        width: 109*fem,
                        height: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconsearchsearchnormali89 (106:3722)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-search-search-normal-X7F.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                            Text(
                              // searchherepS5 (106:3723)
                              'Search here',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1*ffem/fem,
                                color: Color(0x7f000000),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // frame53kqX (106:3666)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      width: 364*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupdtqt68h (9ztscfM6eX8Z2toF5QdTqT)
                            width: double.infinity,
                            height: 182*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group45deR (106:3667)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(27*fem, 66*fem, 26.91*fem, 66*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // zarasvgiQy (106:3669)
                                    child: SizedBox(
                                      width: 120.09*fem,
                                      height: 50*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/zara-svg-hKo.png',
                                        width: 120.09*fem,
                                        height: 50*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group44dnq (106:3672)
                                  padding: EdgeInsets.fromLTRB(26*fem, 66*fem, 26.02*fem, 66*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // levissvgwYd (106:3674)
                                    child: SizedBox(
                                      width: 121.98*fem,
                                      height: 50*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/levis-svg-Pv9.png',
                                        width: 121.98*fem,
                                        height: 50*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroupcazmFpD (9ztsmA6wbKtBZ1DXEucAzm)
                            width: double.infinity,
                            height: 182*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group46zWu (106:3677)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(42.1*fem, 60.97*fem, 41.2*fem, 60.84*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // hmsvgt6V (106:3679)
                                    child: SizedBox(
                                      width: 90.7*fem,
                                      height: 60.19*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/hm-svg-END.png',
                                        width: 90.7*fem,
                                        height: 60.19*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group47Qad (106:3683)
                                  padding: EdgeInsets.fromLTRB(10*fem, 71*fem, 10.15*fem, 71*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // snitchpngvYy (106:3685)
                                    child: SizedBox(
                                      width: 153.85*fem,
                                      height: 40*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/snitch-png-2h7.png',
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroupkhe1eE5 (9ztsta4FrAdwMkM4QLKhE1)
                            width: double.infinity,
                            height: 182*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group48b9K (106:3686)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(23*fem, 81*fem, 23.34*fem, 81*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // pradasvgUyo (106:3688)
                                    child: SizedBox(
                                      width: 127.66*fem,
                                      height: 20*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/prada-svg-dSZ.png',
                                        width: 127.66*fem,
                                        height: 20*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group50zx9 (106:3691)
                                  padding: EdgeInsets.fromLTRB(56*fem, 60.84*fem, 56*fem, 61.16*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // louisvuittonsvgi7T (106:3693)
                                    child: SizedBox(
                                      width: 62*fem,
                                      height: 60*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/louis-vuitton-svg-eLH.png',
                                        width: 62*fem,
                                        height: 60*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroupupjd1sF (9ztt1uBNpYn1a5XmeDUpJd)
                            width: double.infinity,
                            height: 182*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group51Mw7 (106:3695)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(23*fem, 81.05*fem, 23.36*fem, 81*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // chanelsvgrss (106:3697)
                                    child: SizedBox(
                                      width: 127.65*fem,
                                      height: 19.95*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/chanel-svg-VSR.png',
                                        width: 127.65*fem,
                                        height: 19.95*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group49Bv9 (106:3713)
                                  padding: EdgeInsets.fromLTRB(16*fem, 71*fem, 15.13*fem, 71*fem),
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    // diorsvg61X (106:3715)
                                    child: SizedBox(
                                      width: 142.87*fem,
                                      height: 40*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/dior-svg-dcV.png',
                                        width: 142.87*fem,
                                        height: 40*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group10Qnu (106:3796)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 14*fem, 14*fem),
                width: 393*fem,
                height: 90*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xfff1f1f1)),
                  color: Color(0xfffefaf8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // blackstatusbar6Qq (106:3798)
                      margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 1.34*fem, 21*fem),
                      width: double.infinity,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timec8H (I106:3813;727:363)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1428571429*ffem/fem,
                                  letterSpacing: -0.2800000012*fem,
                                  color: Color(0xff0a0a0a),
                                ),
                                children: [
                                  TextSpan(
                                    text: '9:4',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xff0a0a0a),
                                    ),
                                  ),
                                  TextSpan(
                                    text: '1',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xff0a0a0a),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // group6Sm (106:3799)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // cellularconnectionqQM (106:3808)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/cellular-connection-6Ch.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                SizedBox(
                                  width: 5*fem,
                                ),
                                Container(
                                  // wifik1X (106:3804)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                  width: 15.33*fem,
                                  height: 11*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-TG5.png',
                                    width: 15.33*fem,
                                    height: 11*fem,
                                  ),
                                ),
                                SizedBox(
                                  width: 5*fem,
                                ),
                                Container(
                                  // batteryFDB (106:3800)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-WG9.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group4xdP (106:3814)
                      width: double.infinity,
                      height: 24*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogrouppdzyJhF (9ztteiTNFNhjpZLygiPDzy)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 153*fem, 0*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // iconarrowarrowleftqhB (106:3817)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 24*fem,
                                      height: 24*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon-arrow-arrow-left-hWh.png',
                                        width: 24*fem,
                                        height: 24*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // browsebybrandsKsF (106:3818)
                                  'Browse by brands',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 18*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 0.8888888889*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // iconshopshoppingcartfRK (106:3816)
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-shop-shopping-cart-RbF.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // blackstatusbarbpm (106:3745)
              left: 34*fem,
              top: 15*fem,
              child: Container(
                width: 343.66*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeKVs (I106:3760;727:363)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: -0.2800000012*fem,
                            color: Color(0xff0a0a0a),
                          ),
                          children: [
                            TextSpan(
                              text: '9:4',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                            ),
                            TextSpan(
                              text: '1',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // groupRhK (106:3746)
                      margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cellularconnectionAeu (106:3755)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/cellular-connection-2Q1.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // wififrZ (106:3751)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                            width: 15.33*fem,
                            height: 11*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-j5j.png',
                              width: 15.33*fem,
                              height: 11*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // batteryysF (106:3747)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-zGy.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}