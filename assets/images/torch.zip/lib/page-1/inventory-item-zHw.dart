import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // inventoryitem4eM (50:7797)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10Pgd (50:7798)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarHGD (50:7800)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeoVT (I50:7815;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupSwj (50:7801)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionaHF (50:7810)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-qMK.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiHhT (50:7806)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-gqX.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryXbo (50:7802)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-3nR.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwhppRx5 (9ztb2Dq6e8HcAR5noAwhPP)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 258.66*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconarrowarrowleftZYV (50:7817)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-arrow-arrow-left-1ay.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // tshirtsqku (50:7818)
                          'T Shirts',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupncchys7 (9ztXbjhVQcDsGbUosYncCH)
              width: double.infinity,
              height: 800*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group52iph (50:7819)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      width: 361*fem,
                      height: 800*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogrouppw2mRz1 (9ztXmjQqTg3nU8uxeqpW2m)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group13yVj (50:7820)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7daH (50:7822)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-MLM.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20ird (50:7823)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroup7aokekH (9ztXxoviChsaP3drSD7aoK)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18z3T (50:7824)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // ssw (50:7829)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23nED (50:7830)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group14TzZ (50:7831)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7kim (50:7833)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-hx5.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20GBK (50:7834)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroup2yqtbjP (9ztYHtDGBnkuFb74qp2yqT)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame188jK (50:7835)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // q7w (50:7840)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara238Mw (50:7841)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroupnplhRkM (9ztYZHwFggaC1xyvdUNpLH)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group15BDj (50:7842)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7FUV (50:7844)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-bnZ.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20S3B (50:7845)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupb7ahZNh (9ztYixKpbuwNqrdmibB7aH)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18gy7 (50:7846)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // b4V (50:7851)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara2361F (50:7852)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group162Z7 (50:7853)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7igq (50:7855)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-SMP.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20dYu (50:7856)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupbj5sAYq (9ztZ2cV4mCN6dP2wRwbj5s)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18JQ9 (50:7857)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // CEd (50:7862)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23tt9 (50:7863)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroup6parcxZ (9ztZG76ajY2gkGAnz66PAR)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group17AUH (50:7864)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle73Y5 (50:7866)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-BLm.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20Yzd (50:7867)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupbtcyHhK (9ztZQmWpFG1gTCUizgBtcy)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18phF (50:7868)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 14*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1428571429*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // vkH (50:7873)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23qMT (50:7874)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group18PGV (50:7875)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff191919),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7G5P (50:7877)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-7kV.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame209ey (50:7878)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupewufguo (9ztZhBD99fDALXhVrsEWuF)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18pWD (50:7879)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 14*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1428571429*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // vZF (50:7884)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara232cH (50:7885)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1myB (50:7886)
                    left: 0*fem,
                    top: 646*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 100*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xff191919)),
                            color: Color(0xff010101),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group24u3o (50:7887)
                    left: 16*fem,
                    top: 670*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 361*fem,
                        height: 45*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Container(
                          // group23cyo (50:7888)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff11a0af),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Add item',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}