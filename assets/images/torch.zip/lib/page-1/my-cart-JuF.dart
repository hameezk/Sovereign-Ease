import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // mycartMn1 (147:3436)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10H9s (147:3437)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff191919)),
                color: Color(0xff111111),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // blackstatusbarnMX (147:3440)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeVmj (I147:3455;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupK8V (147:3441)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionSU1 (147:3450)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-46V.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiZHj (147:3446)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-4bT.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batterysZK (147:3442)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-hzH.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupzvyuaTj (9zukUx6BCcmUCSaFqTzVYu)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.66*fem, 0*fem),
                    width: double.infinity,
                    height: 24*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup82hwuW1 (9zukbXjYcsNQ54FXmT82Hw)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238*fem, 0*fem),
                          width: 99*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // mycartRz9 (147:3439)
                                left: 32*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 67*fem,
                                    height: 16*fem,
                                    child: Text(
                                      'My Cart',
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 0.8888888889*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // group48Nm (147:3456)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 60.28*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/group-4-Q97.png',
                                      width: 60.28*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // iconessentialtrashEwb (147:3578)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-essential-trash-1hs.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupg4uhmAq (9zuhwXKpvPqC1hRmpPG4UH)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group1000004214Vcd (147:3459)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff191919),
                      borderRadius: BorderRadius.circular(8*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 10*fem),
                          blurRadius: 7.5*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group10000042139hB (147:3465)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 216*fem, 16*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ellipse1354rrV (147:3467)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                width: 16*fem,
                                height: 16*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                  border: Border.all(color: Color(0x33ecdfd7)),
                                  color: Color(0x00ffffff),
                                ),
                              ),
                              Text(
                                // sellernamehereNZw (147:3466)
                                'Seller name here',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // line7JTb (147:3464)
                          width: double.infinity,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff363636),
                          ),
                        ),
                        Container(
                          // autogrouphauzFNq (9zuiivBraV8ENhc5wvhaUZ)
                          padding: EdgeInsets.fromLTRB(1*fem, 15*fem, 1*fem, 1*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // group1000004211BGV (147:3468)
                                margin: EdgeInsets.fromLTRB(13*fem, 0*fem, 106*fem, 8*fem),
                                width: double.infinity,
                                height: 77*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // iconessentialtickcirclehVj (147:3476)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 1*fem),
                                      width: 20*fem,
                                      height: 20*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon-essential-tick-circle-wHB.png',
                                        width: 20*fem,
                                        height: 20*fem,
                                      ),
                                    ),
                                    Container(
                                      // frame110DDB (147:3469)
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // rectangle25A8R (147:3470)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                            width: 75*fem,
                                            height: 77*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(8*fem),
                                              color: Color(0xffffffff),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/rectangle-25-bg-jH3.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // frame105U97 (147:3471)
                                            margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                            width: 113*fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // frame109zt9 (147:3472)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                  width: double.infinity,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        // itemnamehere7Sy (147:3473)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                        width: double.infinity,
                                                        child: Text(
                                                          'Item name here',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // xcuX (147:3474)
                                                        width: double.infinity,
                                                        child: Text(
                                                          '1x',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1*ffem/fem,
                                                            color: Color(0x7f000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  // 9eZ (147:3475)
                                                  width: double.infinity,
                                                  child: Text(
                                                    '\$14.50',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupckm7641 (9zui86rXxfxtN8Ui4VCkM7)
                                width: double.infinity,
                                height: 100*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupdvjhS7s (9zuiDgXZyRBd7np4uwdVJh)
                                      padding: EdgeInsets.fromLTRB(15*fem, 8*fem, 15*fem, 15*fem),
                                      width: 310*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xff191919),
                                        borderRadius: BorderRadius.only (
                                          bottomLeft: Radius.circular(8*fem),
                                        ),
                                      ),
                                      child: Container(
                                        // group1000004212MVj (147:3477)
                                        width: 238*fem,
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // ellipse1355hpV (147:3485)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 1*fem),
                                              width: 16*fem,
                                              height: 16*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(8*fem),
                                                border: Border.all(color: Color(0x33ecdfd7)),
                                                color: Color(0x00ffffff),
                                              ),
                                            ),
                                            Container(
                                              // frame110Dnq (147:3478)
                                              height: double.infinity,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // rectangle25BUm (147:3479)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                                    width: 75*fem,
                                                    height: 77*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(8*fem),
                                                      color: Color(0xffffffff),
                                                      image: DecorationImage (
                                                        fit: BoxFit.cover,
                                                        image: AssetImage (
                                                          'assets/page-1/images/rectangle-25-bg-4QR.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame10565w (147:3480)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                                    width: 113*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          // frame109pXj (147:3481)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                          width: double.infinity,
                                                          child: Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                // itemnameherey9j (147:3482)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                                width: double.infinity,
                                                                child: Text(
                                                                  'Item name here',
                                                                  textAlign: TextAlign.center,
                                                                  style: SafeGoogleFont (
                                                                    'Urbanist',
                                                                    fontSize: 16*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1*ffem/fem,
                                                                    color: Color(0xffffffff),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // xV85 (147:3483)
                                                                width: double.infinity,
                                                                child: Text(
                                                                  '1x',
                                                                  textAlign: TextAlign.center,
                                                                  style: SafeGoogleFont (
                                                                    'Urbanist',
                                                                    fontSize: 16*ffem,
                                                                    fontWeight: FontWeight.w400,
                                                                    height: 1*ffem/fem,
                                                                    color: Color(0x7f000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // 2Nu (147:3484)
                                                          width: double.infinity,
                                                          child: Text(
                                                            '\$14.50',
                                                            textAlign: TextAlign.center,
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w400,
                                                              height: 1*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupv98mm5b (9zuiTbJ4N3vdCjg45ov98M)
                                      padding: EdgeInsets.fromLTRB(17*fem, 42*fem, 16*fem, 42*fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffff0000),
                                        borderRadius: BorderRadius.only (
                                          bottomRight: Radius.circular(8*fem),
                                        ),
                                      ),
                                      child: Center(
                                        // iconessentialtrashHpd (147:3463)
                                        child: SizedBox(
                                          width: 16*fem,
                                          height: 16*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-essential-trash-PXw.png',
                                            width: 16*fem,
                                            height: 16*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group1000004215Cwb (147:3486)
                    padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff191919),
                      borderRadius: BorderRadius.circular(8*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 10*fem),
                          blurRadius: 7.5*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group10000042136XB (147:3489)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 216*fem, 16*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ellipse1354dGD (147:3491)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                width: 16*fem,
                                height: 16*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                  border: Border.all(color: Color(0x33ecdfd7)),
                                  color: Color(0x00ffffff),
                                ),
                              ),
                              Text(
                                // sellernameherewnh (147:3490)
                                'Seller name here',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // line7gkH (147:3488)
                          width: double.infinity,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff363636),
                          ),
                        ),
                        Container(
                          // autogroupbrd73aq (9zujaeFzzSQmbAwN5mBrD7)
                          padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 16*fem, 16*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // group1000004211yzH (147:3492)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 16*fem),
                                width: double.infinity,
                                height: 77*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1355WUR (147:3500)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 1*fem),
                                      width: 16*fem,
                                      height: 16*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                        border: Border.all(color: Color(0x33ecdfd7)),
                                        color: Color(0x00ffffff),
                                      ),
                                    ),
                                    Container(
                                      // frame110Dtd (147:3493)
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // rectangle25BKf (147:3494)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                            width: 75*fem,
                                            height: 77*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(8*fem),
                                              color: Color(0xffffffff),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/rectangle-25-bg-7R3.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // frame105syB (147:3495)
                                            margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                            width: 113*fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // frame109Qy7 (147:3496)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                  width: double.infinity,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        // itemnamehereYpR (147:3497)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                        width: double.infinity,
                                                        child: Text(
                                                          'Item name here',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // xTAh (147:3498)
                                                        width: double.infinity,
                                                        child: Text(
                                                          '1x',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1*ffem/fem,
                                                            color: Color(0x7f000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  // aWD (147:3499)
                                                  width: double.infinity,
                                                  child: Text(
                                                    '\$14.50',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group1000004212Kih (147:3501)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 0*fem),
                                width: double.infinity,
                                height: 77*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse1355rTj (147:3509)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 1*fem),
                                      width: 16*fem,
                                      height: 16*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                        border: Border.all(color: Color(0x33ecdfd7)),
                                        color: Color(0x00ffffff),
                                      ),
                                    ),
                                    Container(
                                      // frame110aed (147:3502)
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // rectangle258w3 (147:3503)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                            width: 75*fem,
                                            height: 77*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(8*fem),
                                              color: Color(0xffffffff),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/rectangle-25-bg-vm7.png',
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // frame105SRw (147:3504)
                                            margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                            width: 113*fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // frame109B8d (147:3505)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                  width: double.infinity,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        // itemnamehere83s (147:3506)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                        width: double.infinity,
                                                        child: Text(
                                                          'Item name here',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1*ffem/fem,
                                                            color: Color(0xffffffff),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // xEsb (147:3507)
                                                        width: double.infinity,
                                                        child: Text(
                                                          '1x',
                                                          textAlign: TextAlign.center,
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1*ffem/fem,
                                                            color: Color(0x7f000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  // PEh (147:3508)
                                                  width: double.infinity,
                                                  child: Text(
                                                    '\$14.50',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupegwb8CH (9zugvPMhSb2WkaH8N4egwb)
              width: double.infinity,
              height: 249*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group1000004216fxu (147:3510)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                      width: 361*fem,
                      height: 249*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff191919),
                        borderRadius: BorderRadius.circular(8*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 10*fem),
                            blurRadius: 7.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // group10000042138rV (147:3513)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 216*fem, 16*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse13544VF (147:3515)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  width: 16*fem,
                                  height: 16*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                    border: Border.all(color: Color(0x33ecdfd7)),
                                    color: Color(0x00ffffff),
                                  ),
                                ),
                                Text(
                                  // sellernamehereng9 (147:3514)
                                  'Seller name here',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // line78k1 (147:3512)
                            width: double.infinity,
                            height: 1*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff363636),
                            ),
                          ),
                          Container(
                            // autogroup9my3hHK (9zuh73ibmKmthRGtXi9my3)
                            padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 16*fem, 16*fem),
                            width: double.infinity,
                            height: 201*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group1000004211E2M (147:3516)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 16*fem),
                                  width: double.infinity,
                                  height: 77*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse1355ZKX (147:3524)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 1*fem),
                                        width: 16*fem,
                                        height: 16*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(8*fem),
                                          border: Border.all(color: Color(0x33ecdfd7)),
                                          color: Color(0x00ffffff),
                                        ),
                                      ),
                                      Container(
                                        // frame110HWR (147:3517)
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // rectangle25FCM (147:3518)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                              width: 75*fem,
                                              height: 77*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(8*fem),
                                                color: Color(0xffffffff),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-25-bg-LUZ.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame105AaD (147:3519)
                                              margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                              width: 113*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame109JAd (147:3520)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          // itemnamehereeEV (147:3521)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          child: Text(
                                                            'Item name here',
                                                            textAlign: TextAlign.center,
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // xACq (147:3522)
                                                          width: double.infinity,
                                                          child: Text(
                                                            '1x',
                                                            textAlign: TextAlign.center,
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w400,
                                                              height: 1*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // hTf (147:3523)
                                                    width: double.infinity,
                                                    child: Text(
                                                      '\$14.50',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group1000004212EiV (147:3525)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91*fem, 0*fem),
                                  width: double.infinity,
                                  height: 77*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse1355NJu (147:3533)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 1*fem),
                                        width: 16*fem,
                                        height: 16*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(8*fem),
                                          border: Border.all(color: Color(0x33ecdfd7)),
                                          color: Color(0x00ffffff),
                                        ),
                                      ),
                                      Container(
                                        // frame110Hwf (147:3526)
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // rectangle25Eru (147:3527)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                              width: 75*fem,
                                              height: 77*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(5*fem),
                                                color: Color(0xffd9d9d9),
                                              ),
                                            ),
                                            Container(
                                              // frame105B1T (147:3528)
                                              margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                              width: 113*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame109uCM (147:3529)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          // itemnamehereSTB (147:3530)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          child: Text(
                                                            'Item name here',
                                                            textAlign: TextAlign.center,
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w500,
                                                              height: 1*ffem/fem,
                                                              color: Color(0xffffffff),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // xMa9 (147:3531)
                                                          width: double.infinity,
                                                          child: Text(
                                                            '1x',
                                                            textAlign: TextAlign.center,
                                                            style: SafeGoogleFont (
                                                              'Urbanist',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w400,
                                                              height: 1*ffem/fem,
                                                              color: Color(0x7f000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // htu (147:3532)
                                                    width: double.infinity,
                                                    child: Text(
                                                      '\$14.50',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1Sbb (147:3534)
                    left: 0*fem,
                    top: 133*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 83*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xff191919)),
                            color: Color(0xff010101),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame1000004227AXb (151:4504)
                    left: 16*fem,
                    top: 167*fem,
                    child: Container(
                      width: 87*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // totalHs7 (151:4505)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                            child: Text(
                              'Total:',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1*ffem/fem,
                                color: Color(0xff727272),
                              ),
                            ),
                          ),
                          Text(
                            // 241 (151:4506)
                            '\$16.31',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group24mXP (147:3535)
                    left: 250*fem,
                    top: 149*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 127*fem,
                        height: 44*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Container(
                          // group23Ugh (147:3536)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff11a0af),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Checkout',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}