import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // upcomings6Uq (110:5191)
        width: double.infinity,
        height: 852*fem,
        child: Container(
          // viewpostrU1 (110:5192)
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xff111111),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // group10yYd (110:5193)
                padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
                width: double.infinity,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff191919)),
                  color: Color(0xff111111),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // blackstatusbarHZK (110:5196)
                      margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                      width: double.infinity,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timeCgH (I110:5211;727:363)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.1428571429*ffem/fem,
                                  letterSpacing: -0.2800000012*fem,
                                  color: Color(0xffffffff),
                                ),
                                children: [
                                  TextSpan(
                                    text: '9:4',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                  TextSpan(
                                    text: '1',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: -0.2800000012*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // grouptBj (110:5197)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // cellularconnectionpLH (110:5206)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/cellular-connection-ZGM.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                SizedBox(
                                  width: 5*fem,
                                ),
                                Container(
                                  // wifiiwT (110:5202)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                  width: 15.33*fem,
                                  height: 11*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-8cq.png',
                                    width: 15.33*fem,
                                    height: 11*fem,
                                  ),
                                ),
                                SizedBox(
                                  width: 5*fem,
                                ),
                                Container(
                                  // batteryqWH (110:5198)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-SXT.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupmisukdF (9zuogwabsJYp6LPJHUMiSu)
                      width: 166*fem,
                      height: 24*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // upcomingdropstzM (110:5195)
                            left: 32*fem,
                            top: 4*fem,
                            child: Align(
                              child: SizedBox(
                                width: 134*fem,
                                height: 16*fem,
                                child: Text(
                                  'Upcoming drops',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 18*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 0.8888888889*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group4BTf (110:5212)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 60.28*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-4-jhB.png',
                                  width: 60.28*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16*fem,
              ),
              Container(
                // frame1000004213sbP (110:5215)
                padding: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
                width: double.infinity,
                height: 26*fem,
                child: Container(
                  // frame10000042071Sh (110:5216)
                  width: 772*fem,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextButton(
                        // frame14vpZ (110:5217)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 50*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Jan',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame15C1P (110:5219)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 51*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Feb',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame16UUh (110:5221)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 54*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Mar',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame17AsK (110:5223)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 51*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Apr',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame18fJH (110:5225)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 56*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'May',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame19wWh (110:5227)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 49*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Jun',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame20ccq (110:5229)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 45*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Jul',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame2173o (110:5231)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 53*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Aug',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame22me9 (110:5233)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 53*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Sep',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame23T1B (110:5235)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 51*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Oct',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame24L4y (110:5237)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 52*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Nov',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 14*fem,
                      ),
                      TextButton(
                        // frame251wo (110:5239)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 53*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff1e1e1e),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Dec',
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 16*fem,
              ),
              Container(
                // frame1000004214h3w (110:5241)
                margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group1000004196pPT (110:5242)
                      width: double.infinity,
                      height: 284*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame1000004202MuB (110:5243)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                            width: 170*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group1000004195VkV (110:5244)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/rectangle-7-bg-gfB.png',
                                      ),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ClipRect(
                                        // frame18y9s (110:5249)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame17Da1 (110:5246)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0x66000000),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: ClipRect(
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur (
                                              sigmaX: 7*fem,
                                              sigmaY: 7*fem,
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // iconsupportlikequestionstarJbT (110:5247)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                  width: 8*fem,
                                                  height: 8*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-support-like-question-star-L7B.png',
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                  ),
                                                ),
                                                Text(
                                                  // jwf (110:5248)
                                                  '4.2',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.2*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame1000004197HTP (110:5251)
                                  width: 81*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame1000004196E7j (110:5252)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // funkytshirtZfo (110:5253)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                              child: Text(
                                                'Funky T Shirt',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // WUZ (110:5254)
                                              '\$150',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 18*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 0.8888888889*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        // byzara23eqf (110:5255)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame1000004203XY5 (110:5256)
                            width: 170*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group1000004195GEm (110:5257)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/rectangle-7-bg-jCV.png',
                                      ),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ClipRect(
                                        // frame18wLu (110:5259)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame17bRT (110:5261)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0x66000000),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: ClipRect(
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur (
                                              sigmaX: 7*fem,
                                              sigmaY: 7*fem,
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // iconsupportlikequestionstargho (110:5262)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                  width: 8*fem,
                                                  height: 8*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-support-like-question-star-w85.png',
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                  ),
                                                ),
                                                Text(
                                                  // Q81 (110:5263)
                                                  '4.2',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.2*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame100000419795b (110:5264)
                                  width: 81*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame1000004196LQy (110:5265)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // funkytshirtTVb (110:5266)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                              child: Text(
                                                'Funky T Shirt',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // a4R (110:5267)
                                              '\$150',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 18*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 0.8888888889*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        // byzara237q3 (110:5268)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16*fem,
                    ),
                    Container(
                      // group100000419724q (110:5269)
                      width: double.infinity,
                      height: 284*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame1000004202mHK (110:5270)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                            width: 170*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group1000004195USd (110:5271)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/rectangle-7-bg-jw7.png',
                                      ),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ClipRect(
                                        // frame18Lzd (110:5273)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame17bff (110:5275)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0x66000000),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: ClipRect(
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur (
                                              sigmaX: 7*fem,
                                              sigmaY: 7*fem,
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // iconsupportlikequestionstarsdB (110:5276)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                  width: 8*fem,
                                                  height: 8*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-support-like-question-star-rVX.png',
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                  ),
                                                ),
                                                Text(
                                                  // nVF (110:5277)
                                                  '4.2',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.2*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame1000004197vrM (110:5278)
                                  width: 81*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame10000041965DT (110:5279)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // funkytshirtbhb (110:5280)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                              child: Text(
                                                'Funky T Shirt',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // K7o (110:5281)
                                              '\$150',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 18*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 0.8888888889*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        // byzara23fSZ (110:5282)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame1000004203oBP (110:5283)
                            width: 170*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group1000004195LSD (110:5284)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/rectangle-7-bg-L81.png',
                                      ),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ClipRect(
                                        // frame18Qgy (110:5286)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame1752R (110:5288)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0x66000000),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: ClipRect(
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur (
                                              sigmaX: 7*fem,
                                              sigmaY: 7*fem,
                                            ),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // iconsupportlikequestionstarLyw (110:5289)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                  width: 8*fem,
                                                  height: 8*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/icon-support-like-question-star-Dc5.png',
                                                    width: 8*fem,
                                                    height: 8*fem,
                                                  ),
                                                ),
                                                Text(
                                                  // GMo (110:5290)
                                                  '4.2',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 10*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.2*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame1000004197cgZ (110:5291)
                                  width: 81*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame1000004196knm (110:5292)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // funkytshirttPB (110:5293)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                              child: Text(
                                                'Funky T Shirt',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // cKB (110:5294)
                                              '\$150',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 18*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 0.8888888889*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        // byzara23ALh (110:5295)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7fffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16*fem,
                    ),
                    Container(
                      // group1000004207tvu (110:5296)
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group1000004198FFf (110:5297)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            width: double.infinity,
                            height: 284*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame1000004202aHw (110:5298)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                                  width: 170*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195JDw (110:5299)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-3Vs.png',
                                            ),
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            ClipRect(
                                              // frame18B2q (110:5301)
                                              child: BackdropFilter(
                                                filter: ImageFilter.blur (
                                                  sigmaX: 7*fem,
                                                  sigmaY: 7*fem,
                                                ),
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                                  width: 40*fem,
                                                  height: 16*fem,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      'Jan 04',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 10*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.2*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame17SUZ (110:5303)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                              padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0x66000000),
                                                borderRadius: BorderRadius.circular(100*fem),
                                              ),
                                              child: ClipRect(
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 7*fem,
                                                    sigmaY: 7*fem,
                                                  ),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // iconsupportlikequestionstarved (110:5304)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                        width: 8*fem,
                                                        height: 8*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/icon-support-like-question-star-JaD.png',
                                                          width: 8*fem,
                                                          height: 8*fem,
                                                        ),
                                                      ),
                                                      Text(
                                                        // 2hf (110:5305)
                                                        '4.2',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197mv9 (110:5306)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196iKb (110:5307)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtTHB (110:5308)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // mYm (110:5309)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23iiu (110:5310)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame1000004203G89 (110:5311)
                                  width: 170*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195iVw (110:5312)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-6ED.png',
                                            ),
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            ClipRect(
                                              // frame18Q7s (110:5314)
                                              child: BackdropFilter(
                                                filter: ImageFilter.blur (
                                                  sigmaX: 7*fem,
                                                  sigmaY: 7*fem,
                                                ),
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                                  width: 40*fem,
                                                  height: 16*fem,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      'Jan 04',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 10*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.2*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame173Rj (110:5316)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                              padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0x66000000),
                                                borderRadius: BorderRadius.circular(100*fem),
                                              ),
                                              child: ClipRect(
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 7*fem,
                                                    sigmaY: 7*fem,
                                                  ),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // iconsupportlikequestionstarvEd (110:5317)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                        width: 8*fem,
                                                        height: 8*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/icon-support-like-question-star-xho.png',
                                                          width: 8*fem,
                                                          height: 8*fem,
                                                        ),
                                                      ),
                                                      Text(
                                                        // dPw (110:5318)
                                                        '4.2',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197yih (110:5319)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041968Lh (110:5320)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtfbX (110:5321)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // Bpm (110:5322)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Xtd (110:5323)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group100000419952y (110:5324)
                            width: double.infinity,
                            height: 284*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame10000042021hK (110:5325)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                                  width: 170*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195Yx9 (110:5326)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-Wg1.png',
                                            ),
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            ClipRect(
                                              // frame18SGq (110:5328)
                                              child: BackdropFilter(
                                                filter: ImageFilter.blur (
                                                  sigmaX: 7*fem,
                                                  sigmaY: 7*fem,
                                                ),
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                                  width: 40*fem,
                                                  height: 16*fem,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      'Jan 04',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 10*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.2*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame17H2Z (110:5330)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                              padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0x66000000),
                                                borderRadius: BorderRadius.circular(100*fem),
                                              ),
                                              child: ClipRect(
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 7*fem,
                                                    sigmaY: 7*fem,
                                                  ),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // iconsupportlikequestionstarMYD (110:5331)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                        width: 8*fem,
                                                        height: 8*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/icon-support-like-question-star-Dj7.png',
                                                          width: 8*fem,
                                                          height: 8*fem,
                                                        ),
                                                      ),
                                                      Text(
                                                        // 4xR (110:5332)
                                                        '4.2',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197Pzh (110:5333)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame1000004196wFX (110:5334)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtUFT (110:5335)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // PdK (110:5336)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23jhB (110:5337)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame1000004203tiV (110:5338)
                                  width: 170*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group1000004195RyK (110:5339)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-v7K.png',
                                            ),
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            ClipRect(
                                              // frame18WUy (110:5341)
                                              child: BackdropFilter(
                                                filter: ImageFilter.blur (
                                                  sigmaX: 7*fem,
                                                  sigmaY: 7*fem,
                                                ),
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 152*fem),
                                                  width: 40*fem,
                                                  height: 16*fem,
                                                  decoration: BoxDecoration (
                                                    color: Color(0x66000000),
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      'Jan 04',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 10*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.2*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame17xrm (110:5343)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
                                              padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0x66000000),
                                                borderRadius: BorderRadius.circular(100*fem),
                                              ),
                                              child: ClipRect(
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 7*fem,
                                                    sigmaY: 7*fem,
                                                  ),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // iconsupportlikequestionstarSmw (110:5344)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                                        width: 8*fem,
                                                        height: 8*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/icon-support-like-question-star-LWD.png',
                                                          width: 8*fem,
                                                          height: 8*fem,
                                                        ),
                                                      ),
                                                      Text(
                                                        // xEV (110:5345)
                                                        '4.2',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame1000004197u9j (110:5346)
                                        width: 81*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // frame10000041963Wq (110:5347)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // funkytshirtBN9 (110:5348)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                    child: Text(
                                                      'Funky T Shirt',
                                                      style: SafeGoogleFont (
                                                        'Urbanist',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffffffff),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // hbP (110:5349)
                                                    '\$150',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 0.8888888889*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23ELR (110:5350)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7fffffff),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}