import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 140;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame1000004200CjK (106:2488)
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // group1000004195Z45 (106:2489)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
              padding: EdgeInsets.fromLTRB(8*fem, 166*fem, 8*fem, 8*fem),
              width: double.infinity,
              height: 190*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(8*fem),
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-7-bg-Sem.png',
                  ),
                ),
              ),
              child: Container(
                // frame17r3B (106:2491)
                padding: EdgeInsets.fromLTRB(5*fem, 2*fem, 5*fem, 2*fem),
                width: 34*fem,
                height: double.infinity,
                decoration: BoxDecoration (
                  color: Color(0x66000000),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: ClipRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur (
                      sigmaX: 7*fem,
                      sigmaY: 7*fem,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconsupportlikequestionstarvoj (106:2492)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 8*fem,
                          height: 8*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-support-like-question-star-4TT.png',
                            width: 8*fem,
                            height: 8*fem,
                          ),
                        ),
                        Text(
                          // 2bs (106:2493)
                          '4.2',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // frame1000004197Axy (106:2494)
              width: 81*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // frame1000004196WG9 (106:2495)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // funkytshirtQcR (106:2496)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                          child: Text(
                            'Funky T Shirt',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // tGh (106:2497)
                          '\$150',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w600,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  RichText(
                    // byzara23ouT (106:2498)
                    text: TextSpan(
                      style: SafeGoogleFont (
                        'Urbanist',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.3333333333*ffem/fem,
                        color: Color(0x7f000000),
                      ),
                      children: [
                        TextSpan(
                          text: 'by ',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.3333333333*ffem/fem,
                            color: Color(0x7f000000),
                          ),
                        ),
                        TextSpan(
                          text: 'Zara23',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.3333333333*ffem/fem,
                            color: Color(0x7f000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}