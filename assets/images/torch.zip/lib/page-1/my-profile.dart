import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // myprofilemzR (28:3117)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupqnxsHhs (9zrrzbW4f5tkhnXN1TqnXs)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 393*fem,
                height: 383*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle17QGh (28:3295)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 393*fem,
                          height: 154*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffd9d9d9),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-17-bg.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame77hmb (33:3594)
                      left: 351*fem,
                      top: 52*fem,
                      child: Align(
                        child: SizedBox(
                          width: 28*fem,
                          height: 28*fem,
                          child: Image.asset(
                            'assets/page-1/images/frame-77.png',
                            width: 28*fem,
                            height: 28*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame76o3w (33:3593)
                      left: 16*fem,
                      top: 52*fem,
                      child: Align(
                        child: SizedBox(
                          width: 28*fem,
                          height: 28*fem,
                          child: Image.asset(
                            'assets/page-1/images/frame-76.png',
                            width: 28*fem,
                            height: 28*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame74tr5 (33:3320)
                      left: 29*fem,
                      top: 115*fem,
                      child: Container(
                        width: 336*fem,
                        height: 268*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // ellipse10cXB (28:3296)
                              margin: EdgeInsets.fromLTRB(128*fem, 0*fem, 128*fem, 0*fem),
                              width: double.infinity,
                              height: 80*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(40*fem),
                                border: Border.all(color: Color(0xfffffbf8)),
                                image: DecorationImage (
                                  fit: BoxFit.cover,
                                  image: AssetImage (
                                    'assets/page-1/images/ellipse-10-bg.png',
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 24*fem,
                            ),
                            Container(
                              // frame73J97 (33:3319)
                              margin: EdgeInsets.fromLTRB(61.5*fem, 0*fem, 61.5*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // johndoeDms (33:3306)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                    child: Text(
                                      'John doe',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 0.8888888889*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // frame57hww (33:3318)
                                    width: double.infinity,
                                    height: 36*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame70FTf (33:3311)
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // cJD (33:3309)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                child: Text(
                                                  '1486',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // followersj7w (33:3310)
                                                'Followers',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 32*fem,
                                        ),
                                        Container(
                                          // frame71eEu (33:3312)
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // odb (33:3313)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                child: Text(
                                                  '18',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // followingY5P (33:3314)
                                                'Following',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 32*fem,
                                        ),
                                        Container(
                                          // frame72fQu (33:3315)
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // RQ5 (33:3316)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                child: Text(
                                                  '14',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // collectionMYd (33:3317)
                                                'Collection',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 24*fem,
                            ),
                            Text(
                              // bestcollectionintheworldfollow (33:3307)
                              'Best collection in the world. Follow me for daily updates',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                            SizedBox(
                              height: 24*fem,
                            ),
                            Container(
                              // frame75awB (33:3423)
                              margin: EdgeInsets.fromLTRB(119.5*fem, 0*fem, 119.5*fem, 0*fem),
                              width: double.infinity,
                              height: 32*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffeaeaea),
                                borderRadius: BorderRadius.circular(10*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Edit profile',
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group57G3K (33:3331)
              left: 0*fem,
              top: 407*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(44*fem, 0*fem, 48*fem, 0*fem),
                width: 393*fem,
                height: 25*fem,
                child: Container(
                  // group1000004189yiR (106:1769)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // autogroupy4xkvNm (9zrsquREek6sxC8WXaY4XK)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 45*fem, 0*fem),
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // postsf5T (33:3321)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.5*fem),
                              child: Text(
                                'Posts',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xff12a1af),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // pinsA2D (33:3322)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 50*fem, 0*fem),
                        child: Text(
                          'Pins',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0x7f000000),
                          ),
                        ),
                      ),
                      Container(
                        // collection5Q5 (33:3323)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 50*fem, 0*fem),
                        child: Text(
                          'Collection',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0x7f000000),
                          ),
                        ),
                      ),
                      Text(
                        // likeszX3 (33:3324)
                        'Likes',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Urbanist',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          color: Color(0x7f000000),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // frame288t9 (91:1720)
              left: 15*fem,
              top: 456*fem,
              child: Container(
                width: 364*fem,
                height: 1236*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // frame29ft5 (91:1721)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 182*fem,
                        height: 1236*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // frame28AZw (91:1722)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 182*fem,
                                height: 228*fem,
                                child: Container(
                                  // group26HeZ (91:1723)
                                  width: double.infinity,
                                  height: 200*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // group25Rkm (91:1724)
                                        left: 16.0009765625*fem,
                                        top: 2.9990844727*fem,
                                        child: Container(
                                          width: 166*fem,
                                          height: 187*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // group159wf (91:1725)
                                                left: 47.9946289062*fem,
                                                top: 17.588684082*fem,
                                                child: Container(
                                                  width: 118*fem,
                                                  height: 149.7*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5ssf (91:1726)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 149.7*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-dKo.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group14an5 (91:1727)
                                                left: 20.5864257812*fem,
                                                top: 10.9829101562*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                  width: 139.69*fem,
                                                  height: 170.3*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5u3f (91:1728)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 169.92*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-dAy.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group13cim (91:1729)
                                                left: 0*fem,
                                                top: 0*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                  width: 153.32*fem,
                                                  height: 187*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle58h7 (91:1730)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 186.78*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-9GM.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // group12rd7 (91:1731)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Container(
                                          width: 156*fem,
                                          height: 200*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle5o2Z (91:1732)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 200*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-kg1.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame307J9 (91:1743)
                              left: 0*fem,
                              top: 216*fem,
                              child: Container(
                                width: 174*fem,
                                height: 268*fem,
                                child: Container(
                                  // group26FfF (91:1744)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                  width: double.infinity,
                                  height: 240*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Container(
                                    // group12oAy (91:1745)
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Center(
                                      // rectangle5A1X (91:1746)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 240*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-5-bg-ZuT.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame32U2D (91:1757)
                              left: 0*fem,
                              top: 472*fem,
                              child: Container(
                                width: 174*fem,
                                height: 764*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group26bMj (91:1758)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      width: 166*fem,
                                      height: 240*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Container(
                                        // group128Mf (91:1759)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(10*fem),
                                        ),
                                        child: Center(
                                          // rectangle56JV (91:1760)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 240*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffd9d9d9),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg-z8q.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupjgsdQpy (9zrtTiitg4eR5iboVYjgSD)
                                      width: double.infinity,
                                      height: 516*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // frame30xrV (91:1771)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 174*fem,
                                              height: 268*fem,
                                              child: Container(
                                                // group26HNy (91:1772)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group121pm (91:1773)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5NfK (91:1774)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-YhX.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // frame31UCZ (91:1785)
                                            left: 0*fem,
                                            top: 248*fem,
                                            child: Container(
                                              width: 174*fem,
                                              height: 268*fem,
                                              child: Container(
                                                // group26cJm (91:1786)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12Yy7 (91:1787)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5Wf3 (91:1788)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-Wgy.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // frame29Cnm (91:1799)
                      left: 182*fem,
                      top: 0*fem,
                      child: Container(
                        width: 182*fem,
                        height: 956*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // frame29jXo (91:1800)
                              left: 16*fem,
                              top: 0*fem,
                              child: Container(
                                width: 166*fem,
                                height: 268*fem,
                                child: Container(
                                  // group26H3X (91:1801)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                  width: double.infinity,
                                  height: 240*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Container(
                                    // group12crV (91:1802)
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Center(
                                      // rectangle5aYR (91:1803)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 240*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-5-bg-tjK.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame31h7F (91:1814)
                              left: 8*fem,
                              top: 256*fem,
                              child: Container(
                                width: 174*fem,
                                height: 268*fem,
                                child: Container(
                                  // group26SKj (91:1815)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                  width: double.infinity,
                                  height: 240*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Container(
                                    // group12agq (91:1816)
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Center(
                                      // rectangle5jZj (91:1817)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 240*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-5-bg-nPj.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame33eRo (91:1828)
                              left: 0*fem,
                              top: 512*fem,
                              child: Container(
                                width: 182*fem,
                                height: 228*fem,
                                child: Container(
                                  // group26Nsb (91:1829)
                                  width: double.infinity,
                                  height: 200*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // group25XEh (91:1830)
                                        left: 16.0009765625*fem,
                                        top: 2.9990844727*fem,
                                        child: Container(
                                          width: 166*fem,
                                          height: 187*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // group15eaD (91:1831)
                                                left: 47.9946289062*fem,
                                                top: 17.5886535645*fem,
                                                child: Container(
                                                  width: 118*fem,
                                                  height: 149.7*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5ycV (91:1832)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 149.7*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-Tcm.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group146BK (91:1833)
                                                left: 20.5864257812*fem,
                                                top: 10.9829406738*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                  width: 139.69*fem,
                                                  height: 170.3*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5o5j (91:1834)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 169.92*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-xG1.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group13vAM (91:1835)
                                                left: 0*fem,
                                                top: 0*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                  width: 153.32*fem,
                                                  height: 187*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5S8h (91:1836)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 186.78*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-a17.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // group12kQH (91:1837)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Container(
                                          width: 156*fem,
                                          height: 200*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle5gYq (91:1838)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 200*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-QEV.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame34QUq (91:1849)
                              left: 0*fem,
                              top: 728*fem,
                              child: Container(
                                width: 182*fem,
                                height: 228*fem,
                                child: Container(
                                  // group26wUm (91:1850)
                                  width: double.infinity,
                                  height: 200*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // group25HYd (91:1851)
                                        left: 16.0009765625*fem,
                                        top: 2.9990844727*fem,
                                        child: Container(
                                          width: 166*fem,
                                          height: 187*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // group15QNM (91:1852)
                                                left: 47.9946289062*fem,
                                                top: 17.5886535645*fem,
                                                child: Container(
                                                  width: 118*fem,
                                                  height: 149.7*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5YDf (91:1853)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 149.7*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-MRb.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group14rk9 (91:1854)
                                                left: 20.5864257812*fem,
                                                top: 10.982925415*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                  width: 139.69*fem,
                                                  height: 170.3*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5aAM (91:1855)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 169.92*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-hTP.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // group13JMF (91:1856)
                                                left: 0*fem,
                                                top: 0*fem,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                  width: 153.32*fem,
                                                  height: 187*fem,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5pKb (91:1857)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 186.78*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-h6H.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // group12jBf (91:1858)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Container(
                                          width: 156*fem,
                                          height: 200*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Center(
                                            // rectangle5E8R (91:1859)
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 200*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  color: Color(0xffd9d9d9),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-5-bg-DUm.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // blackstatusbarhXo (28:3180)
              left: 36*fem,
              top: 15*fem,
              child: Container(
                width: 341.66*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeP9j (I28:3195;727:363)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: -0.2800000012*fem,
                            color: Color(0xffffffff),
                          ),
                          children: [
                            TextSpan(
                              text: '9:4',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: '1',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // groupnLH (28:3181)
                      margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cellularconnectionWXB (28:3190)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/cellular-connection-hc5.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // wifi1iq (28:3186)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                            width: 15.33*fem,
                            height: 11*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-Gjb.png',
                              width: 15.33*fem,
                              height: 11*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // batteryXBP (28:3182)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-uAR.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}