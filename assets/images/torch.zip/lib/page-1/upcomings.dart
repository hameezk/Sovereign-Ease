import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // upcomings9RB (110:4996)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10s6H (110:4814)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xfff1f1f1)),
                color: Color(0xfffefaf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarmBf (110:4817)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeULy (I110:4832;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupF8m (110:4818)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionNDP (110:4827)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-1Mj.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              SizedBox(
                                width: 5*fem,
                              ),
                              Container(
                                // wififCV (110:4823)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-pKT.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              SizedBox(
                                width: 5*fem,
                              ),
                              Container(
                                // batteryyU5 (110:4819)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-DVK.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup6mn9HUm (9zu8NuR3qqa8QzHDJu6Mn9)
                    width: 166*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // upcomingdropsRqs (110:4816)
                          left: 32*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 134*fem,
                              height: 16*fem,
                              child: Text(
                                'Upcoming drops',
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 0.8888888889*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group4WsK (110:4833)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 60.28*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-4-b8d.png',
                                width: 60.28*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 16*fem,
            ),
            Container(
              // frame100000421313P (110:4998)
              padding: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 26*fem,
              child: Container(
                // frame1000004207YJD (110:4999)
                width: 772*fem,
                height: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextButton(
                      // frame14FTX (110:5000)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 50*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Jan',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame15iM7 (110:5002)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 51*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Feb',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame16aeD (110:5004)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 54*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Mar',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame17s7X (110:5006)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 51*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Apr',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame18xem (110:5008)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 56*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'May',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame19eGh (110:5010)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 49*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Jun',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame20X5b (110:5012)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 45*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Jul',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame21zjs (110:5014)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 53*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Aug',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame22P1K (110:5016)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 53*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Sep',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame23U2m (110:5018)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 51*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Oct',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame249eh (110:5020)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 52*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Nov',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 14*fem,
                    ),
                    TextButton(
                      // frame25Eg9 (110:5022)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 53*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xfff4ece7),
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Dec',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 16*fem,
            ),
            Container(
              // group1000004247WtZ (176:2663)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupqwwsSGR (9zu96U48SpZmUzyWyQqWws)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: double.infinity,
                    height: 252*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame1000004202xVf (176:2664)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                          width: 182*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // frame28665 (176:2666)
                                left: 0*fem,
                                top: 0*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 182*fem,
                                    height: 228*fem,
                                    child: Container(
                                      // group26QsT (176:2667)
                                      width: double.infinity,
                                      height: 200*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group25mT7 (176:2668)
                                            left: 16.0009765625*fem,
                                            top: 2.9991455078*fem,
                                            child: Container(
                                              width: 166*fem,
                                              height: 187*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // group156VP (176:2669)
                                                    left: 47.9946289062*fem,
                                                    top: 17.5886230469*fem,
                                                    child: Container(
                                                      width: 118*fem,
                                                      height: 149.7*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5RnZ (176:2670)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 149.7*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-BDs.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group14k49 (176:2671)
                                                    left: 20.5864257812*fem,
                                                    top: 10.9829101562*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                      width: 139.69*fem,
                                                      height: 170.3*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5SxZ (176:2672)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 169.92*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-Hof.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group13NbK (176:2673)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                      width: 153.32*fem,
                                                      height: 187*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle55kd (176:2674)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 186.78*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-iA5.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group12owX (176:2675)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                              width: 156*fem,
                                              height: 200*fem,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg-X8D.png',
                                                  ),
                                                ),
                                              ),
                                              child: ClipRect(
                                                // frame1869w (176:2687)
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 7*fem,
                                                    sigmaY: 7*fem,
                                                  ),
                                                  child: Container(
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 100*fem, 168*fem),
                                                    width: 40*fem,
                                                    height: 16*fem,
                                                    decoration: BoxDecoration (
                                                      color: Color(0x66000000),
                                                      borderRadius: BorderRadius.circular(100*fem),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        'Jan 04',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // frame1000004197jTo (176:2689)
                                left: 0*fem,
                                top: 212*fem,
                                child: Container(
                                  width: 81*fem,
                                  height: 40*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // funkytshirtTPo (176:2691)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        child: Text(
                                          'Funky T Shirt',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      RichText(
                                        // byzara23aUR (176:2692)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame1000004203GVf (176:2693)
                          width: 166*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // group10000041951y3 (176:2694)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                width: double.infinity,
                                height: 200*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-7-bg-YwB.png',
                                    ),
                                  ),
                                ),
                                child: ClipRect(
                                  // frame18uHj (176:2696)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 7*fem,
                                      sigmaY: 7*fem,
                                    ),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 110*fem, 168*fem),
                                      width: 40*fem,
                                      height: 16*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0x66000000),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'Jan 04',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // frame1000004197kp9 (176:2698)
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // funkytshirtvCq (176:2700)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Funky T Shirt',
                                        style: SafeGoogleFont (
                                          'Urbanist',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.1428571429*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    RichText(
                                      // byzara23Sgy (176:2701)
                                      text: TextSpan(
                                        style: SafeGoogleFont (
                                          'Urbanist',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0x7f000000),
                                        ),
                                        children: [
                                          TextSpan(
                                            text: 'by ',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0x7f000000),
                                            ),
                                          ),
                                          TextSpan(
                                            text: 'Zara23',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0x7f000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupyxbbbCV (9zu9gnQHMt31w6RwKayxBb)
                    width: double.infinity,
                    height: 252*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame1000004202wGM (176:2702)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                          width: 166*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // group1000004195fi9 (176:2703)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                width: double.infinity,
                                height: 200*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-7-bg-QM7.png',
                                    ),
                                  ),
                                ),
                                child: ClipRect(
                                  // frame18wvZ (176:2705)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 7*fem,
                                      sigmaY: 7*fem,
                                    ),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 110*fem, 168*fem),
                                      width: 40*fem,
                                      height: 16*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0x66000000),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'Jan 04',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // frame1000004197aTj (176:2707)
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // funkytshirtvnV (176:2709)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Funky T Shirt',
                                        style: SafeGoogleFont (
                                          'Urbanist',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.1428571429*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    RichText(
                                      // byzara23dwo (176:2710)
                                      text: TextSpan(
                                        style: SafeGoogleFont (
                                          'Urbanist',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0x7f000000),
                                        ),
                                        children: [
                                          TextSpan(
                                            text: 'by ',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0x7f000000),
                                            ),
                                          ),
                                          TextSpan(
                                            text: 'Zara23',
                                            style: SafeGoogleFont (
                                              'Urbanist',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0x7f000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame1000004203aVf (176:2711)
                          width: 182*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // frame288GH (176:2714)
                                left: 0*fem,
                                top: 0*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 182*fem,
                                    height: 228*fem,
                                    child: Container(
                                      // group26ri5 (176:2715)
                                      width: double.infinity,
                                      height: 200*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group25DYd (176:2716)
                                            left: 16.0009765625*fem,
                                            top: 2.9991455078*fem,
                                            child: Container(
                                              width: 166*fem,
                                              height: 187*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // group159BP (176:2717)
                                                    left: 47.9946289062*fem,
                                                    top: 17.588684082*fem,
                                                    child: Container(
                                                      width: 118*fem,
                                                      height: 149.7*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle54p9 (176:2718)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 149.7*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-43B.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group14anV (176:2719)
                                                    left: 20.5864257812*fem,
                                                    top: 10.9829101562*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                      width: 139.69*fem,
                                                      height: 170.3*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5toB (176:2720)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 169.92*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-RRK.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // group13QmX (176:2721)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                      width: 153.32*fem,
                                                      height: 187*fem,
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(10*fem),
                                                      ),
                                                      child: Center(
                                                        // rectangle5Kdb (176:2722)
                                                        child: SizedBox(
                                                          width: double.infinity,
                                                          height: 186.78*fem,
                                                          child: Container(
                                                            decoration: BoxDecoration (
                                                              borderRadius: BorderRadius.circular(10*fem),
                                                              color: Color(0xffd9d9d9),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-5-bg-wwP.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group122nu (176:2723)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                              width: 156*fem,
                                              height: 200*fem,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-5-bg-rv5.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                // frame1873f (176:2735)
                                                width: 40*fem,
                                                height: 16*fem,
                                                decoration: BoxDecoration (
                                                  color: Color(0x66000000),
                                                  borderRadius: BorderRadius.circular(100*fem),
                                                ),
                                                child: ClipRect(
                                                  child: BackdropFilter(
                                                    filter: ImageFilter.blur (
                                                      sigmaX: 7*fem,
                                                      sigmaY: 7*fem,
                                                    ),
                                                    child: Stack(
                                                      children: [
                                                        Positioned(
                                                          // jan041eq (176:2736)
                                                          left: 5*fem,
                                                          top: 2*fem,
                                                          child: Align(
                                                            child: SizedBox(
                                                              width: 30*fem,
                                                              height: 12*fem,
                                                              child: Text(
                                                                'Jan 04',
                                                                style: SafeGoogleFont (
                                                                  'Urbanist',
                                                                  fontSize: 10*ffem,
                                                                  fontWeight: FontWeight.w500,
                                                                  height: 1.2*ffem/fem,
                                                                  color: Color(0xffffffff),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          // frame18uVK (176:2737)
                                                          left: 0*fem,
                                                          top: 0*fem,
                                                          child: ClipRect(
                                                            child: BackdropFilter(
                                                              filter: ImageFilter.blur (
                                                                sigmaX: 7*fem,
                                                                sigmaY: 7*fem,
                                                              ),
                                                              child: Container(
                                                                width: 40*fem,
                                                                height: 16*fem,
                                                                decoration: BoxDecoration (
                                                                  color: Color(0x66000000),
                                                                  borderRadius: BorderRadius.circular(100*fem),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    'Jan 04',
                                                                    style: SafeGoogleFont (
                                                                      'Urbanist',
                                                                      fontSize: 10*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.2*ffem/fem,
                                                                      color: Color(0xffffffff),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // frame1000004197mnR (176:2739)
                                left: 0*fem,
                                top: 212*fem,
                                child: Container(
                                  width: 81*fem,
                                  height: 40*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // funkytshirtJGZ (176:2741)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        child: Text(
                                          'Funky T Shirt',
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      RichText(
                                        // byzara23RMB (176:2742)
                                        text: TextSpan(
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'by ',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                            ),
                                            TextSpan(
                                              text: 'Zara23',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvaskxEd (9zuBH55qnKhPLXoSCTvAsK)
                    padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupzzghssP (9zuAH1vEzUtanmwXkDZzGh)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: 252*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame10000042021To (176:2743)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195Xww (176:2744)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-gkR.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame182Nu (176:2746)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame100000419767s (176:2748)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirt3Yu (176:2750)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara23NbB (176:2751)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // frame10000042038yf (176:2752)
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195tC9 (176:2753)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-qcm.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame18nHX (176:2755)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame1000004197Scy (176:2757)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirtzeV (176:2759)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara23X8d (176:2760)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // autogroupqnczfPF (9zuAcbBxgKU1Do5hh5qnCZ)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: 252*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame1000004202zRX (176:2761)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195isK (176:2762)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-qWH.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame18QVF (176:2764)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame1000004197GXT (176:2766)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirtp3B (176:2768)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara23XiH (176:2769)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // frame1000004203VoX (176:2770)
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195FGu (176:2771)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-BSR.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame18YWu (176:2773)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame10000041971QV (176:2775)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirtm8m (176:2777)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara23tjB (176:2778)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // autogroupbcghFTF (9zuAuzrczE3gE5ePdobCGH)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: 252*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame1000004202ye9 (176:2779)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195u21 (176:2780)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-7kV-u29.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame18C17 (176:2782)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame10000041974JD (176:2784)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirtC9X (176:2786)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara237nH (176:2787)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // frame1000004203s9B (176:2788)
                                width: 170*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group1000004195DTw (176:2789)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                                      width: double.infinity,
                                      height: 200*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(8*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-7-bg-KdK.png',
                                          ),
                                        ),
                                      ),
                                      child: ClipRect(
                                        // frame187JR (176:2791)
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur (
                                            sigmaX: 7*fem,
                                            sigmaY: 7*fem,
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 114*fem, 168*fem),
                                            width: 40*fem,
                                            height: 16*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0x66000000),
                                              borderRadius: BorderRadius.circular(100*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Jan 04',
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 10*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2*ffem/fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame1000004197xpq (176:2793)
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // funkytshirt7Sq (176:2795)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Funky T Shirt',
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.1428571429*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          RichText(
                                            // byzara23241 (176:2796)
                                            text: TextSpan(
                                              style: SafeGoogleFont (
                                                'Urbanist',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.3333333333*ffem/fem,
                                                color: Color(0x7f000000),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'by ',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'Zara23',
                                                  style: SafeGoogleFont (
                                                    'Urbanist',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.3333333333*ffem/fem,
                                                    color: Color(0x7f000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}