import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // newlyaddedcollectionsVwo (40:1093)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xff111111),
        ),
        child: Container(
          // frame351fF (45:4238)
          width: 580*fem,
          height: 1557*fem,
          child: Stack(
            children: [
              Positioned(
                // group28LhX (45:4239)
                left: 0*fem,
                top: 0*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 0*fem, 16*fem),
                  width: 580*fem,
                  height: 192*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff111111),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // blackstatusbarQhP (45:4242)
                        margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 202.34*fem, 21*fem),
                        width: double.infinity,
                        height: 16*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // timeixy (I45:4257;727:363)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 251*fem, 0*fem),
                              child: RichText(
                                textAlign: TextAlign.center,
                                text: TextSpan(
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xffd7d7d7),
                                  ),
                                  children: [
                                    TextSpan(
                                      text: '9:4',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xffd7d7d7),
                                      ),
                                    ),
                                    TextSpan(
                                      text: '1',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.1428571429*ffem/fem,
                                        letterSpacing: -0.2800000012*fem,
                                        color: Color(0xffd7d7d7),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              // groupjFo (45:4243)
                              margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // cellularconnectionrbK (45:4252)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                    width: 17*fem,
                                    height: 10.67*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/cellular-connection-Ztd.png',
                                      width: 17*fem,
                                      height: 10.67*fem,
                                    ),
                                  ),
                                  Container(
                                    // wifikwb (45:4248)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                    width: 15.33*fem,
                                    height: 11*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/wifi-iuw.png',
                                      width: 15.33*fem,
                                      height: 11*fem,
                                    ),
                                  ),
                                  Container(
                                    // batteryU6u (45:4244)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/battery-LYh.png',
                                      width: 24.33*fem,
                                      height: 11.33*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group4mrh (45:4258)
                        margin: EdgeInsets.fromLTRB(0.35*fem, 0*fem, 201*fem, 16*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // torchuCD (45:4259)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 278.72*fem, 0.9*fem),
                              width: 59.93*fem,
                              height: 15.38*fem,
                              child: Image.asset(
                                'assets/page-1/images/torch-ZjF.png',
                                width: 59.93*fem,
                                height: 15.38*fem,
                              ),
                            ),
                            Container(
                              // iconsearchsearchnormalRgM (45:4260)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-search-search-normal-MVT.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // frame39cM (45:4262)
                        width: double.infinity,
                        height: 84*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // frame24zD (45:4263)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1pCh (45:4264)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(39*fem, 42*fem, 3*fem, 0*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(30*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-2-bg-LED.png',
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      // group2K9T (45:4266)
                                      alignment: Alignment.bottomRight,
                                      child: SizedBox(
                                        width: 18*fem,
                                        height: 18*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group-2-Zfo.png',
                                          width: 18*fem,
                                          height: 18*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // addstoryF37 (45:4269)
                                    'Add story',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame3xCR (45:4270)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1Vy3 (45:4271)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xffd7d7d7),
                                          borderRadius: BorderRadius.circular(30*fem),
                                          border: Border (
                                          ),
                                        ),
                                        child: Center(
                                          // ellipse3m9s (45:4273)
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 56*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(28*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/ellipse-3-bg-2cR.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // nicklaustEV (45:4274)
                                    'Nicklaus',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame4QyX (45:4275)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1N9f (45:4276)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3HGd (45:4278)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-XAZ.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // cathynUH (45:4279)
                                    'Cathy',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame5XAy (45:4280)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group14wb (45:4281)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3nch (45:4283)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-Ht5.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // kaileyuhK (45:4284)
                                    'Kailey',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame6qay (45:4285)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1o21 (45:4286)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3iPs (45:4288)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-W3s.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // tiaraEND (45:4289)
                                    'Tiara',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame7Mxd (45:4290)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1ioB (45:4291)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse334m (45:4293)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-3s7.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // quincyAfB (45:4294)
                                    'Quincy',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // frame8hv1 (45:4295)
                              width: 60*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group1TPP (45:4296)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 2*fem, 2*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffd7d7d7),
                                      borderRadius: BorderRadius.circular(30*fem),
                                      border: Border (
                                      ),
                                    ),
                                    child: Center(
                                      // ellipse3NFT (45:4298)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 56*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(28*fem),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/ellipse-3-bg-vRP.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // dayneVay (45:4299)
                                    'Dayne',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Urbanist',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xffd7d7d7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // frame28257 (45:4300)
                left: 15*fem,
                top: 209*fem,
                child: Container(
                  width: 364*fem,
                  height: 1348*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // frame299Qd (45:4301)
                        width: 182*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // frame28hS9 (45:4302)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26f85 (45:4303)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25Bs7 (45:4304)
                                          left: 16.000793457*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15WeV (45:4305)
                                                  left: 47.9943237305*fem,
                                                  top: 17.5886230469*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5T3w (45:4306)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-X3F.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group14Mv1 (45:4307)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5rrm (45:4308)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-5Mj.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13ygV (45:4309)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle55zR (45:4310)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-WKK.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group12C3T (45:4311)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5uyT (45:4312)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-Gn5.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27345 (45:4313)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame32NMF (45:4318)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 60*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic1uMB (45:4319)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-5Ff.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messagebjo (45:4320)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-33P.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame31XNZ (45:4322)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-ARF.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        TextButton(
                                          // dots1F3f (45:4314)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: 20*fem,
                                            height: 20*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/dots-1-QrV.png',
                                              width: 20*fem,
                                              height: 20*fem,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupuk6hMsP (9zsKhpzerJwvYnjq3yuK6h)
                              padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // frame30guf (45:4323)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                    width: 174*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26d4D (45:4324)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12xsB (45:4325)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5Khj (45:4326)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-3vR.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27rBs (45:4327)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame32yGV (45:4332)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1vBj (45:4333)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-3pD.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // messaged69 (45:4334)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-Rgd.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31wMj (45:4336)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-Z9K.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots1UMf (45:4328)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-fkm.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame32CoT (45:4337)
                                    width: 174*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroupxvsb9ih (9zsL14zvbJJENFQs9cXvsB)
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 276*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group26tAV (45:4338)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: 166*fem,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12RRK (45:4339)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5BQV (45:4340)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-AyP.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group27VRB (45:4341)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame32oRs (45:4346)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic1wHB (45:4347)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-bwP.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messageceD (45:4348)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-jhs.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame31jyj (45:4350)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-twj.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1Gyf (45:4342)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-CsT.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame30Qpy (45:4351)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group26A3T (45:4352)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12u13 (45:4353)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5rgy (45:4354)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-A57.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group27mow (45:4355)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame32tNm (45:4360)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic12E5 (45:4361)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-8hw.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messageXAq (45:4362)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-HZb.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame313us (45:4364)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-Kpm.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1BFP (45:4356)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-k6m.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame31uSH (45:4365)
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group26Fm3 (45:4366)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 240*fem,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                ),
                                                child: Container(
                                                  // group12CRP (45:4367)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                  ),
                                                  child: Center(
                                                    // rectangle5ZFw (45:4368)
                                                    child: SizedBox(
                                                      width: double.infinity,
                                                      height: 240*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          borderRadius: BorderRadius.circular(10*fem),
                                                          color: Color(0xffd9d9d9),
                                                          image: DecorationImage (
                                                            fit: BoxFit.cover,
                                                            image: AssetImage (
                                                              'assets/page-1/images/rectangle-5-bg-jZK.png',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group275VB (45:4369)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                                width: double.infinity,
                                                height: 20*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // frame32biR (45:4374)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // trendingtopic1Lg1 (45:4375)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            child: TextButton(
                                                              onPressed: () {},
                                                              style: TextButton.styleFrom (
                                                                padding: EdgeInsets.zero,
                                                              ),
                                                              child: Container(
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/trending-topic-1-Wqw.png',
                                                                  width: 20*fem,
                                                                  height: 20*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // messagedQD (45:4376)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/message-H4d.png',
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                            ),
                                                          ),
                                                          TextButton(
                                                            // frame31xBb (45:4378)
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Container(
                                                              width: 20*fem,
                                                              height: 20*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-31-tUy.png',
                                                                width: 20*fem,
                                                                height: 20*fem,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // dots1HDs (45:4370)
                                                      width: 16.25*fem,
                                                      height: 3.75*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/dots-1-Vmj.png',
                                                        width: 16.25*fem,
                                                        height: 3.75*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // frame29pDo (45:4379)
                        width: 182*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // autogroupop3wZx5 (9zsMYGwHWmCLpQonsMoP3w)
                              padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 16*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    // frame295fX (45:4380)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                    width: 166*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group261JH (45:4381)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12wSq (45:4382)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle56Kj (45:4383)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-yaq.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27cJ5 (45:4384)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame32XR3 (45:4389)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1fGM (45:4390)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-HvR.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // messagem4V (45:4391)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-7EH.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31teu (45:4393)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-tJd.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots11jX (45:4385)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-B6Z.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame31wt5 (45:4394)
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // group26WAV (45:4395)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          width: double.infinity,
                                          height: 240*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                          ),
                                          child: Container(
                                            // group12eGh (45:4396)
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5oQV (45:4397)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 240*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-8RP.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // group27uiR (45:4398)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                          width: double.infinity,
                                          height: 20*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame322HF (45:4403)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // trendingtopic1Z2H (45:4404)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/trending-topic-1-7Y5.png',
                                                            width: 20*fem,
                                                            height: 20*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // message3y3 (45:4405)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/message-y7w.png',
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                      ),
                                                    ),
                                                    TextButton(
                                                      // frame31yLu (45:4407)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 20*fem,
                                                        height: 20*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-31-4oj.png',
                                                          width: 20*fem,
                                                          height: 20*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // dots1i3b (45:4399)
                                                width: 16.25*fem,
                                                height: 3.75*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/dots-1-w6q.png',
                                                  width: 16.25*fem,
                                                  height: 3.75*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame33dwF (45:4408)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26mnZ (45:4409)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25hAR (45:4410)
                                          left: 16.000793457*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15QqX (45:4411)
                                                  left: 47.9943237305*fem,
                                                  top: 17.5888671875*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle592R (45:4412)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-nNd.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group14sDK (45:4413)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5yn9 (45:4414)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-WLR.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13J3j (45:4415)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5QcZ (45:4416)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-wqB.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group12vau (45:4417)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle53fX (45:4418)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-ErD.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27mbX (45:4419)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame32s8m (45:4424)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic1QPb (45:4425)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-yxV.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messageJUy (45:4426)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-H7w.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame31ENd (45:4428)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-Rus.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // dots1m7f (45:4420)
                                          width: 16.25*fem,
                                          height: 3.75*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/dots-1-hYM.png',
                                            width: 16.25*fem,
                                            height: 3.75*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame34ti5 (45:4429)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26eSM (45:4430)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 200*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // group25mWy (45:4431)
                                          left: 16.000793457*fem,
                                          top: 2.9990234375*fem,
                                          child: Container(
                                            width: 166*fem,
                                            height: 187*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // group15gtq (45:4432)
                                                  left: 47.9943237305*fem,
                                                  top: 17.5888671875*fem,
                                                  child: Container(
                                                    width: 118*fem,
                                                    height: 149.7*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle51AR (45:4433)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 149.7*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-1qB.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group147jF (45:4434)
                                                  left: 20.5866699219*fem,
                                                  top: 10.9829101562*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.15*fem, 0.19*fem, 0.15*fem, 0.19*fem),
                                                    width: 139.69*fem,
                                                    height: 170.3*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5EYy (45:4435)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 169.92*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-xGh.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group13m37 (45:4436)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.09*fem, 0.11*fem, 0.09*fem, 0.11*fem),
                                                    width: 153.32*fem,
                                                    height: 187*fem,
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(10*fem),
                                                    ),
                                                    child: Center(
                                                      // rectangle5fuB (45:4437)
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 186.78*fem,
                                                        child: Container(
                                                          decoration: BoxDecoration (
                                                            borderRadius: BorderRadius.circular(10*fem),
                                                            color: Color(0xffd9d9d9),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-5-bg-haZ.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // group121CM (45:4438)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            width: 156*fem,
                                            height: 200*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(10*fem),
                                            ),
                                            child: Center(
                                              // rectangle5je9 (45:4439)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 200*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(10*fem),
                                                    color: Color(0xffd9d9d9),
                                                    image: DecorationImage (
                                                      fit: BoxFit.cover,
                                                      image: AssetImage (
                                                        'assets/page-1/images/rectangle-5-bg-tTT.png',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // group27Ta9 (45:4440)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.88*fem, 0*fem),
                                    width: double.infinity,
                                    height: 20*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame32mKw (45:4445)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61.88*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // trendingtopic16t1 (45:4446)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/trending-topic-1-bdb.png',
                                                      width: 20*fem,
                                                      height: 20*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // messagezCh (45:4447)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                                width: 20*fem,
                                                height: 20*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/message-5rq.png',
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                ),
                                              ),
                                              TextButton(
                                                // frame31uqT (45:4449)
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  width: 20*fem,
                                                  height: 20*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/frame-31-77P.png',
                                                    width: 20*fem,
                                                    height: 20*fem,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // dots1rEu (45:4441)
                                          width: 16.25*fem,
                                          height: 3.75*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/dots-1-bww.png',
                                            width: 16.25*fem,
                                            height: 3.75*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // footermsf (45:4450)
                left: 0*fem,
                top: 769*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(14*fem, 0*fem, 25*fem, 0*fem),
                  width: 393*fem,
                  height: 83*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff191919)),
                    color: Color(0xff010101),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // autogroupkr7sr8R (9zsNjExNUiba6FVwFtKr7s)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                        width: 44*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/auto-group-kr7s.png',
                          width: 44*fem,
                          height: 40*fem,
                        ),
                      ),
                      Container(
                        // iconshopshop9tD (45:4457)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 46*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-shop-shop-47B.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // group11rGq (45:4454)
                        margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46*fem, 0*fem),
                        width: 44*fem,
                        height: 44*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-11-D5s.png',
                          width: 44*fem,
                          height: 44*fem,
                        ),
                      ),
                      Container(
                        // iconnotificationnotificationP1 (45:4453)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 56*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-notification-notification-1U5.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // ellipse1fVB (45:4458)
                        margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(12*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/ellipse-1-bg-3ub.png',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // rectangle20YJ5 (40:1318)
                left: 0*fem,
                top: 0*fem,
                child: Align(
                  child: SizedBox(
                    width: 393*fem,
                    height: 852*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0x7f000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // group58GUy (40:1320)
                left: 16*fem,
                top: 204*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
                  width: 361*fem,
                  height: 410*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff111111),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupqvdxYxH (9zsNvjdDe3VmyDwxeyQvdX)
                        margin: EdgeInsets.fromLTRB(116*fem, 0*fem, 0*fem, 20*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // mycollectionVMj (40:1322)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 92*fem, 0*fem),
                              child: Text(
                                'My Collection',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Urbanist',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            TextButton(
                              // iconessentialclosetPs (40:1323)
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-essential-close-VAh.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // frame58CfT (40:1324)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 105*fem, 0*fem),
                        width: 224*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TextButton(
                              // frame78YDX (40:1325)
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: double.infinity,
                                height: 54*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // group59uiH (40:1326)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(15*fem, 15*fem, 15*fem, 15*fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xff343434)),
                                        color: Color(0xff111111),
                                        borderRadius: BorderRadius.circular(10*fem),
                                      ),
                                      child: Center(
                                        // iconessentialaddbr1 (40:1328)
                                        child: SizedBox(
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-essential-add-nNV.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // createnewcollectionXUm (40:1329)
                                      'Create new collection',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Urbanist',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              // autogrouppnkrTdK (9zsPAp46bbU9EzhbfvpNkR)
                              padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // frame79axq (40:1330)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 111*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // rectangle19X7P (40:1331)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          width: 54*fem,
                                          height: 54*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-19-bg-o7X.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // shoesSEM (40:1332)
                                          'Shoes',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16*fem,
                                  ),
                                  Container(
                                    // frame80xyP (40:1333)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 71*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // rectangle19JGZ (40:1334)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          width: 54*fem,
                                          height: 54*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-19-bg-fN1.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // accessoriesoj7 (40:1335)
                                          'Accessories',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16*fem,
                                  ),
                                  Container(
                                    // frame81LDF (40:1336)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 100*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // rectangle195Rj (40:1337)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          width: 54*fem,
                                          height: 54*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-19-bg-E49.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // tshirtsyn1 (40:1338)
                                          'T Shirts',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16*fem,
                                  ),
                                  Container(
                                    // frame82hbX (40:1339)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 113*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // rectangle19ELZ (40:1340)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          width: 54*fem,
                                          height: 54*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/rectangle-19-bg-yku.png',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // shirtsk41 (40:1341)
                                          'Shirts',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Urbanist',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}