import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // inventoryitemcWD (45:5620)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffffbf8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10jqj (45:5621)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xfff1f1f1)),
                color: Color(0xfffffbf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarRyT (45:5623)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timexTb (I45:5638;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // groupDXw (45:5624)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectionk25 (45:5633)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-NRP.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifiThB (45:5629)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-NQh.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryamo (45:5625)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-Tp5.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup1cqfHgD (9ztF4iFU32buj3XESd1Cqf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 258.66*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconarrowarrowleftciV (45:5640)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-arrow-arrow-left-i9o.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // tshirtsWYy (45:5641)
                          'T Shirts',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouphgqqr73 (9ztB3umhtT4vP8TqAphgQq)
              width: double.infinity,
              height: 800*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group52zj3 (45:5711)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      width: 361*fem,
                      height: 800*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupak9ov6u (9ztBGeuUJfCNAJ6FR5Ak9o)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group134yo (45:5712)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7jKF (45:5714)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-saH.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20Rxm (45:5715)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupnduvmFw (9ztBTUvmCKB7HxyfRondUV)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18Hzy (45:5716)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // NWd (45:5721)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23FqK (45:5722)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group14mBP (45:5723)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7Tpu (45:5725)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-omj.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20yHT (45:5726)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupqpj56ss (9ztBoZBeauSdHTnnuwQpJ5)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18q4m (45:5727)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // uqK (45:5732)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23QXB (45:5733)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogrouphu7jWTj (9ztC3Tx8yYBdNQen5ohU7j)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group15TNy (45:5734)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7vnM (45:5736)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-WFT.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20dwf (45:5737)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupaxobNeM (9ztCDNqHk9PryY96wZAxob)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18WEm (45:5738)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // c2u (45:5743)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23KT7 (45:5744)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group16f9b (45:5745)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7kRw (45:5747)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-6qP.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20G9P (45:5748)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupjxx1ntR (9ztCXx8g2Ub6HbwMotjxx1)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18KtM (45:5749)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // 225 (45:5754)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23XUd (45:5755)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16*fem,
                          ),
                          Container(
                            // autogroupgdn947B (9ztCnCDwYwnpkCaefwGDN9)
                            width: double.infinity,
                            height: 256*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group17CDP (45:5756)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle752H (45:5758)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-wcd.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20NGH (45:5759)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupw7txJQq (9ztCwmnKBiYKygHfqWW7TX)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18qQm (45:5760)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 14*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1428571429*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // kGq (45:5765)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23et1 (45:5766)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group18Pz1 (45:5767)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                  width: 172*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(8*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3fd0d0d0),
                                        offset: Offset(0*fem, 10*fem),
                                        blurRadius: 7.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // rectangle7seH (45:5769)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                        width: double.infinity,
                                        height: 160*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.only (
                                            topLeft: Radius.circular(8*fem),
                                            topRight: Radius.circular(8*fem),
                                          ),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/rectangle-7-bg-5sw.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame20mUm (45:5770)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        width: 112*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // autogroupakzbu5B (9ztDFmGLUqRn8rU9F3AKZb)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: double.infinity,
                                              height: 48*fem,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // frame18RpD (45:5771)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      width: 112*fem,
                                                      height: 36*fem,
                                                      child: Text(
                                                        'Funky T Shirt',
                                                        style: SafeGoogleFont (
                                                          'Urbanist',
                                                          fontSize: 14*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1428571429*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // KPo (45:5776)
                                                    left: 0*fem,
                                                    top: 32*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 37*fem,
                                                        height: 16*fem,
                                                        child: Text(
                                                          '\$150',
                                                          style: SafeGoogleFont (
                                                            'Urbanist',
                                                            fontSize: 18*ffem,
                                                            fontWeight: FontWeight.w600,
                                                            height: 0.8888888889*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            RichText(
                                              // byzara23Rhj (45:5777)
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Urbanist',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0x7f000000),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'by ',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Zara23',
                                                    style: SafeGoogleFont (
                                                      'Urbanist',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0x7f000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1aU9 (50:6815)
                    left: 0*fem,
                    top: 646*fem,
                    child: Align(
                      child: SizedBox(
                        width: 393*fem,
                        height: 100*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffe6e6e6)),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group24hHs (50:6816)
                    left: 16*fem,
                    top: 670*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 361*fem,
                        height: 45*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Container(
                          // group232L9 (50:6817)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff11a0af),
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'Add item',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Urbanist',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}