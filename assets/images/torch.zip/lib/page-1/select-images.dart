import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // selectimages7ry (109:4101)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group10eM7 (109:4127)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 15.34*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xfff1f1f1)),
                color: Color(0xfffefaf8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // blackstatusbarYBb (109:4129)
                    margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeTZT (I109:4144;727:363)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: -0.2800000012*fem,
                                color: Color(0xff0a0a0a),
                              ),
                              children: [
                                TextSpan(
                                  text: '9:4',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                                TextSpan(
                                  text: '1',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: -0.2800000012*fem,
                                    color: Color(0xff0a0a0a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // grouph6R (109:4130)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 2.33*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cellularconnectiondVs (109:4139)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 17*fem,
                                height: 10.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/cellular-connection-7oP.png',
                                  width: 17*fem,
                                  height: 10.67*fem,
                                ),
                              ),
                              Container(
                                // wifik4h (109:4135)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0.34*fem),
                                width: 15.33*fem,
                                height: 11*fem,
                                child: Image.asset(
                                  'assets/page-1/images/wifi-Nth.png',
                                  width: 15.33*fem,
                                  height: 11*fem,
                                ),
                              ),
                              Container(
                                // batteryfSZ (109:4131)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 24.33*fem,
                                height: 11.33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/battery-gLy.png',
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4mEh (109:4145)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 244.66*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconarrowarrowleftu61 (109:4147)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-arrow-arrow-left-Hn1.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // newpostPG5 (109:4148)
                          'New post',
                          style: SafeGoogleFont (
                            'Urbanist',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 0.8888888889*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouphnnviZF (9ztxwB9hkDu4i67iWohnNV)
              padding: EdgeInsets.fromLTRB(168*fem, 16*fem, 16*fem, 10.5*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-bg-uxV.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRect(
                    // frame11pMP (109:4154)
                    child: BackdropFilter(
                      filter: ImageFilter.blur (
                        sigmaX: 2*fem,
                        sigmaY: 2*fem,
                      ),
                      child: Container(
                        margin: EdgeInsets.fromLTRB(178*fem, 0*fem, 0*fem, 337*fem),
                        width: 31*fem,
                        height: 20*fem,
                        decoration: BoxDecoration (
                          color: Color(0xcc000000),
                          borderRadius: BorderRadius.circular(5*fem),
                        ),
                        child: Center(
                          child: Text(
                            '1/5',
                            style: SafeGoogleFont (
                              'Urbanist',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // frame6T9T (109:4156)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 150.63*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(10*fem, 6*fem, 9.87*fem, 6*fem),
                    decoration: BoxDecoration (
                      color: Color(0xfff5f5f5),
                      borderRadius: BorderRadius.circular(100*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // xmlid28992H (109:4157)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid289.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid287T2y (109:4158)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid287.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291BUm (109:4159)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291-zd7.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291uvZ (109:4160)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                        SizedBox(
                          width: 4*fem,
                        ),
                        Container(
                          // xmlid291r57 (109:4161)
                          width: 4.5*fem,
                          height: 4.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/xmlid291-x2M.png',
                            width: 4.5*fem,
                            height: 4.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // recentszBK (109:4233)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouplabsXww (9ztybjsn8gk8REnGwjLaBs)
                    width: double.infinity,
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004205Ged (109:4267)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-zL1.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleavD (109:4242)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-vLZ.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004201hjw (109:4263)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-Txu.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleQeM (109:4268)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-fJh.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004202vch (109:4264)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-EcZ.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircleqjf (109:4273)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-Xdj.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group1000004203AG9 (109:4265)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 9*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-KfP.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcircle5e1 (109:4278)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-mjX.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjrtpoa1 (9ztyqu8rNhLBHRUjtEJRTP)
                    width: double.infinity,
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group1000004204YnV (109:4266)
                          padding: EdgeInsets.fromLTRB(74*fem, 74*fem, 8*fem, 8*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-bg-LPT.png',
                              ),
                            ),
                          ),
                          child: Align(
                            // iconessentialtickcirclesZs (109:4283)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-essential-tick-circle-yHT.png',
                                width: 16*fem,
                                height: 16*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // rectanglePo7 (109:4245)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-8A5.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectangle9GV (109:4243)
                          width: 98*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-PrZ.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // rectanglegnD (109:4244)
                          width: 99*fem,
                          height: 98*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-TFP.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouprha1dxM (9ztz44TFoh9quhVNffrhA1)
                    width: double.infinity,
                    height: 196*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectanglemof (109:4234)
                          left: 0*fem,
                          top: 98.783996582*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-3RT.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle65F (109:4235)
                          left: 98.2613525391*fem,
                          top: 98.783996582*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-jxd.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleR7X (109:4236)
                          left: 196.5227050781*fem,
                          top: 98.783996582*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-68q.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectanglewbf (109:4237)
                          left: 294.7839355469*fem,
                          top: 98.783996582*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97.22*fem,
                              height: 97.22*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-7r9.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleg3T (109:4247)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-dJH.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleQEM (109:4248)
                          left: 98*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-q2h.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectanglewEH (109:4249)
                          left: 294*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 99*fem,
                              height: 98*fem,
                              child: Image.asset(
                                'assets/page-1/images/rectangle-A9P.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // videoGnM (109:4250)
                          left: 255.1773681641*fem,
                          top: 74.5*fem,
                          child: Container(
                            width: 30*fem,
                            height: 13*fem,
                            child: Center(
                              child: Text(
                                '06:23',
                                textAlign: TextAlign.right,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 11*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1818181818*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle1kSd (109:4122)
                          left: 0*fem,
                          top: 49*fem,
                          child: Align(
                            child: SizedBox(
                              width: 393*fem,
                              height: 117*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffe6e6e6)),
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group24FuB (109:4123)
                          left: 16*fem,
                          top: 73*fem,
                          child: Container(
                            width: 361*fem,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Container(
                              // group23neD (109:4124)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xff11a0af),
                                borderRadius: BorderRadius.circular(100*fem),
                              ),
                              child: Center(
                                child: Text(
                                  'Post',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Urbanist',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}